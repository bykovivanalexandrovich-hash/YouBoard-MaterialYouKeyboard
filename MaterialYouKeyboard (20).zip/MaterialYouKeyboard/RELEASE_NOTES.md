# YouBoard 5.1.1_2

## New in this build
- New "R" button at the top right of the Version screen (opposite the back arrow). It adapts to the colours of the screen and opens the big releases, 1.0, 1.5, 2.0 and on to 5.0, as colourful cards.

## Previous build (5.1)
- Wavy loading indicator and more careful autocorrect.

## Install
Download `YouBoard.apk` below and install it over the old version.
