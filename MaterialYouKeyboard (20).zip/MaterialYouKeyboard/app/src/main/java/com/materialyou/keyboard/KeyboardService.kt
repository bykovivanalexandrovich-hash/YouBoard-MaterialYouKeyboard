package com.materialyou.keyboard

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import android.content.SharedPreferences
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.color.DynamicColors
import com.google.android.material.color.MaterialColors
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class KeyboardService : InputMethodService() {

    companion object {
        const val PREFS = "keyboard_prefs"
        private val SYMBOL_ROWS = listOf("1234567890", "@#\$%&-+()/", "=*\"':;!?")

        /** Long-press alternatives in the symbols layout: basic maths signs, brackets, currencies. */
        private val MATH_ALTS = mapOf(
            "+" to "±", "-" to "−–—_~", "*" to "×·√^", "/" to "÷\\|", "=" to "≠≈≤≥", "%" to "‰",
            "(" to "[{<", ")" to "]}>", "1" to "¹½¼", "2" to "²⅔", "3" to "³¾", "0" to "°∅∞",
            "\$" to "€£¥", "'" to "`´’", "\"" to "«»„", "&" to "§", "#" to "№"
        )
        private const val SEPARATORS = ".,!?;:"
    }

    private enum class Shift { OFF, ON, CAPS }

    private class Morph(
        val d: GradientDrawable,
        val n: FloatArray,
        val p: FloatArray,
        var color: Int,
        var pressedColor: Int
    ) {
        val cur: FloatArray = n.copyOf()
        var curColor: Int = color
        var anim: ValueAnimator? = null
    }

    private class Key(
        val root: FrameLayout,
        val face: FrameLayout,
        val label: TextView?,
        val icon: ImageView?,
        val morph: Morph
    )

    private class Cat(val tab: String, val items: List<String>)
    private class Correction(val original: String, val fixed: String, val sep: String)
    private class Sugg(val list: List<String>, val autoFix: String?)

    private class Palette(private val c: Context, theme: String) {
        private val dark = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        private val t = Themes.colors(theme, dark)

        private fun col(attr: Int, fallback: Long): Int =
            MaterialColors.getColor(c, attr, fallback.toInt())

        val bg = t?.bg ?: col(com.google.android.material.R.attr.colorSurfaceContainer, 0xFF2B2930)
        val letter = t?.letter ?: col(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF36343B)
        val space = t?.space ?: col(com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E)
        val function = t?.function ?: col(com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458)
        val onFunction = t?.onFunction ?: col(com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8)
        val tertiary = t?.tertiary ?: col(com.google.android.material.R.attr.colorTertiaryContainer, 0xFF633B48)
        val onTertiary = t?.onTertiary ?: col(com.google.android.material.R.attr.colorOnTertiaryContainer, 0xFFFFD8E4)
        val primary = t?.primary ?: col(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF)
        val onPrimary = t?.onPrimary ?: col(com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72)
        val pressed = t?.pressed ?: col(com.google.android.material.R.attr.colorPrimaryContainer, 0xFF4F378B)
        val onSurface = t?.onSurface ?: col(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9)
        val onSurfaceVariant = t?.onSurfaceVariant ?: col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFFCAC4D0)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val prefs: SharedPreferences by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private fun kbFace(): Typeface = Fonts.kb(this, prefs)
    private val audio: AudioManager? by lazy { getSystemService(AudioManager::class.java) }
    private val imm: InputMethodManager? by lazy { getSystemService(InputMethodManager::class.java) }
    private val exec = Executors.newSingleThreadExecutor()
    private val dicts = HashMap<String, WordDict>()
    private val userWords: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private lateinit var clipStore: ClipStore
    private var clipboard: ClipboardManager? = null
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip(true) }

    // state
    private var lang = Langs.RU
    private var symbols = false
    private var shift = Shift.OFF
    private var renderedShift: Shift? = null
    private var lastShiftTap = 0L
    private var plus = false
    private var square = false
    private var retro = false

    // typing state
    private val word = StringBuilder()
    private var lastOwnEdit = 0L
    private var lastCorrection: Correction? = null
    private var skipCorrect: String? = null
    private var canDoubleSpace = false
    private var lastSpaceTime = 0L
    private var suggestOn = true
    private var autocorrectOn = true
    private var suggestionsAllowed = true
    @Volatile
    private var suggestGen = 0
    private var suggestFor: String? = null
    private var lastWord: String? = null
    private var nextShown = false
    private val bigrams = HashMap<String, HashMap<String, Int>>()
    private val saveBigramsRun = Runnable { saveBigrams() }
    private var autoFix: String? = null
    private val resyncRun = Runnable { resyncWord() }
    private val JOY_BLUE = 0xFF1E6FE0.toInt()

    // views
    private var rootView: View? = null
    private var viewCtx: Context? = null
    private var palette: Palette? = null
    private var builtSig = ""
    private var navColor = 0
    private var faceH = 0f
    private var keysBox: LinearLayout? = null
    private var contentFrame: FrameLayout? = null
    private var trail: SwipeTrail? = null
    private var swipeCommitted: String? = null
    private var panel: View? = null
    private var panelKind: String? = null
    private var clipList: LinearLayout? = null
    private var clipBtn: View? = null
    private var symBtn: View? = null
    private var altOverlay: LinearLayout? = null
    private val altChips = ArrayList<TextView>()
    private var altValues: List<String> = emptyList()
    private var altSel = 0
    private var menuKey: Key? = null
    private var enterBtn: Key? = null
    private var menuOverlay: LinearLayout? = null
    private var liveClip: String? = null
    private var liveKind = 0 // 0 text, 1 one-time code, 2 other sensitive
    private var liveTime = 0L
    private var usedClip: String? = null
    private var chipShown = false
    private var emojiCache: List<Cat>? = null
    private val letterKeys = mutableListOf<Pair<TextView, String>>()
    private val letterTargets = mutableListOf<Pair<Key, String>>()
    private var lastDownT = 0L
    private var lastDownX = 0f
    private var lastDownY = 0f
    private val suggestCells = mutableListOf<TextView>()
    private var shiftKey: Key? = null
    private var shiftCustom: Int? = null
    private var spaceCustom: Int? = null
    private var pendingCustom: Int? = null
    private var pendingShape: String? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        clipStore = ClipStore(prefs)
        userWords.addAll(prefs.getStringSet("user_words", emptySet()) ?: emptySet())
        loadBigrams()
        clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.addPrimaryClipChangedListener(clipListener)
        val act = activeLangs()
        lang = act[0]
        act.forEach { ensureDict(it) }
    }

    override fun onDestroy() {
        stopVoice()
        recognizer?.destroy()
        recognizer = null
        clipboard?.removePrimaryClipChangedListener(clipListener)
        exec.shutdown()
        super.onDestroy()
    }

    /**
     * The window always holds this one host view; a rebuild only swaps its child. Calling setInputView again
     * (e.g. when a form moves from a text field to a phone field) re-creates the input window, and the keyboard
     * visibly slides out and back in.
     */
    private var host: FrameLayout? = null

    // ---- debug mode: a log line above the keyboard showing what the service is doing
    private var dbgView: TextView? = null
    private val dbgLines = ArrayDeque<String>()
    private val dbgT0 = SystemClock.uptimeMillis()

    private fun dbg(msg: String) {
        if (!prefs.getBoolean("debug_mode", false)) return
        val t = SystemClock.uptimeMillis() - dbgT0
        dbgLines.addLast("${t / 1000}.${(t % 1000).toString().padStart(3, '0')} $msg")
        while (dbgLines.size > 5) dbgLines.removeFirst()
        showDbg()
        // the on-screen line disappears together with the keyboard, so keep a longer history for the Control Center
        val old = prefs.getString("dbg_log", "") ?: ""
        val all = (old.split('\n').filter { it.isNotEmpty() } + dbgLines.last()).takeLast(60)
        prefs.edit().putString("dbg_log", all.joinToString("\n")).apply()
    }

    private fun showDbg() {
        dbgView?.text = dbgLines.joinToString("\n")
    }

    override fun onWindowShown() {
        super.onWindowShown()
        dbg("WINDOW shown")
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        dbg("WINDOW hidden")
    }

    private var lastEventT = SystemClock.uptimeMillis()

    /** who called us: the first stack frame that is neither this class nor the IME framework plumbing */
    private fun caller(): String {
        val f = Throwable().stackTrace.firstOrNull {
            !it.className.startsWith("com.materialyou") && !it.className.startsWith("java.") &&
                !it.className.startsWith("dalvik.") && it.className != "android.inputmethodservice.InputMethodService"
        }
        return f?.let { it.className.substringAfterLast('.') + "." + it.methodName } ?: "?"
    }

    private fun dt(): String {
        val now = SystemClock.uptimeMillis()
        val d = now - lastEventT
        lastEventT = now
        return "+${d}ms"
    }

    private var lastEi: String? = null

    // ---- inline autofill suggestions ("copy code from message" etc.), shown inside the suggestion bar
    private var inlineSlot: FrameLayout? = null
    private var inlineView: View? = null

    private fun showInline(v: View) {
        val slot = inlineSlot ?: return
        (v.parent as? ViewGroup)?.removeView(v)
        slot.removeAllViews()
        slot.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        slot.visibility = View.VISIBLE
        inlineView = v
        for (tv in suggestCells) tv.visibility = View.GONE
        dbg("inline suggestion shown")
    }

    private fun clearInline() {
        if (inlineView == null) return
        inlineView = null
        inlineSlot?.let {
            it.removeAllViews()
            it.visibility = View.GONE
        }
        paintSuggestions()
    }

    @androidx.annotation.RequiresApi(android.os.Build.VERSION_CODES.R)
    override fun onCreateInlineSuggestionsRequest(uiExtras: Bundle): android.view.inputmethod.InlineSuggestionsRequest? {
        return try {
            val styles = androidx.autofill.inline.UiVersions.newStylesBuilder()
                .addStyle(androidx.autofill.inline.v1.InlineSuggestionUi.newStyleBuilder().build())
                .build()
            val spec = android.widget.inline.InlinePresentationSpec.Builder(
                android.util.Size(0, 0), android.util.Size(Int.MAX_VALUE, Int.MAX_VALUE)
            ).setStyle(styles).build()
            android.view.inputmethod.InlineSuggestionsRequest.Builder(listOf(spec))
                .setMaxSuggestionCount(1)
                .build()
        } catch (e: Throwable) {
            null
        }
    }

    @androidx.annotation.RequiresApi(android.os.Build.VERSION_CODES.R)
    override fun onInlineSuggestionsResponse(response: android.view.inputmethod.InlineSuggestionsResponse): Boolean {
        val list = response.inlineSuggestions
        if (list.isEmpty()) {
            clearInline()
            return false
        }
        return try {
            val size = android.util.Size(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            list[0].inflate(this, size, androidx.core.content.ContextCompat.getMainExecutor(this)) { v ->
                if (v != null) showInline(v) else clearInline()
            }
            true
        } catch (e: Throwable) {
            false
        }
    }
    private var idle = false
    private var hideT = 0L
    private var icWas = false

    private fun eiSig(a: EditorInfo?) =
        "${a?.packageName}|${a?.fieldId}|${a?.inputType}|${a?.imeOptions}|${a?.privateImeOptions}"

    /** 0.3 s and 1.5 s after a start: is the connection alive and is the keyboard still on screen? */
    private fun scheduleHealthCheck() {
        for (ms in longArrayOf(300, 1500)) {
            handler.postDelayed({
                val ic = currentInputConnection
                val ok = try {
                    ic?.getTextBeforeCursor(1, 0) != null || ic != null
                } catch (_: Throwable) {
                    false
                }
                dbg("check ${ms}ms: IC=${if (ic == null) "NULL" else if (ok) "ok" else "dead"} shown=$isInputViewShown win=$isShowInputRequested")
            }, ms)
        }
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        idle = (attribute?.inputType ?: 0) == 0 && attribute?.fieldId == 0
        val sig = eiSig(attribute)
        val same = lastEi == sig
        lastEi = sig
        val sinceHide = if (hideT > 0) "${SystemClock.uptimeMillis() - hideT}ms" else "-"
        if (!idle) dbg("EI ${if (same) "same" else "CHANGED"} sinceHide=$sinceHide IC=${if (currentInputConnection == null) "NULL" else "ok"}")
        icWas = currentInputConnection != null
        if (idle) return
        scheduleHealthCheck()
        dbg(
            "startInput ${dt()} ime=0x${Integer.toHexString(attribute?.imeOptions ?: 0)} " +
                "type=0x${Integer.toHexString(attribute?.inputType ?: 0)} act=${(attribute?.imeOptions ?: 0) and 0xff} " +
                "fid=${attribute?.fieldId} restart=$restarting"
        )
    }

    override fun onFinishInput() {
        val icNow = currentInputConnection != null
        super.onFinishInput()
        if (!idle) dbg("finishInput ${dt()} IC was=${if (icNow) "ok" else "NULL"}")
    }

    override fun onShowInputRequested(flags: Int, configChange: Boolean): Boolean {
        val r = super.onShowInputRequested(flags, configChange)
        dbg("showRequested flags=$flags cfg=$configChange -> $r")
        return r
    }

    override fun requestHideSelf(flags: Int) {
        dbg("requestHideSelf($flags) by ${caller()}")
        super.requestHideSelf(flags)
    }

    override fun hideWindow() {
        hideT = SystemClock.uptimeMillis()
        dbg("hideWindow ${dt()} by ${caller()}")
        super.hideWindow()
    }

    override fun showWindow(showInput: Boolean) {
        dbg("showWindow($showInput) ${dt()} by ${caller()}")
        super.showWindow(showInput)
    }

    override fun onBindInput() {
        super.onBindInput()
    }

    override fun onUnbindInput() {
        super.onUnbindInput()
    }

    override fun onCreateInputView(): View {
        val v = buildKeyboard()
        rootView = v
        builtSig = signature()
        val h = FrameLayout(this)
        h.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        host = h
        return h
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // an exception here makes the system drop the keyboard right after showing it, so never let one escape
        dbg(
            "START ${dt()} ${info?.packageName?.substringAfterLast('.')} cls=${(info?.inputType ?: 0) and 15} " +
                "var=${((info?.inputType ?: 0) shr 4) and 255} restart=$restarting"
        )
        try {
            startInput(info, restarting)
            dbg("start ok sym=$symbols lang=${lang.code}")
        } catch (e: Throwable) {
            dbg("ERROR ${e.javaClass.simpleName}")
            val where = e.stackTrace.firstOrNull { it.className.startsWith("com.materialyou") }
            val msg = "${e.javaClass.simpleName} @ ${where?.fileName}:${where?.lineNumber}"
            prefs.edit().putString("last_error", msg + "\n" + e.stackTraceToString().take(1500)).apply()
            android.widget.Toast.makeText(this, "YouBoard: $msg", android.widget.Toast.LENGTH_LONG).show()
            try {
                if (rootView == null) rebuild()
            } catch (_: Throwable) {
            }
        }
    }

    private fun startInput(info: EditorInfo?, restarting: Boolean) {
        suggestOn = prefs.getBoolean("suggestions", true)
        autocorrectOn = suggestOn && prefs.getBoolean("autocorrect", true)
        suggestionsAllowed = true
        var wantSymbols = symbols
        if (info != null) {
            val cls = info.inputType and InputType.TYPE_MASK_CLASS
            val variation = info.inputType and InputType.TYPE_MASK_VARIATION
            if (cls != InputType.TYPE_CLASS_TEXT) suggestionsAllowed = false
            if (cls == InputType.TYPE_CLASS_TEXT) {
                when (variation) {
                    InputType.TYPE_TEXT_VARIATION_PASSWORD,
                    InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
                    InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
                    InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
                    InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
                    InputType.TYPE_TEXT_VARIATION_URI -> suggestionsAllowed = false
                }
                if ((info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) suggestionsAllowed = false
            }
            if (!restarting) {
                wantSymbols = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
            }
        }
        val act = activeLangs()
        act.forEach { ensureDict(it) }
        val langFixed = lang !in act
        if (langFixed) {
            lang = act[0]
            symbols = false
            word.setLength(0); lastWord = null
        }
        var needRebuild = rootView == null || builtSig != signature() || langFixed
        if (wantSymbols != symbols) {
            symbols = wantSymbols
            needRebuild = true
        }
        if (needRebuild) rebuild() else if (panelKind != null) hidePanel(false)
        if (shift != Shift.CAPS) shift = Shift.OFF
        autoCapIfNeeded()
        refreshShift()
        applyNavBar()
        updateEnterIcon()
        resyncWord()
        captureClip(false)
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        clearInline()
        dbg("FINISH ${dt()} finishing=$finishingInput shown=${isInputViewShown}")
        stopVoice()
        handler.removeCallbacksAndMessages(null)
        word.setLength(0); lastWord = null
        lastCorrection = null
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // Cursor moved or the app changed the text on its own (not through our key presses).
        if (SystemClock.uptimeMillis() - lastOwnEdit > 350) {
            resyncWord()
            if (shift == Shift.OFF) {
                autoCapIfNeeded()
                refreshShift()
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        dbg("config changed")
        if (rootView != null) {
            rebuild()
            applyNavBar()
        }
    }

    private fun tr(ru: String, en: String): String = Loc.t(prefs, ru, en)

    private fun signature(): String =
        "${prefs.getBoolean("number_row", true)}|${prefs.getInt("key_height", 48)}|" +
                "${prefs.getString("yk_enter", "auto")}${prefs.getString("yk_shift", "auto")}${prefs.getString("yk_bksp", "auto")}${prefs.getString("yk_space", "auto")}${prefs.getString("yk_func", "auto")}|" +
                "${prefs.getBoolean("plus", false)}|${prefs.getBoolean("square_mode", false)}|${prefs.getBoolean("suggestions", true)}|" +
                "${prefs.getBoolean("clip_history", true)}|" +
                "${prefs.getBoolean("clip_chip", true)}|${prefs.getBoolean("big_letters", true)}|" +
                "${prefs.getBoolean("voice_enabled", true)}|${LangSwitch.mode(prefs)}|${prefs.getBoolean("lang_switch_all", false)}|" +
                "${prefs.getString(Themes.KEY, "system")}|" +
                "${prefs.getString("kb_langs", "auto")}|${prefs.getString("langs_on", "")}|" +
                "${prefs.getString(Fx.KEY, "none")}|${prefs.getInt("fx_x", 50)}|${prefs.getInt("fx_y", 30)}|${prefs.getInt("fx_size", 70)}|${prefs.getBoolean("space_joystick", false)}|${prefs.getBoolean("plus_shapes", true)}|${prefs.getBoolean("kb_font", false)}|${prefs.getBoolean("hide_emoji_btn", false)}|${prefs.getBoolean("win95", false)}|${prefs.getInt("key_round", -1)}|${BgPhotos.signature(prefs)}|${prefs.getBoolean("one_hand", false)}|${prefs.getString("one_hand_side", "right")}|${prefs.getBoolean("debug_mode", false)}|${prefs.getBoolean("hard_sign_alt", true)}|${prefs.getBoolean("sym_in_123", true)}|" +
                Layouts.signature(prefs) + "|" + KeyEdits.signature(prefs)

    private fun rebuild() {
        dbg("rebuild")
        panelKind = null
        panel = null
        val v = buildKeyboard()
        rootView = v
        builtSig = signature()
        val h = host
        if (h == null) {
            setInputView(v)
            return
        }
        h.removeAllViews()
        val pal = palette
        if (prefs.getBoolean("one_hand", false) && pal != null) {
            // one-handed mode: the keyboard shrinks to one side, a small button on the free side restores it
            val right = prefs.getString("one_hand_side", "right") != "left"
            val w = (resources.displayMetrics.widthPixels * 0.78f).toInt()
            h.addView(v, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, (if (right) Gravity.END else Gravity.START) or Gravity.BOTTOM))
            val back = TextView(this).apply {
                text = "\u2922"
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                setTextColor(pal.onFunction)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(pal.function)
                }
                setOnClickListener {
                    feedback(it)
                    prefs.edit().putBoolean("one_hand", false).apply()
                    rebuild()
                }
            }
            h.addView(back, FrameLayout.LayoutParams(dp(48), dp(48), (if (right) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL).apply {
                setMargins(dp(14), 0, dp(14), 0)
            })
        } else {
            h.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        v.requestApplyInsets()
    }

    private fun applyNavBar() {
        try {
            val w = window?.window ?: return
            w.navigationBarColor = navColor
            WindowCompat.getInsetsController(w, w.decorView).isAppearanceLightNavigationBars =
                ColorUtils.calculateLuminance(navColor) > 0.5
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- building UI

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    /** Material You mode: the user picks a palette role for each main key (yk_* prefs). null = automatic. */
    private fun roleColors(p: Palette, kind: KeyKind): Pair<Int, Int>? {
        if (plus || square) return null
        val key = when (kind) {
            KeyKind.ENTER -> "yk_enter"; KeyKind.SHIFT -> "yk_shift"; KeyKind.BACKSPACE -> "yk_bksp"
            KeyKind.SPACE -> "yk_space"; KeyKind.FUNCTION -> "yk_func"; else -> return null
        }
        return when (prefs.getString(key, "auto")) {
            "primary" -> p.primary to p.onPrimary
            "secondary" -> p.function to p.onFunction
            "tertiary" -> p.tertiary to p.onTertiary
            "neutral" -> p.space to p.onSurfaceVariant
            else -> null
        }
    }

    private fun colorsFor(p: Palette, kind: KeyKind): Pair<Int, Int> = roleColors(p, kind) ?: when (kind) {
        KeyKind.LETTER -> p.letter to p.onSurface
        KeyKind.FUNCTION, KeyKind.SHIFT, KeyKind.BACKSPACE -> p.function to p.onFunction
        KeyKind.SPACE -> if (plus) p.tertiary to p.onTertiary else p.space to p.onSurfaceVariant
        KeyKind.ENTER -> p.primary to p.onPrimary
    }

    private fun pressedColorFor(p: Palette, kind: KeyKind): Int =
        if (roleColors(p, kind) != null) colorsFor(p, kind).let { ColorUtils.blendARGB(it.first, it.second, 0.22f) }
        else if (kind == KeyKind.ENTER) ColorUtils.blendARGB(p.primary, p.onPrimary, 0.25f) else p.pressed

    private fun customFg(bg: Int): Int = if (ColorUtils.calculateLuminance(bg) > 0.5) 0xFF1B1B1F.toInt() else 0xFFFFFFFF.toInt()

    private fun customPressed(bg: Int): Int = ColorUtils.blendARGB(bg, customFg(bg), 0.22f)

    private fun makeKey(
        c: Context,
        p: Palette,
        kind: KeyKind,
        label: String? = null,
        hint: String? = null,
        icon: Int? = null,
        textSp: Float = 22f
    ): Key {
        var (bg, fg) = colorsFor(p, kind)
        val cc = pendingCustom
        if (cc != null) {
            bg = cc
            fg = customFg(cc)
        }
        val density = resources.displayMetrics.density
        val sp = if (kind == KeyKind.LETTER && prefs.getBoolean("big_letters", true)) textSp * 1.3f else textSp
        val ps = if (square) null else pendingShape
        val cookieKey = ps == "cookie"
        val n = if (ps != null) KeyShapes.custom(ps, faceH, density)
        else KeyShapes.normal(kind, plus, faceH, density, square, prefs.getBoolean("plus_shapes", true), KeyShapes.round(prefs))
        val pr = if (ps == null) KeyShapes.pressed(kind, plus, faceH, density, square, prefs.getBoolean("plus_shapes", true), KeyShapes.round(prefs))
        else if (cookieKey) KeyShapes.cookieRadii(true)
        else FloatArray(8) { minOf(n[it] + 8f * density, faceH / 2f) }
        val d = (if (retro) Bevel95(density) else if (cookieKey) CookieDrawable(8, Int.MAX_VALUE) else GradientDrawable()).apply {
            shape = GradientDrawable.RECTANGLE
            setColor(bg)
            cornerRadii = n.copyOf()
        }
        val morph = Morph(d, n, pr, bg, if (cc != null) customPressed(cc) else pressedColorFor(p, kind))

        // root = full touch cell (no dead zones between keys); face = visible rounded key
        val root = FrameLayout(c)
        val face = FrameLayout(c)
        face.background = d
        val flp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        flp.setMargins(dp(2), dp(3), dp(2), dp(3))
        root.addView(face, flp)

        var lbl: TextView? = null
        var ic: ImageView? = null
        if (label != null) {
            lbl = TextView(c).apply {
                text = label
                setTextColor(fg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
                typeface = kbFace()
                gravity = Gravity.CENTER
                includeFontPadding = false
            }
            face.addView(lbl, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        if (icon != null) {
            ic = ImageView(c).apply {
                setImageResource(icon)
                setColorFilter(fg)
            }
            face.addView(ic, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        }
        if (hint != null) {
            val h = TextView(c).apply {
                text = hint
                setTextColor(if (cc != null) fg else p.onSurfaceVariant)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                includeFontPadding = false
            }
            val lp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            )
            lp.setMargins(0, dp(3), dp(6), 0)
            face.addView(h, lp)
        }
        return Key(root, face, lbl, ic, morph)
    }

    private fun setKeyColor(k: Key, color: Int) {
        k.morph.color = color
        if (k.morph.anim?.isRunning != true) {
            k.morph.curColor = color
            k.morph.d.setColor(color)
        }
    }

    private fun charKey(c: Context, p: Palette, ch: String, hint: String?, letter: Boolean, alts: List<String>?): Key {
        val k = makeKey(c, p, KeyKind.LETTER, label = ch, hint = hint)
        if (letter) {
            letterKeys.add(k.label!! to ch)
            letterTargets.add(k to ch)
        }
        val altList = alts ?: emptyList()
        val longAction: (() -> Unit)? = if (altList.size == 1) {
            { replaceLast(altList[0]) }
        } else null
        attachTouch(k, onLong = longAction, alts = if (altList.size > 1) altList else null) {
            typeText(if (letter && shift != Shift.OFF) ch.uppercase() else ch)
        }
        return k
    }

    /** Key for the letter/symbol rows with long-press alternatives. */
    private fun rowKey(c: Context, p: Palette, ch: String, row: Int, index: Int, numberRow: Boolean): Key {
        if (symbols) {
            val m = MATH_ALTS[ch] ?: return charKey(c, p, ch, null, false, null)
            return charKey(c, p, ch, m.take(3), false, m.map { it.toString() })
        }
        val alts = ArrayList<String>()
        if (lang == Langs.RU && ch == "е") alts.add("ё")
        if (lang == Langs.UK && ch == "г") alts.add("ґ")
        if (lang == Langs.UK && ch == "ь") alts.add("'")
        if (lang == Langs.RU && ch == "ь" && prefs.getBoolean("hard_sign_alt", true)) alts.add("ъ")
        lang.alts[ch]?.forEach { alts.add(it.toString()) }
        if (row == 0 && !numberRow && index < 10) alts.add("1234567890"[index].toString())
        return charKey(c, p, ch, if (alts.isEmpty()) null else alts.joinToString("").take(3), true, if (alts.isEmpty()) null else alts)
    }

    private fun buildKeyboard(): View {
        val c = DynamicColors.wrapContextIfAvailable(this, R.style.Theme_KeyboardView)
        viewCtx = c
        retro = prefs.getBoolean("win95", false)
        val p = Palette(c, if (retro) Themes.WIN95 else prefs.getString(Themes.KEY, "system") ?: "system")
        palette = p
        navColor = p.bg
        square = prefs.getBoolean("square_mode", false) || retro
        plus = prefs.getBoolean("plus", false) && !square
        letterKeys.clear()
        letterTargets.clear()
        suggestCells.clear()
        shiftKey = null
        shiftCustom = null
        spaceCustom = null
        pendingCustom = null
        pendingShape = null
        renderedShift = null
        panel = null
        panelKind = null
        clipList = null
        clipBtn = null
        symBtn = null
        altOverlay = null
        menuOverlay = null
        menuKey = null
        inlineSlot = null
        inlineView = null
        quickArrow = null
        micBtn = null
        enterBtn = null

        val keyH = dp(prefs.getInt("key_height", 48))
        faceH = (keyH - dp(6)).toFloat()
        val numberRow = prefs.getBoolean("number_row", true)
        val hardAlt = !symbols && lang == Langs.RU && prefs.getBoolean("hard_sign_alt", true)
        var rows = if (symbols) SYMBOL_ROWS else Layouts.rows(prefs, lang.code)
        if (hardAlt) rows = rows.map { it.replace("ъ", "") }
        val symIn123 = prefs.getBoolean("sym_in_123", true)
        val joyPref = prefs.getBoolean("space_joystick", false) // joystick owns the space bar: no swipe switching
        val allLang = prefs.getBoolean("lang_switch_all", false) && !joyPref // hidden: every switching method at once
        val swipeLang = !joyPref && (allLang || LangSwitch.mode(prefs) == "swipe")
        val globeOn = allLang || LangSwitch.mode(prefs) == "globe"
        val maxKeys = rows.maxOf { it.length }
        val btnMode = !allLang && LangSwitch.mode(prefs) == "button"
        val langKey = btnMode || allLang // the key left of the comma: tap switches language, hold opens emoji
        val showBar = (btnMode && !prefs.getBoolean("hide_emoji_btn", false)) || prefs.getBoolean("suggestions", true) || prefs.getBoolean("clip_history", true) ||
                prefs.getBoolean("clip_chip", true) || prefs.getBoolean("voice_enabled", true)

        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            val fxBg = (if (retro) null else BgPhotos.drawable(this@KeyboardService, prefs, p.bg))
                ?: Fx.drawable(if (retro) "none" else prefs.getString(Fx.KEY, "none"), p.bg, p.primary, prefs.getInt("fx_x", 50) / 100f, prefs.getInt("fx_y", 30) / 100f, prefs.getInt("fx_size", 70) / 100f)
            background = if (square) fxBg else TopRoundDrawable(fxBg, dp(22).toFloat())
            setPadding(dp(4), dp(4), dp(4), dp(6))
            clipChildren = false
            clipToPadding = false
        }
        dbgView = null
        if (prefs.getBoolean("debug_mode", false)) {
            val tv = TextView(c).apply {
                setTextColor(0xFF00E676.toInt())
                setBackgroundColor(0xFF101010.toInt())
                typeface = Typeface.MONOSPACE
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
                setPadding(dp(6), dp(2), dp(6), dp(2))
                maxLines = 6
            }
            dbgView = tv
            root.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            showDbg()
        }
        val basePad = dp(6)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val nav = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            // globe mode: the globe row sits in the navigation-bar zone, level with the system hide-keyboard arrow
            val bottom = if (globeOn) maxOf(dp(9), nav - dp(24)) else basePad + nav
            v.setPadding(dp(4), dp(4), dp(4), bottom)
            insets
        }

        if (showBar) {
            root.addView(buildTopBar(c, p), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))
        }

        val frame = FrameLayout(c).apply {
            clipChildren = false
            clipToPadding = false
        }
        contentFrame = frame
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        keysBox = box
        frame.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val tr = SwipeTrail(c, ColorUtils.setAlphaComponent(p.primary, 220), dp(6).toFloat())
        trail = tr
        frame.addView(tr, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        if (globeOn) {
            val strip = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            strip.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
            val globe = iconButton(c, p, R.drawable.ic_globe, p.onSurfaceVariant) { switchLang() }
            (globe.getChildAt(0) as? ImageView)?.layoutParams =
                FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER)
            globe.setOnLongClickListener {
                imm?.showInputMethodPicker()
                true
            }
            val glp = LinearLayout.LayoutParams(dp(56), ViewGroup.LayoutParams.MATCH_PARENT)
            glp.marginEnd = dp(6)
            strip.addView(globe, glp)
            root.addView(strip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)))
        }

        fun newRow(): LinearLayout {
            val r = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = maxKeys.toFloat()
            }
            box.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, keyH))
            return r
        }

        fun LinearLayout.addKey(k: Key, w: Float) {
            addView(k.root, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w))
        }

        fun LinearLayout.addSpacer(w: Float) {
            addView(View(c), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w))
        }

        val globeMode = (globeOn || swipeLang) && !allLang // language lives elsewhere, so the menu key opens emoji directly

        fun mkMode(): Key {
            val modeKey = makeKey(c, p, KeyKind.FUNCTION, label = if (symbols) "ABC" else "?123", textSp = 15f)
            attachTouch(modeKey, fireOnDown = false) {
                symbols = !symbols
                word.setLength(0); lastWord = null
                rebuild()
            }
            return modeKey
        }

        fun mkMenu(): Key {
            val menuK = if (langKey) makeKey(c, p, KeyKind.FUNCTION, label = lang.code, textSp = 15f)
            else makeKey(c, p, KeyKind.FUNCTION, label = "\uD83D\uDE42", textSp = 20f)
            menuKey = menuK
            attachTouch(menuK, fireOnDown = false, onLong = { if (langKey) showGridPanel("emoji") else imm?.showInputMethodPicker() }) {
                if (langKey) switchLang() else showGridPanel("emoji")
            }
            return menuK
        }

        fun mkSpace(): Key {
            val spaceKey = makeKey(c, p, KeyKind.SPACE, label = if (swipeLang) "\u2039   ${lang.title}   \u203A" else lang.title, textSp = 14f)
            val joy = !swipeLang && prefs.getBoolean("space_joystick", false)
            attachTouch(
                spaceKey, fireOnDown = !swipeLang && !joy,
                onSwipe = if (swipeLang) ({ d: Int -> switchLang(d) }) else null, joystick = joy
            ) { typeText(" ") }
            return spaceKey
        }

        fun mkEnter(): Key {
            val enterKey = makeKey(c, p, KeyKind.ENTER, icon = R.drawable.ic_enter)
            enterBtn = enterKey
            attachTouch(enterKey) { pressEnter() }
            return enterKey
        }

        val edited = !symbols && KeyEdits.active(prefs, lang.code)
        if (edited) {
            // user-edited arrangement (Themes > keyboard editor): order, hidden keys, fixed colours, widths
            val conf = KeyEdits.load(prefs, lang.code)
            val lay = KeyEdits.layout(prefs, lang.code, numberRow, hardAlt)
            for (row in lay.rows) {
                val vis = row.filter { !it.hidden }
                if (vis.isEmpty()) continue
                val sum = vis.sumOf { it.w.toDouble() }.toFloat()
                val pad = if (vis.none { it.id == KeyEdits.SPACE } && sum < lay.maxKeys) (lay.maxKeys - sum) / 2f else 0f
                val r = LinearLayout(c).apply {
                    orientation = LinearLayout.HORIZONTAL
                    weightSum = maxOf(sum + 2f * pad, 0.1f)
                }
                box.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, keyH))
                if (pad > 0f) r.addSpacer(pad)
                for (pk in vis) {
                    val custom = conf?.color?.get(pk.id)
                    pendingCustom = custom
                    pendingShape = conf?.shape?.get(pk.id)
                    val k: Key = when (pk.id) {
                        KeyEdits.SHIFT -> {
                            val sk = makeKey(c, p, KeyKind.SHIFT, icon = R.drawable.ic_shift)
                            attachTouch(sk) { onShiftTap() }
                            shiftKey = sk
                            shiftCustom = custom
                            sk
                        }
                        KeyEdits.BKSP -> {
                            val bs = makeKey(c, p, KeyKind.BACKSPACE, icon = R.drawable.ic_backspace)
                            attachTouch(bs, repeat = true) { backspace() }
                            bs
                        }
                        KeyEdits.MODE -> mkMode()
                        KeyEdits.MENU -> mkMenu()
                        KeyEdits.SPACE -> {
                            spaceCustom = custom
                            mkSpace()
                        }
                        KeyEdits.ENTER -> mkEnter()
                        "," , "." -> charKey(c, p, pk.id, null, false, null)
                        else -> {
                            if (pk.id.length == 1 && pk.id[0].isDigit()) charKey(c, p, pk.id, null, false, null)
                            else {
                                var oi = 0
                                var oj = 0
                                for (i in rows.indices) {
                                    val j = rows[i].indexOf(pk.id)
                                    if (j >= 0) { oi = i; oj = j; break }
                                }
                                rowKey(c, p, pk.id, oi, oj, numberRow)
                            }
                        }
                    }
                    pendingCustom = null
                    pendingShape = null
                    r.addKey(k, pk.w)
                }
                if (pad > 0f) r.addSpacer(pad)
            }
        } else {
        // number row
        if (!symbols && numberRow) {
            val r = newRow()
            "1234567890".forEach { d ->
                r.addKey(charKey(c, p, d.toString(), null, false, null), maxKeys / 10f)
            }
        }

        // letter / symbol rows
        rows.forEachIndexed { i, chars ->
            val r = newRow()
            if (i == 2) {
                val rest = maxKeys - chars.length
                if (!symbols) {
                    val sk = makeKey(c, p, KeyKind.SHIFT, icon = R.drawable.ic_shift)
                    attachTouch(sk) { onShiftTap() }
                    shiftKey = sk
                    r.addKey(sk, rest / 2f)
                } else if (symIn123) {
                    val ek = makeKey(c, p, KeyKind.FUNCTION, label = "=\\<", textSp = 15f)
                    attachTouch(ek, fireOnDown = false) { showGridPanel("sym") }
                    r.addKey(ek, rest / 2f)
                }
                chars.forEachIndexed { idx, ch -> r.addKey(rowKey(c, p, ch.toString(), i, idx, numberRow), 1f) }
                val bs = makeKey(c, p, KeyKind.BACKSPACE, icon = R.drawable.ic_backspace)
                attachTouch(bs, repeat = true) { backspace() }
                r.addKey(bs, if (symbols && !symIn123) rest.toFloat() else rest / 2f)
            } else {
                val pad = (maxKeys - chars.length) / 2f
                if (pad > 0f) r.addSpacer(pad)
                chars.forEachIndexed { idx, ch -> r.addKey(rowKey(c, p, ch.toString(), i, idx, numberRow), 1f) }
                if (pad > 0f) r.addSpacer(pad)
            }
        }

        // bottom row
        val bottom = newRow()
        bottom.addKey(mkMode(), 1.25f)
        bottom.addKey(mkMenu(), 1f)
        bottom.addKey(charKey(c, p, ",", null, false, null), 1f)
        bottom.addKey(mkSpace(), maxKeys - 5.5f)
        bottom.addKey(charKey(c, p, ".", null, false, null), 1f)
        bottom.addKey(mkEnter(), 1.25f)
        }

        refreshShift()
        clearSuggestions()
        updateEnterIcon()
        return root
    }

    /** Top-bar buttons: in Material You + they are cookies in the theme's brightest colour. */
    private fun barCookie() = plus && !square && prefs.getBoolean("plus_shapes", true)

    private fun barTint(p: Palette) = if (barCookie()) p.onPrimary else if (!square) p.onSurface else p.onSurfaceVariant

    @Suppress("ClickableViewAccessibility")
    private fun styleBarButton(b: FrameLayout, p: Palette, active: Boolean = false) {
        if (!barCookie()) {
            if (!square) {
                // without Material You +: a plain gray circle
                val oval = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(p.letter)
                }
                val inset = android.graphics.drawable.InsetDrawable(oval, dp(4), dp(3), dp(4), dp(3))
                b.background = android.graphics.drawable.RippleDrawable(
                    android.content.res.ColorStateList.valueOf(p.pressed), inset, null
                )
                return
            }
            val tv = TypedValue()
            b.context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
            if (tv.resourceId != 0) b.setBackgroundResource(tv.resourceId)
            return
        }
        val d = CookieDrawable(8, dp(36))
        val dark = ColorUtils.blendARGB(p.primary, p.onPrimary, 0.25f)
        val base = if (active) dark else p.primary
        d.setColor(base)
        b.background = d
        var anim: ValueAnimator? = null
        var curC = base
        fun go(down: Boolean) {
            anim?.cancel()
            val fromA = d.amp
            val toA = if (down) 0.15f else 1f
            val fromC = curC
            val toC = if (down) dark else base
            val ev = ArgbEvaluator()
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = if (down) 120L else 320L
                interpolator = if (down) DecelerateInterpolator() else OvershootInterpolator(2.2f)
                addUpdateListener {
                    val f = it.animatedValue as Float
                    d.setAmp(fromA + (toA - fromA) * f)
                    val col = ev.evaluate(f.coerceIn(0f, 1f), fromC, toC) as Int
                    curC = col
                    d.setColor(col)
                }
                start()
            }
        }
        b.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> go(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> go(false)
            }
            false
        }
    }

    private fun iconButton(
        c: Context, p: Palette, res: Int, tint: Int, active: Boolean = false, onClick: () -> Unit
    ): FrameLayout {
        val b = FrameLayout(c)
        styleBarButton(b, p, active)
        val iv = ImageView(c).apply {
            setImageResource(res)
            setColorFilter(if (barCookie()) p.onPrimary else tint)
        }
        b.addView(iv, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        b.setOnClickListener {
            feedback(it)
            onClick()
        }
        return b
    }

    private fun symButton(c: Context, p: Palette): FrameLayout {
        val b = FrameLayout(c)
        styleBarButton(b, p)
        val t = TextView(c).apply {
            text = "\u03A9"
            setTextColor(barTint(p))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = kbFace()
            gravity = Gravity.CENTER
        }
        b.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        b.setOnClickListener {
            feedback(it)
            showGridPanel("sym")
        }
        return b
    }

    private fun buildTopBar(c: Context, p: Palette): View {
        val bar = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val clip = iconButton(c, p, R.drawable.ic_clipboard, barTint(p)) { toggleClipPanel() }
        clipBtn = clip
        bar.addView(clip, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT))
        if (LangSwitch.mode(prefs) == "button" && !prefs.getBoolean("lang_switch_all", false) &&
            !prefs.getBoolean("hide_emoji_btn", false)
        ) {
            val em = FrameLayout(c)
            styleBarButton(em, p)
            em.addView(TextView(c).apply {
                text = "\uD83D\uDE42"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                gravity = Gravity.CENTER
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            em.setOnClickListener {
                feedback(it)
                showGridPanel("emoji")
            }
            bar.addView(em, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT))
        }

        for (i in 0 until 3) {
            val tv = TextView(c).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(p.onSurface)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(8), 0, dp(8), 0)
            }
            tv.setOnClickListener { onSuggestionTap(i) }
            tv.setOnLongClickListener {
                if (chipShown && i == 1) {
                    dismissChip()
                    true
                } else false
            }
            val lp = LinearLayout.LayoutParams(0, dp(34), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            bar.addView(tv, lp)
            suggestCells.add(tv)
        }

        val slot = FrameLayout(c).apply { visibility = View.GONE }
        inlineSlot = slot
        bar.addView(slot, LinearLayout.LayoutParams(0, dp(34), 3f).apply { setMargins(dp(2), 0, dp(2), 0) })

        if (!prefs.getBoolean("sym_in_123", true)) {
            val sym = symButton(c, p)
            symBtn = sym
            bar.addView(sym, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT))
        }

        if (prefs.getBoolean("voice_enabled", true)) {
            val mic = iconButton(c, p, R.drawable.ic_mic, barTint(p)) { toggleVoice() }
            micBtn = mic
            bar.addView(mic, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT))
            if (listening) setListening(true)
        }

        val arrowBtn = FrameLayout(c)
        styleBarButton(arrowBtn, p)
        val ad = ArrowDrawable(if (barCookie()) p.onPrimary else barTint(p), dp(28))
        quickArrow = ad
        arrowBtn.addView(ImageView(c).apply { setImageDrawable(ad) }, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        arrowBtn.setOnClickListener {
            feedback(it)
            toggleQuickPanel()
        }
        bar.addView(arrowBtn, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT))
        return bar
    }

    // ---------------------------------------------------------------- voice input

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var micBtn: FrameLayout? = null
    private var micPulse: ValueAnimator? = null
    private var voicePrefix = ""

    private fun voiceLangTag(): String? = when (prefs.getString("voice_lang", "any")) {
        "ru" -> "ru-RU"
        "uk" -> "uk-UA"
        "en" -> "en-US"
        else -> null
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun toggleVoice() {
        if (listening) {
            try {
                recognizer?.stopListening()
            } catch (_: Exception) {
            }
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this, VoicePermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast(tr("Распознавание речи недоступно на этом устройстве", "Speech recognition is not available on this device"))
            return
        }
        startVoice()
    }

    private fun startVoice() {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(1, 0)?.toString()
        voicePrefix = if (!before.isNullOrEmpty() && !before.last().isWhitespace()) " " else ""
        try {
            val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(voiceListener)
                recognizer = it
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                voiceLangTag()?.let {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, it)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, it)
                }
            }
            setListening(true)
            r.startListening(i)
        } catch (e: Exception) {
            setListening(false)
            toast(tr("Не удалось запустить распознавание", "Could not start speech recognition"))
        }
    }

    private fun stopVoice() {
        if (listening) {
            try {
                recognizer?.cancel()
            } catch (_: Exception) {
            }
            setListening(false)
            clearComposing()
        }
    }

    private fun setListening(on: Boolean) {
        listening = on
        val b = micBtn ?: return
        val p = palette ?: return
        val iv = b.getChildAt(0) as? ImageView ?: return
        micPulse?.cancel()
        micPulse = null
        if (on) {
            iv.setColorFilter(if (barCookie()) p.onPrimary else if (retro) p.onSurface else p.primary)
            micPulse = ValueAnimator.ofFloat(1f, 0.35f).apply {
                duration = 600
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener { iv.alpha = it.animatedValue as Float }
                start()
            }
        } else {
            iv.alpha = 1f
            iv.setColorFilter(barTint(p))
        }
    }

    private fun clearComposing() {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()
        ic.setComposingText("", 1)
        ic.finishComposingText()
    }

    private fun firstResult(b: Bundle?): String =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim() ?: ""

    private val voiceListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = firstResult(partialResults)
            val ic = currentInputConnection ?: return
            if (t.isEmpty()) return
            lastOwnEdit = SystemClock.uptimeMillis()
            ic.setComposingText(voicePrefix + t, 1)
        }

        override fun onResults(results: Bundle?) {
            setListening(false)
            val t = firstResult(results)
            val ic = currentInputConnection ?: return
            lastOwnEdit = SystemClock.uptimeMillis()
            if (t.isEmpty()) {
                clearComposing()
                return
            }
            ic.commitText(voicePrefix + t, 1)
            word.setLength(0); lastWord = null
            lastCorrection = null
            canDoubleSpace = false
            afterTyped(true)
            clearSuggestions()
        }

        override fun onError(error: Int) {
            setListening(false)
            clearComposing()
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    toast(tr("Не расслышал, попробуйте ещё раз", "Didn't catch that, try again"))
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    startActivity(Intent(this@KeyboardService, VoicePermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                SpeechRecognizer.ERROR_CLIENT -> {}
                else -> toast(tr("Ошибка распознавания ($error)", "Recognition error ($error)"))
            }
        }
    }

    // ---------------------------------------------------------------- touch handling

    private fun pressVisual(k: Key, down: Boolean) {
        val m = k.morph
        (m.d as? Bevel95)?.sunken = down
        m.anim?.cancel()
        val toR = if (down) m.p else m.n
        val toC = if (down) m.pressedColor else m.color
        if (!plus) {
            for (i in 0 until 8) m.cur[i] = toR[i]
            m.curColor = toC
            m.d.cornerRadii = m.cur.copyOf()
            m.d.setColor(toC)
            return
        }
        val fromR = m.cur.copyOf()
        val fromC = m.curColor
        val eval = ArgbEvaluator()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = if (down) 80L else 260L
        a.interpolator = if (down) DecelerateInterpolator() else OvershootInterpolator(1.8f)
        a.addUpdateListener { an ->
            val f = an.animatedValue as Float
            for (i in 0 until 8) m.cur[i] = maxOf(0f, fromR[i] + (toR[i] - fromR[i]) * f)
            m.curColor = eval.evaluate(f.coerceIn(0f, 1f), fromC, toC) as Int
            m.d.cornerRadii = m.cur.copyOf()
            m.d.setColor(m.curColor)
        }
        m.anim = a
        a.start()

        val mode = prefs.getString("press_anim", "shrink")
        val dens = resources.displayMetrics.density
        val s = if (!down) 1f else when (mode) {
            "grow" -> 1.08f
            "shrink" -> 0.9f
            else -> 1f
        }
        val ty = if (down && mode == "push") 2.5f * dens else 0f
        val al = if (down && mode == "fade") 0.55f else 1f
        k.face.animate().cancel()
        k.face.animate()
            .scaleX(s).scaleY(s).translationY(ty).alpha(al)
            .setDuration(if (down) 80L else 240L)
            .setInterpolator(if (down) DecelerateInterpolator() else OvershootInterpolator(if (s == 1f) 0f else 2.2f))
            .start()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachTouch(
        k: Key,
        repeat: Boolean = false,
        fireOnDown: Boolean = true,
        onLong: (() -> Unit)? = null,
        alts: List<String>? = null,
        onSwipe: ((Int) -> Unit)? = null,
        joystick: Boolean = false,
        onTap: () -> Unit
    ) {
        val myLetter = letterTargets.firstOrNull { it.first === k }?.second?.lowercase()?.takeIf { it.length == 1 }
        var swAct = false
        var swTravel = 0f
        var swLX = 0f
        var swLY = 0f
        var swX0 = 0f
        var swY0 = 0f
        var shDown = Shift.OFF
        val swSeq = StringBuilder()
        var joyMode = false
        var joyX = 0f
        var joyLabel: CharSequence? = null
        var swiped = false
        var swipeX = 0f
        var longDone = false
        var cancelled = false
        var altMode = false
        var ghost = false
        var downAt = 0L
        val longRun = object : Runnable {
            override fun run() {
                if (repeat) {
                    onTap()
                    handler.postDelayed(this, 45)
                } else if (alts != null) {
                    longDone = true
                    altMode = true
                    feedback(k.root)
                    pressVisual(k, false)
                    showAlts(k, alts)
                } else if (onLong != null) {
                    longDone = true
                    feedback(k.root)
                    pressVisual(k, false)
                    onLong()
                } else if (joystick) {
                    // held long enough: the space bar becomes a cursor joystick
                    longDone = true
                    joyMode = true
                    joyX = lastDownX
                    feedback(k.root)
                    joyLabel = k.label?.text
                    k.label?.text = tr("\u0414\u0436\u043e\u0439\u0441\u0442\u0438\u043a", "Joystick")
                    k.label?.setTextColor(0xFFFFFFFF.toInt())
                    k.morph.pressedColor = JOY_BLUE
                    setKeyColor(k, JOY_BLUE)
                    pressVisual(k, false)
                    joyExpand(k, true)
                }
            }
        }
        k.root.setOnTouchListener { view, ev ->
            if (ghost && ev.actionMasked != MotionEvent.ACTION_DOWN) {
                if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) ghost = false
                return@setOnTouchListener true
            }
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    ghost = false
                    if (prefs.getBoolean("touch_guard", true)) {
                        val dx = ev.rawX - lastDownX
                        val dy = ev.rawY - lastDownY
                        val near = dx * dx + dy * dy < dp(40) * dp(40)
                        // a second touch landing next to the first one within a few ms is the same fat finger
                        if (near && (ev.eventTime - lastDownT) in 0L..45L && lastDownT != 0L) {
                            ghost = true
                            return@setOnTouchListener true
                        }
                    }
                    lastDownT = ev.eventTime
                    lastDownX = ev.rawX
                    lastDownY = ev.rawY
                    downAt = ev.eventTime
                    swiped = false
                    swipeX = ev.rawX
                    longDone = false
                    cancelled = false
                    altMode = false
                    swAct = false
                    swTravel = 0f
                    swSeq.setLength(0)
                    if (myLetter != null) {
                        swSeq.append(myLetter)
                        swLX = ev.rawX
                        swLY = ev.rawY
                        swX0 = ev.rawX
                        swY0 = ev.rawY
                        shDown = shift
                    }
                    if (k !== menuKey) hideMenu()
                    pressVisual(k, true)
                    feedback(view)
                    if (fireOnDown) onTap()
                    if (repeat) {
                        handler.postDelayed(longRun, 400)
                    } else if (onLong != null || alts != null) {
                        handler.postDelayed(longRun, 380)
                    } else if (joystick) {
                        handler.postDelayed(longRun, 2000)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (onSwipe != null && !swiped && !altMode && !longDone &&
                        Math.abs(ev.rawX - swipeX) > dp(40)
                    ) {
                        // horizontal swipe along the key (space bar): the tap is cancelled, the swipe fires on release
                        swiped = true
                        cancelled = true
                        handler.removeCallbacks(longRun)
                        pressVisual(k, false)
                        feedback(view)
                    }
                    if (myLetter != null && !symbols && !altMode && !longDone && !joyMode &&
                        prefs.getBoolean("swipe_typing", true)
                    ) {
                        swTravel += Math.hypot((ev.rawX - swLX).toDouble(), (ev.rawY - swLY).toDouble()).toFloat()
                        swLX = ev.rawX
                        swLY = ev.rawY
                        val hit = letterAtCore(ev.rawX, ev.rawY)
                        if (hit != null) {
                            val c = hit.second.lowercase()
                            if (c.length == 1 && c[0] != swSeq[swSeq.length - 1]) swSeq.append(c[0])
                        }
                        if (!swAct && swSeq.length >= 3 && swTravel > dp(40)) {
                            swAct = true
                            handler.removeCallbacks(longRun)
                            cancelled = true
                            pressVisual(k, false)
                            feedback(view)
                            swipeStart(shDown)
                            trail?.start(swX0, swY0, keysBox?.height ?: 0)
                        }
                        if (swAct) trail?.add(ev.rawX, ev.rawY)
                    }
                    if (swAct) {
                        // swipe typing owns the gesture
                    } else if (joyMode) {
                        val step = dp(12).toFloat()
                        while (ev.rawX - joyX >= step) {
                            joyX += step
                            moveCursor(1)
                        }
                        while (joyX - ev.rawX >= step) {
                            joyX -= step
                            moveCursor(-1)
                        }
                    } else if (altMode) {
                        updateAlts(ev.rawX)
                    } else {
                        val slack = dp(14)
                        if (!cancelled && (ev.x < -slack || ev.x > view.width + slack ||
                                    ev.y < -slack || ev.y > view.height + slack)
                        ) {
                            cancelled = true
                            handler.removeCallbacks(longRun)
                            pressVisual(k, false)
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    if (swAct) {
                        swAct = false
                        val lastHit = letterAt(ev.rawX, ev.rawY)
                        if (lastHit != null) {
                            val c = lastHit.second.lowercase()
                            if (c.length == 1 && c[0] != swSeq[swSeq.length - 1]) swSeq.append(c[0])
                        }
                        pressVisual(k, false)
                        trail?.fade()
                        swipeFinish(swSeq.toString())
                    } else if (joyMode) {
                        endJoystick(k, joyLabel)
                        joyMode = false
                    } else if (altMode) {
                        altMode = false
                        val sel = altValues.getOrNull(altSel)
                        hideAlts()
                        if (sel != null) replaceLast(sel)
                    } else {
                        if (!cancelled && !longDone) pressVisual(k, false)
                        if (!fireOnDown && !longDone && !cancelled) onTap()
                        if (swiped) {
                            swiped = false
                            onSwipe?.invoke(if (ev.rawX >= swipeX) 1 else -1)
                        }
                        // finger slid off the key it landed on: type the key it was released on instead
                        if (cancelled && fireOnDown && !longDone && !repeat &&
                            prefs.getBoolean("touch_guard", true) && ev.eventTime - downAt < 450 &&
                            letterTargets.any { it.first === k }
                        ) {
                            val t = letterAt(ev.rawX, ev.rawY)
                            if (t != null && t.first !== k) {
                                replaceLast(t.second)
                                pressVisual(t.first, true)
                                handler.postDelayed({ pressVisual(t.first, false) }, 90)
                            }
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    swiped = false
                    handler.removeCallbacks(longRun)
                    if (swAct) {
                        swAct = false
                        trail?.fade()
                    }
                    if (joyMode) {
                        endJoystick(k, joyLabel)
                        joyMode = false
                    }
                    if (altMode) {
                        altMode = false
                        hideAlts()
                    }
                    pressVisual(k, false)
                }
            }
            true
        }
    }

    /** Like [letterAt] but only the central part of a key counts, so corners crossed on the way are ignored. */
    private fun letterAtCore(x: Float, y: Float): Pair<Key, String>? {
        val loc = IntArray(2)
        for (t in letterTargets) {
            val r = t.first.root
            r.getLocationOnScreen(loc)
            val ix = r.width * 0.2f
            val iy = r.height * 0.2f
            if (x >= loc[0] + ix && x < loc[0] + r.width - ix && y >= loc[1] + iy && y < loc[1] + r.height - iy) return t
        }
        return null
    }

    /** The swipe has begun: take back the letter that was typed when the finger first touched down. */
    private fun swipeStart(shiftAtDown: Shift) {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()
        ic.deleteSurroundingText(1, 0)
        if (word.isNotEmpty()) word.setLength(word.length - 1)
        shift = shiftAtDown
        renderedShift = null
        refreshShift()
        clearSuggestions()
    }

    private fun swipeFinish(seq: String) {
        val ic = currentInputConnection ?: return
        val d = dicts[lang.code]
        if (d == null || !d.ready) return
        val cands = filt(d.swipe(seq, 10)).take(3).map {
            when (shift) {
                Shift.CAPS -> it.uppercase()
                Shift.ON -> it.replaceFirstChar { c -> c.uppercase() }
                Shift.OFF -> it
            }
        }
        if (cands.isEmpty()) return
        val w = cands[0]
        val before = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
        val lead = if (before.isNotEmpty() && !before[0].isWhitespace() && "([{\"'\u00AB\u201E-\u2014".indexOf(before[0]) < 0) " " else ""
        lastOwnEdit = SystemClock.uptimeMillis()
        ic.commitText("$lead$w ", 1)
        word.setLength(0)
        learnPair(lastWord, w)
        lastWord = norm(w)
        lastCorrection = null
        skipCorrect = null
        canDoubleSpace = true
        lastSpaceTime = SystemClock.uptimeMillis()
        afterTyped(true)
        clearSuggestions()
        if (cands.size >= 2 && suggestCells.size >= 3 && suggestOn && suggestionsAllowed) {
            swipeCommitted = w
            suggestCells[1].text = w
            suggestCells[0].text = cands.getOrNull(1) ?: ""
            suggestCells[2].text = cands.getOrNull(2) ?: ""
            paintSuggestions()
        } else {
            showNext(w)
        }
    }

    private fun moveCursor(dir: Int) {
        lastOwnEdit = SystemClock.uptimeMillis()
        sendDownUpKeyEvents(if (dir > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT)
        handler.postDelayed({
            val v = rootView
            if (v != null) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }, 0)
    }

    private var joyWeight = 0f
    private var joyWeights: FloatArray? = null
    private var joyAnim: ValueAnimator? = null

    /** While the joystick is active the space bar takes the whole bottom row; this grows/shrinks it smoothly. */
    private fun joyExpand(k: Key, on: Boolean) {
        val row = k.root.parent as? LinearLayout ?: return
        val lp = k.root.layoutParams as? LinearLayout.LayoutParams ?: return
        joyAnim?.cancel()
        if (joyWeights == null || joyWeights!!.size != row.childCount) {
            joyWeights = FloatArray(row.childCount) {
                (row.getChildAt(it).layoutParams as? LinearLayout.LayoutParams)?.weight ?: 0f
            }
            joyWeight = lp.weight
        }
        val orig = joyWeights!!
        val total = row.weightSum
        val space = joyWeight
        fun apply(f: Float) {
            for (i in 0 until row.childCount) {
                val ch = row.getChildAt(i)
                val l = ch.layoutParams as? LinearLayout.LayoutParams ?: continue
                if (ch === k.root) {
                    l.weight = space + (total - space) * (1f - f)
                } else {
                    l.weight = orig[i] * f
                    ch.alpha = f
                    ch.visibility = if (f <= 0.001f) View.GONE else View.VISIBLE
                }
                ch.layoutParams = l
            }
        }
        val from = if (on) 1f else 0f
        val to = if (on) 0f else 1f
        apply(from)
        joyAnim = ValueAnimator.ofFloat(from, to).apply {
            duration = if (on) 160L else 240L
            interpolator = DecelerateInterpolator()
            addUpdateListener { apply(it.animatedValue as Float) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    apply(to)
                    if (!on) joyWeights = null
                }
            })
            start()
        }
    }

    private fun endJoystick(k: Key, label: CharSequence?) {
        joyExpand(k, false)
        val p = palette ?: return
        var (bg, fg) = colorsFor(p, KeyKind.SPACE)
        var pc = pressedColorFor(p, KeyKind.SPACE)
        spaceCustom?.let { bg = it; fg = customFg(it); pc = customPressed(it) }
        k.label?.text = label
        k.label?.setTextColor(fg)
        k.morph.pressedColor = pc
        setKeyColor(k, bg)
        pressVisual(k, false)
        // the caret moved: forget the old word and read the new surroundings
        word.setLength(0)
        lastWord = null
        clearSuggestions()
        handler.removeCallbacks(resyncRun)
        handler.postDelayed(resyncRun, 150)
    }

    /** The letter key under a screen point, used to fix a finger that slid onto a neighbouring key. */
    private fun letterAt(x: Float, y: Float): Pair<Key, String>? {
        val loc = IntArray(2)
        for (t in letterTargets) {
            val r = t.first.root
            r.getLocationOnScreen(loc)
            if (x >= loc[0] && x < loc[0] + r.width && y >= loc[1] && y < loc[1] + r.height) return t
        }
        return null
    }

    private fun switchLang(dir: Int = 1) {
        val act = activeLangs()
        val i = act.indexOf(lang).coerceAtLeast(0)
        lang = act[(i + dir + act.size) % act.size]
        symbols = false
        word.setLength(0); lastWord = null
        rebuild()
    }

    /** Small two-button menu above the menu key: emoji and language. */
    private fun toggleMenu(k: Key) {
        if (menuOverlay != null) {
            hideMenu()
            return
        }
        val c = viewCtx ?: return
        val p = palette ?: return
        val frame = contentFrame ?: return
        val ov = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(22).toFloat()
                setColor(p.space)
            }
            elevation = dp(8).toFloat()
        }
        fun chip(label: String, sp: Float, action: () -> Unit) {
            val tv = TextView(c).apply {
                text = label
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
                setTextColor(p.onFunction)
                typeface = kbFace()
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(18).toFloat()
                    setColor(p.function)
                }
            }
            tv.setOnClickListener {
                feedback(it)
                hideMenu()
                action()
            }
            val lp = LinearLayout.LayoutParams(dp(54), dp(44))
            lp.setMargins(dp(2), 0, dp(2), 0)
            ov.addView(tv, lp)
        }
        chip("\uD83D\uDE42", 22f) { showGridPanel("emoji") }
        val actL = activeLangs()
        chip(actL[(actL.indexOf(lang).coerceAtLeast(0) + 1) % actL.size].code, 16f) { switchLang() }
        frame.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ov.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = ov.measuredWidth
        val h = ov.measuredHeight
        val a = IntArray(2)
        val b = IntArray(2)
        k.root.getLocationOnScreen(a)
        frame.getLocationOnScreen(b)
        var x = a[0] - b[0] + k.root.width / 2 - w / 2
        x = x.coerceIn(0, maxOf(0, frame.width - w))
        val y = a[1] - b[1] - h - dp(2)
        ov.translationX = x.toFloat()
        ov.translationY = y.toFloat()
        ov.alpha = 0f
        ov.animate().alpha(1f).setDuration(120).start()
        menuOverlay = ov
    }

    private fun hideMenu() {
        menuOverlay?.let { contentFrame?.removeView(it) }
        menuOverlay = null
    }

    /** Popup with alternatives above a key (hold, slide, release). */
    private fun showAlts(k: Key, alts: List<String>) {
        val c = viewCtx ?: return
        val p = palette ?: return
        val frame = contentFrame ?: return
        hideAlts()
        val ov = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(p.space)
            }
            elevation = dp(8).toFloat()
        }
        altChips.clear()
        for (a in alts) {
            val tv = TextView(c).apply {
                text = a
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                typeface = kbFace()
            }
            ov.addView(tv, LinearLayout.LayoutParams(dp(46), dp(46)))
            altChips.add(tv)
        }
        altValues = alts
        altSel = 0
        frame.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ov.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = ov.measuredWidth
        val h = ov.measuredHeight
        val a = IntArray(2)
        val b = IntArray(2)
        k.root.getLocationOnScreen(a)
        frame.getLocationOnScreen(b)
        var x = a[0] - b[0] + k.root.width / 2 - dp(4) - dp(23)
        x = x.coerceIn(0, maxOf(0, frame.width - w))
        val rootTop = rootView?.let { r ->
            val l = IntArray(2)
            r.getLocationOnScreen(l)
            l[1] - b[1]
        } ?: -dp(40)
        var y = a[1] - b[1] - h - dp(2)
        if (y < rootTop) y = rootTop
        ov.translationX = x.toFloat()
        ov.translationY = y.toFloat()
        altOverlay = ov
        paintAlts()
    }

    private fun paintAlts() {
        val p = palette ?: return
        for ((i, tv) in altChips.withIndex()) {
            if (i == altSel) {
                tv.setTextColor(p.onPrimary)
                tv.background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(14).toFloat()
                    setColor(p.primary)
                }
            } else {
                tv.setTextColor(p.onSurface)
                tv.background = null
            }
        }
    }

    private fun updateAlts(rawX: Float) {
        if (altChips.isEmpty()) return
        var best = 0
        var bestDist = Float.MAX_VALUE
        val loc = IntArray(2)
        for ((i, ch) in altChips.withIndex()) {
            ch.getLocationOnScreen(loc)
            val d = Math.abs(rawX - (loc[0] + ch.width / 2f))
            if (d < bestDist) {
                bestDist = d
                best = i
            }
        }
        if (best != altSel) {
            altSel = best
            paintAlts()
        }
    }

    private fun hideAlts() {
        altOverlay?.let { contentFrame?.removeView(it) }
        altOverlay = null
        altChips.clear()
    }

    private fun feedback(v: View) {
        if (prefs.getBoolean("vibrate", true)) {
            @Suppress("DEPRECATION")
            v.performHapticFeedback(
                HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
        if (prefs.getBoolean("sound", false)) {
            audio?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, -1f)
        }
    }

    // ---------------------------------------------------------------- typing logic

    private fun norm(s: String): String = s.lowercase().replace('ё', 'е')

    private fun typeText(s: String) {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()
        unmark(ic)
        val ch = if (s.length == 1) s[0] else null

        if (ch != null && (ch.isLetter() || (ch == '\'' && word.isNotEmpty()))) {
            ic.commitText(s, 1)
            word.append(ch)
            lastCorrection = null
            skipCorrect = null
            canDoubleSpace = false
            afterTyped(false)
            updateSuggestions()
            return
        }

        if (ch != null && (ch == ' ' || SEPARATORS.indexOf(ch) >= 0)) {
            handleSeparator(ic, s)
            return
        }

        ic.commitText(s, 1)
        word.setLength(0); lastWord = null
        lastCorrection = null
        canDoubleSpace = false
        afterTyped(true)
        clearSuggestions()
    }

    private var scRaw: String? = null
    private var scMap: Map<String, String> = emptyMap()

    /** Text shortcuts: "code=phrase" lines from the settings; a typed code is replaced by its phrase. */
    private fun shortcutFor(w: String): String? {
        if (!prefs.getBoolean("shortcuts_on", true)) return null
        val raw = prefs.getString("shortcuts", "") ?: ""
        if (raw != scRaw) {
            scRaw = raw
            scMap = raw.lines().mapNotNull { line ->
                val i = line.indexOf('=')
                if (i <= 0) null else line.substring(0, i).trim().lowercase() to line.substring(i + 1).trim()
            }.filter { it.first.isNotEmpty() && it.second.isNotEmpty() }.toMap()
        }
        return scMap[w.lowercase()]
    }

    private fun handleSeparator(ic: android.view.inputmethod.InputConnection, sep: String) {
        val now = SystemClock.uptimeMillis()
        val w = word.toString()

        val sc = if (w.isNotEmpty() && !symbols) shortcutFor(w) else null
        if (sc != null) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(w.length, 0)
            ic.commitText(sc + sep, 1)
            ic.endBatchEdit()
            lastCorrection = null
            canDoubleSpace = false
            lastSpaceTime = now
            word.setLength(0)
            lastWord = null
            afterTyped(true)
            clearSuggestions()
            return
        }

        // double space -> ". "
        if (sep == " " && w.isEmpty() && canDoubleSpace && now - lastSpaceTime < 600) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
            ic.endBatchEdit()
            canDoubleSpace = false
            lastCorrection = null
            lastWord = null
            afterTyped(true)
            clearSuggestions()
            return
        }

        val fixed = if (w.isNotEmpty()) autoCorrectFor(w) else null
        if (fixed != null && fixed != w) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(w.length, 0)
            ic.commitText(fixed + sep, 1)
            ic.endBatchEdit()
            lastCorrection = Correction(w, fixed, sep)
            markFix(ic, fixed.length, sep.length)
        } else {
            ic.commitText(sep, 1)
            lastCorrection = null
        }
        canDoubleSpace = sep == " " && w.isNotEmpty()
        lastSpaceTime = now
        word.setLength(0)
        afterTyped(true)
        clearSuggestions()
        if (sep == " " && w.isNotEmpty()) {
            val done = fixed ?: w
            learnPair(lastWord, done)
            lastWord = norm(done)
            showNext(done)
        } else {
            lastWord = null
        }
    }

    private var marked = false
    private val unmarkRun = Runnable { currentInputConnection?.let { unmark(it) } }

    /** Gboard-like feedback: the auto-corrected word is briefly shown as a highlighted (composing) region. */
    private fun markFix(ic: android.view.inputmethod.InputConnection, len: Int, sepLen: Int) {
        try {
            val et = ic.getExtractedText(android.view.inputmethod.ExtractedTextRequest(), 0) ?: return
            val end = et.startOffset + et.selectionEnd - sepLen
            val start = end - len
            if (start < 0 || len <= 0) return
            ic.setComposingRegion(start, end)
            marked = true
            handler.removeCallbacks(unmarkRun)
            handler.postDelayed(unmarkRun, 1600)
        } catch (_: Exception) {
        }
    }

    private fun unmark(ic: android.view.inputmethod.InputConnection) {
        if (!marked) return
        marked = false
        handler.removeCallbacks(unmarkRun)
        ic.finishComposingText()
    }

    private fun autoCorrectFor(w: String): String? {
        if (!autocorrectOn || !suggestionsAllowed || symbols) return null
        if (w.length < 3 || w[0].isUpperCase()) return null
        if (w == skipCorrect) return null
        val lw = norm(w)
        if (userWords.contains(lw)) return null
        val fix: String? = if (suggestFor == w) {
            autoFix
        } else {
            val d = dicts[lang.code]
            if (d == null || !d.ready) null else computeSuggestions(d, w).autoFix
        }
        return fix
    }

    private fun afterTyped(checkCap: Boolean) {
        if (symbols) return
        if (shift == Shift.ON) shift = Shift.OFF
        if (checkCap) autoCapIfNeeded()
        refreshShift()
    }

    private fun autoCapIfNeeded() {
        if (shift == Shift.CAPS) return
        if (!prefs.getBoolean("autocap", true)) return
        val ei = currentInputEditorInfo ?: return
        val caps = currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0
        if (caps != 0) shift = Shift.ON
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        unmark(ic)
        lastOwnEdit = SystemClock.uptimeMillis()

        // right after an auto-correction: undo it and keep what the user typed
        val lc = lastCorrection
        if (lc != null && word.isEmpty()) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(lc.fixed.length + lc.sep.length, 0)
            ic.commitText(lc.original, 1)
            ic.endBatchEdit()
            word.append(lc.original)
            skipCorrect = lc.original
            lastCorrection = null
            canDoubleSpace = false
            updateSuggestions()
            return
        }
        lastCorrection = null
        canDoubleSpace = false

        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
            word.setLength(0); lastWord = null
            clearSuggestions()
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            if (word.isNotEmpty()) {
                word.setLength(word.length - 1)
                updateSuggestions()
            } else {
                // we deleted into earlier text: re-read the current word a moment later
                lastWord = null
                clearSuggestions()
                handler.removeCallbacks(resyncRun)
                handler.postDelayed(resyncRun, 300)
            }
        }
        if (!symbols && word.isEmpty()) {
            if (shift != Shift.CAPS) {
                shift = Shift.OFF
                autoCapIfNeeded()
            }
            refreshShift()
        }
    }

    private fun replaceLast(alt: String) {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()
        val prev = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
        val up = prev.isNotEmpty() && prev[0].isUpperCase()
        ic.beginBatchEdit()
        ic.deleteSurroundingText(1, 0)
        ic.commitText(if (up) alt.uppercase() else alt, 1)
        ic.endBatchEdit()
        if (word.isNotEmpty()) word.setLength(word.length - 1)
        if (alt[0].isLetter()) word.append(if (up) alt.uppercase() else alt)
        lastCorrection = null
        updateSuggestions()
    }

    /** Enter key icon follows the editor action: send, search, done or the plain enter arrow. */
    private fun updateEnterIcon() {
        val iv = enterBtn?.icon ?: return
        val ei = currentInputEditorInfo
        var res = R.drawable.ic_enter
        if (ei != null) {
            val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
            val noAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
            res = when {
                // messengers declare SEND even on multi-line fields, so a check mark ignores the flag
                action == EditorInfo.IME_ACTION_SEND -> R.drawable.ic_check
                // search and done only when Enter really performs the action
                noAction -> R.drawable.ic_enter
                action == EditorInfo.IME_ACTION_SEARCH -> R.drawable.ic_search
                action == EditorInfo.IME_ACTION_DONE -> R.drawable.ic_check
                else -> R.drawable.ic_enter
            }
        }
        iv.setImageResource(res)
    }

    private fun pressEnter() {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()
        val w = word.toString()
        if (w.isNotEmpty()) {
            val fixed = autoCorrectFor(w)
            if (fixed != null && fixed != w) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(w.length, 0)
                ic.commitText(fixed, 1)
                ic.endBatchEdit()
            }
        }
        word.setLength(0); lastWord = null
        lastCorrection = null
        canDoubleSpace = false
        clearSuggestions()
        val ei = currentInputEditorInfo
        if (ei != null) {
            val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
            val noEnterAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
            if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
                return
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        afterTyped(true)
    }

    private fun onShiftTap() {
        val now = SystemClock.uptimeMillis()
        shift = when (shift) {
            Shift.OFF -> Shift.ON
            Shift.ON -> if (now - lastShiftTap < 400) Shift.CAPS else Shift.OFF
            Shift.CAPS -> Shift.OFF
        }
        lastShiftTap = now
        refreshShift()
    }

    private fun refreshShift() {
        if (renderedShift == shift) return
        renderedShift = shift
        val p = palette ?: return
        val up = shift != Shift.OFF
        for ((tv, ch) in letterKeys) {
            val t = if (up) ch.uppercase() else ch
            if (tv.text.toString() != t) tv.text = t
        }
        val k = shiftKey ?: return
        (k.morph.d as? Bevel95)?.sunken = up
        setKeyColor(k, shiftCustom ?: if (retro && up) 0xFFDFDFDF.toInt() else if (up) p.primary else p.function)
        k.icon?.setImageResource(
            when (shift) {
                Shift.OFF -> R.drawable.ic_shift
                Shift.ON -> R.drawable.ic_shift_on
                Shift.CAPS -> R.drawable.ic_caps
            }
        )
        k.icon?.setColorFilter(shiftCustom?.let { customFg(it) } ?: if (up) p.onPrimary else p.onFunction)
    }

    // ---------------------------------------------------------------- suggestions

    /** Keyboard languages in switching order: Russian and/or Ukrainian (by setting or system language), then English. */
    private fun activeLangs(): List<Langs.Def> {
        return Langs.enabled(applicationContext, prefs)
    }

    private fun ensureDict(l: Langs.Def) {
        if (dicts.containsKey(l.code)) return
        val d = WordDict(applicationContext, l.asset ?: "", if (l.builtin) null else Langs.file(applicationContext, l))
        dicts[l.code] = d
        exec.execute {
            try {
                d.load()
            } catch (_: Exception) {
            }
            handler.post { updateSuggestions() }
        }
    }

    private fun resyncWord() {
        val ic = currentInputConnection
        // a late selection callback right after our own space must not wipe the next-word suggestions
        if ((nextShown || swipeCommitted != null) && word.isEmpty() && ic?.getTextBeforeCursor(1, 0)?.toString() == " ") return
        word.setLength(0); lastWord = null
        lastCorrection = null
        if (ic != null && suggestOn && suggestionsAllowed) {
            val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: ""
            val after = ic.getTextAfterCursor(1, 0)?.toString() ?: ""
            if (after.isEmpty() || !after[0].isLetter()) {
                var i = before.length
                while (i > 0 && (before[i - 1].isLetter() || before[i - 1] == '\'')) i--
                var start = before.substring(i)
                while (start.startsWith("'")) start = start.substring(1)
                word.append(start)
            }
        }
        updateSuggestions()
    }

    private fun clearSuggestions() {
        suggestGen++
        suggestFor = null
        autoFix = null
        nextShown = false
        swipeCommitted = null
        for (tv in suggestCells) tv.text = ""
        paintSuggestions()
    }

    private fun updateSuggestions() {
        if (suggestCells.isEmpty()) return
        if (!suggestOn || !suggestionsAllowed || symbols || word.isEmpty()) {
            clearSuggestions()
            return
        }
        val w = word.toString()
        val d = dicts[lang.code]
        if (d == null) {
            clearSuggestions()
            return
        }
        val gen = ++suggestGen
        exec.execute {
            if (gen != suggestGen || !d.ready) return@execute
            val res = try {
                computeSuggestions(d, w)
            } catch (_: Exception) {
                null
            }
            if (res != null) {
                handler.post {
                    if (gen == suggestGen && w == word.toString()) applySuggestions(w, res)
                }
            }
        }
    }

    private fun filtOn() = prefs.getBoolean("profanity_filter", true)

    private fun filt(l: List<String>): List<String> = if (filtOn()) Profanity.clean(l) else l

    private fun matchCase(w: String, s: String): String {
        if (w.length > 1 && w == w.uppercase() && w != w.lowercase()) return s.uppercase()
        if (w.isNotEmpty() && w[0].isUpperCase()) return s.replaceFirstChar { it.uppercase() }
        return s
    }

    private fun computeSuggestions(d: WordDict, w: String): Sugg {
        val lw = norm(w)
        val isName = Names.isName(lw)
        val known = d.contains(lw) || userWords.contains(lw) || isName
        val out = ArrayList<String>()
        var fix: String? = null
        if (isName && w[0].isLowerCase()) {
            val cap = lw.replaceFirstChar { it.uppercase() }
            out.add(cap)
            for (x in filt(d.complete(lw, 8)).take(2)) if (x != lw && !out.contains(x)) out.add(x)
            return Sugg(out, cap)
        } else if (known) {
            out.addAll(filt(d.complete(lw, 8)).take(3))
            if (!out.contains(lw)) {
                if (out.size >= 3) out.removeAt(out.size - 1)
                out.add(lw)
            }
        } else {
            val corr = d.corrections(lw, if (lw.length >= 5) 2 else 1, 8).filter { !filtOn() || !Profanity.bad(it.word) }.take(3)
            val comp = filt(d.complete(lw, 8)).take(2)
            val best = corr.firstOrNull()
            if (best != null) {
                out.add(best.word)
                if (best.dist <= 1 && lw.length >= 4 && (corr.size < 2 || corr[1].dist > best.dist)) fix = best.word
                out.add(lw)
            } else {
                out.add(lw)
            }
            for (cnd in corr.drop(1)) if (out.size < 3 && !out.contains(cnd.word)) out.add(cnd.word)
            for (cnd in comp) if (out.size < 3 && !out.contains(cnd)) out.add(cnd)
        }
        val shown = out.map { if (it == lw) w else matchCase(w, it) }
        return Sugg(shown, fix?.let { matchCase(w, it) })
    }

    private fun applySuggestions(w: String, res: Sugg) {
        suggestFor = w
        autoFix = res.autoFix
        nextShown = false
        swipeCommitted = null
        if (suggestCells.size < 3) return
        suggestCells[1].text = res.list.getOrNull(0) ?: ""
        suggestCells[0].text = res.list.getOrNull(1) ?: ""
        suggestCells[2].text = res.list.getOrNull(2) ?: ""
        paintSuggestions()
    }

    private fun paintSuggestions() {
        if (inlineView != null) return
        val p = palette ?: return
        if (suggestCells.size < 3) return
        val chipText = if (chipShown && liveFresh()) displayClip() else null
        val anyText = suggestCells.withIndex().any { (i, tv) ->
            tv.text.isNotEmpty() && !(i == 1 && chipText != null && tv.text.toString() == chipText)
        }
        val showChip = !anyText && word.isEmpty() && chipActive()
        chipShown = showChip
        val c = viewCtx
        if (showChip && c != null) {
            suggestCells[0].visibility = View.GONE
            suggestCells[2].visibility = View.GONE
            val tv = suggestCells[1]
            tv.visibility = View.VISIBLE
            tv.text = displayClip()
            tv.typeface = kbFace()
            tv.setTextColor(p.onFunction)
            tv.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(p.function)
            }
            val icon = c.getDrawable(if (liveKind == 1) R.drawable.ic_chat else R.drawable.ic_clipboard)?.mutate()
            icon?.setTint(p.onFunction)
            icon?.setBounds(0, 0, dp(20), dp(20))
            tv.setCompoundDrawablesRelative(icon, null, null, null)
            tv.compoundDrawablePadding = dp(10)
            return
        }
        for ((i, tv) in suggestCells.withIndex()) {
            tv.visibility = View.VISIBLE
            tv.setCompoundDrawablesRelative(null, null, null, null)
            val has = tv.text.isNotEmpty()
            val center = i == 1
            tv.typeface = if (center) kbFace()
            else Typeface.create("sans-serif", Typeface.NORMAL)
            if (plus && center && has) {
                tv.setTextColor(p.onFunction)
                tv.background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(18).toFloat()
                    setColor(p.function)
                }
            } else {
                tv.setTextColor(p.onSurface)
                tv.background = null
            }
        }
    }

    private fun onSuggestionTap(i: Int) {
        if (chipShown) {
            pasteLive()
            return
        }
        val ic = currentInputConnection ?: return
        val text = suggestCells.getOrNull(i)?.text?.toString() ?: ""
        if (text.isEmpty()) return
        lastOwnEdit = SystemClock.uptimeMillis()
        val old = swipeCommitted
        if (old != null && word.isEmpty()) {
            // another reading of the swiped word: replace it
            if (text != old) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(old.length + 1, 0)
                ic.commitText("$text ", 1)
                ic.endBatchEdit()
            }
            clearSuggestions()
            lastWord = norm(text)
            showNext(text)
            return
        }
        val w = word.toString()
        if (w.isEmpty()) {
            // next-word suggestion: just continue the sentence
            if (!nextShown) return
            ic.commitText("$text ", 1)
        } else {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(w.length, 0)
            ic.commitText("$text ", 1)
            ic.endBatchEdit()
            // picked the word exactly as typed: remember it so it is not "corrected" again
            if (text == w) {
                userWords.add(norm(w))
                prefs.edit().putStringSet("user_words", HashSet(userWords)).apply()
            }
        }
        word.setLength(0)
        lastCorrection = null
        canDoubleSpace = true
        lastSpaceTime = SystemClock.uptimeMillis()
        afterTyped(true)
        clearSuggestions()
        learnPair(lastWord, text)
        lastWord = norm(text)
        showNext(text)
    }

    // ---------------------------------------------------------------- next-word prediction

    private fun cleanWord(s: String?): String? {
        if (s == null) return null
        val t = norm(s).trim('\'')
        if (t.length < 2 || t.length > 24) return null
        for (ch in t) if (!ch.isLetter() && ch != '\'') return null
        return t
    }

    private fun learnPair(a: String?, b: String) {
        if (!suggestionsAllowed || symbols) return
        val x = cleanWord(a) ?: return
        val y = cleanWord(b) ?: return
        if (x == y) return
        val m = bigrams.getOrPut(x) { HashMap() }
        m[y] = (m[y] ?: 0) + 1
        handler.removeCallbacks(saveBigramsRun)
        handler.postDelayed(saveBigramsRun, 8000)
    }

    private fun showNext(prev: String) {
        if (suggestCells.size < 3 || !suggestOn || !suggestionsAllowed || symbols) return
        val key = cleanWord(prev)
        val out = ArrayList<String>(3)
        if (key != null) {
            bigrams[key]?.entries?.sortedByDescending { it.value }?.forEach {
                if (out.size < 3 && (!filtOn() || !Profanity.bad(it.key))) out.add(it.key)
            }
        }
        val d = dicts[lang.code]
        if (out.size < 3 && d != null && d.ready) {
            for (t in d.top(24)) {
                if (out.size >= 3) break
                if (t.length >= 2 && t != key && !out.contains(t) && (!filtOn() || !Profanity.bad(t))) out.add(t)
            }
        }
        if (out.isEmpty()) return
        val cap = shift != Shift.OFF
        val shown = out.map { if (cap) it.replaceFirstChar { c -> c.uppercase() } else it }
        suggestFor = null
        autoFix = null
        nextShown = true
        suggestCells[1].text = shown.getOrNull(0) ?: ""
        suggestCells[0].text = shown.getOrNull(1) ?: ""
        suggestCells[2].text = shown.getOrNull(2) ?: ""
        paintSuggestions()
    }

    private fun loadBigrams() {
        val raw = prefs.getString("bigrams", null) ?: return
        for (line in raw.split('\n')) {
            val p = line.split(' ')
            if (p.size != 3) continue
            val n = p[2].toIntOrNull() ?: continue
            bigrams.getOrPut(p[0]) { HashMap() }[p[1]] = n
        }
    }

    private fun saveBigrams() {
        var total = bigrams.values.sumOf { it.size }
        if (total > 4000) {
            val it = bigrams.entries.iterator()
            while (it.hasNext()) {
                val e = it.next()
                e.value.entries.removeAll { v -> v.value <= 1 }
                if (e.value.isEmpty()) it.remove()
            }
            total = bigrams.values.sumOf { it.size }
        }
        val sb = StringBuilder()
        for ((a, m) in bigrams) for ((b, n) in m) sb.append(a).append(' ').append(b).append(' ').append(n).append('\n')
        prefs.edit().putString("bigrams", sb.toString().trimEnd('\n')).apply()
    }

    // ---------------------------------------------------------------- panels: clipboard, emoji, symbols

    private fun looksLikeCode(s: String): Boolean {
        val t = s.trim()
        return Regex("^\\d{4,8}$").matches(t) || Regex("^\\d{2,4}[ -]\\d{2,4}$").matches(t)
    }

    private fun liveFresh(): Boolean {
        if (liveClip == null) return false
        val ttl = when (liveKind) {
            1 -> 180000L
            2 -> 60000L
            else -> 600000L
        }
        if (SystemClock.uptimeMillis() - liveTime > ttl) {
            liveClip = null
            return false
        }
        return true
    }

    private fun chipActive(): Boolean = prefs.getBoolean("clip_chip", true) && liveFresh()

    private fun panelLive(): Boolean = liveKind != 0 && liveFresh()

    private fun displayClip(): String {
        val t = liveClip ?: return ""
        val mask = liveKind == 2 || (liveKind == 1 && prefs.getBoolean("clip_mask", true))
        if (mask) return t.trim().take(12).map { if (it.isLetterOrDigit()) '*' else it }.joinToString("")
        return t.replace('\n', ' ').trim()
    }

    private fun pasteLive() {
        val t = liveClip ?: return
        usedClip = t
        liveClip = null
        pasteText(t)
    }

    private fun dismissChip() {
        usedClip = liveClip
        liveClip = null
        clearSuggestions()
    }

    private fun captureClip(fromListener: Boolean = false) {
        val cm = clipboard ?: return
        val clip = (try {
            cm.primaryClip
        } catch (_: Exception) {
            null
        }) ?: return
        if (clip.itemCount == 0) return
        val extras = clip.description.extras
        val sensitive = extras != null && extras.getBoolean("android.content.extra.IS_SENSITIVE", false)
        val t = (try {
            clip.getItemAt(0).coerceToText(this)?.toString()
        } catch (_: Exception) {
            null
        }) ?: return
        if (t.isBlank() || t.length > 5000) return
        val code = looksLikeCode(t)
        val kind = if (code) 1 else if (sensitive) 2 else 0
        // codes and sensitive copies are never written to the saved history
        if (kind == 0 && prefs.getBoolean("clip_history", true)) clipStore.add(t)

        val ts = clip.description.timestamp
        val fresh = if (ts > 0) (System.currentTimeMillis() - ts) in -5000L..600000L else fromListener
        if (fresh && t != usedClip && t != liveClip) {
            liveClip = t
            liveKind = kind
            liveTime = SystemClock.uptimeMillis()
            handler.postDelayed({ if (word.isEmpty()) clearSuggestions() }, 181000L)
        }
        if (panelKind == "clip") fillClipList()
        if (word.isEmpty()) clearSuggestions()
    }

    private fun addLiveRow(list: LinearLayout) {
        val c = viewCtx ?: return
        val p = palette ?: return
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(if (plus) 22 else 14).toFloat()
                setColor(p.tertiary)
            }
            isClickable = true
        }
        val ic = ImageView(c).apply {
            setImageResource(if (liveKind == 1) R.drawable.ic_chat else R.drawable.ic_clipboard)
            setColorFilter(p.onTertiary)
        }
        row.addView(ic, LinearLayout.LayoutParams(dp(22), dp(22)))
        val tv = TextView(c).apply {
            text = displayClip()
            setTextColor(p.onTertiary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = kbFace()
            setPadding(dp(12), 0, 0, 0)
        }
        row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.setOnClickListener {
            feedback(it)
            pasteLive()
            hidePanel(true)
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(3), 0, dp(3))
        list.addView(row, lp)
    }

    private fun toggleClipPanel() {
        if (panelKind == "clip") hidePanel(true) else showClipPanel()
    }

    private fun textButton(c: Context, p: Palette, label: String, onClick: () -> Unit): TextView {
        val tv = TextView(c).apply {
            text = label
            setTextColor(p.primary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = kbFace()
            gravity = Gravity.CENTER
            setPadding(dp(14), 0, dp(14), 0)
        }
        val tvAttr = TypedValue()
        c.theme.resolveAttribute(android.R.attr.selectableItemBackground, tvAttr, true)
        if (tvAttr.resourceId != 0) tv.setBackgroundResource(tvAttr.resourceId)
        tv.setOnClickListener {
            feedback(it)
            onClick()
        }
        return tv
    }

    private fun attachPanel(v: View, kind: String) {
        val frame = contentFrame ?: return
        val box = keysBox ?: return
        panel?.let { frame.removeView(it) }
        panel = v
        panelKind = kind
        // exactly the size of the key area, so the panel never grows the keyboard: long lists just scroll
        val keysH = if (box.height > 0) box.height else dp(230)
        frame.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, keysH))
        box.visibility = View.INVISIBLE
        v.alpha = 0f
        v.translationY = dp(20).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(180).setInterpolator(DecelerateInterpolator()).start()
        tintPanelButtons()
    }

    private var quickArrow: ArrowDrawable? = null
    private var arrowAnim: ValueAnimator? = null

    private fun tintPanelButtons() {
        quickArrow?.let { a ->
            arrowAnim?.cancel()
            val to = if (panelKind == "quick") 1f else 0f
            val from = a.progress
            arrowAnim = ValueAnimator.ofFloat(from, to).apply {
                duration = 220
                addUpdateListener { a.progress = it.animatedValue as Float }
                start()
            }
        }
        val p = palette ?: return
        if (barCookie()) return

        ((clipBtn as? FrameLayout)?.getChildAt(0) as? ImageView)
            ?.setColorFilter(if (panelKind == "clip") p.primary else barTint(p))
        ((symBtn as? FrameLayout)?.getChildAt(0) as? TextView)
            ?.setTextColor(if (panelKind == "sym") p.primary else barTint(p))
    }

    private fun hidePanel(animate: Boolean) {
        val pv = panel
        val frame = contentFrame
        keysBox?.visibility = View.VISIBLE
        panelKind = null
        panel = null
        clipList = null
        tintPanelButtons()
        if (pv == null || frame == null) return
        if (animate) {
            pv.animate().alpha(0f).translationY(dp(20).toFloat()).setDuration(140)
                .withEndAction { frame.removeView(pv) }.start()
        } else {
            frame.removeView(pv)
        }
    }

    // ---------------------------------------------------------------- quick settings panel

    private fun toggleQuickPanel() {
        if (panelKind == "quick") hidePanel(true) else showQuickPanel()
    }

    private fun showQuickPanel() {
        val c = viewCtx ?: return
        val p = palette ?: return
        val painters = mutableListOf<() -> Unit>()
        val panelV = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        fun tile(icon: Int, label: () -> String, on: (() -> Boolean)?, click: () -> Unit): View {
            val box = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(6), dp(6), dp(6), dp(6))
            }
            val ic = ImageView(c).apply { setImageResource(icon) }
            val tx = TextView(c).apply {
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = kbFace()
            }
            box.addView(ic, LinearLayout.LayoutParams(dp(28), dp(28)))
            box.addView(tx, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val paint = {
                val active = on?.invoke() ?: false
                box.background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(20).toFloat()
                    setColor(if (active) p.primary else p.function)
                }
                val fg = if (active) p.onPrimary else p.onFunction
                ic.setColorFilter(fg)
                tx.setTextColor(fg)
                tx.text = label()
            }
            paint()
            painters.add(paint)
            box.setOnClickListener {
                feedback(it)
                click()
                painters.forEach { f -> f() }
            }
            return box
        }

        fun toggle(key: String, def: Boolean, rebuildAfter: Boolean = false) {
            prefs.edit().putBoolean(key, !prefs.getBoolean(key, def)).apply()
            if (rebuildAfter) {
                suggestOn = prefs.getBoolean("suggestions", true)
                autocorrectOn = suggestOn && prefs.getBoolean("autocorrect", true)
                rebuild()
            }
        }

        val tiles = listOf(
            tile(R.drawable.ic_phone, { tr("Одной рукой", "One hand") }, { prefs.getBoolean("one_hand", false) }) {
                prefs.edit().putBoolean("one_hand", !prefs.getBoolean("one_hand", false)).apply()
                rebuild()
            },
            tile(R.drawable.ic_swap, {
                if (prefs.getString("one_hand_side", "right") == "left") tr("Сторона: слева", "Side: left") else tr("Сторона: справа", "Side: right")
            }, null) {
                val left = prefs.getString("one_hand_side", "right") == "left"
                prefs.edit().putString("one_hand_side", if (left) "right" else "left").apply()
                if (prefs.getBoolean("one_hand", false)) rebuild()
            },
            tile(R.drawable.ic_bolt, { tr("Шорткаты", "Shortcuts") }, { prefs.getBoolean("shortcuts_on", true) }) { toggle("shortcuts_on", true) },
            tile(R.drawable.ic_swipe, { tr("Свайп-набор", "Swipe typing") }, { prefs.getBoolean("swipe_typing", true) }) { toggle("swipe_typing", true) },
            tile(R.drawable.ic_bulb, { tr("Подсказки", "Suggestions") }, { prefs.getBoolean("suggestions", true) }) { toggle("suggestions", true, true) },
            tile(R.drawable.ic_settings, { tr("Настройки", "Settings") }, null) {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        )
        for (r in 0 until 2) {
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            for (cI in 0 until 3) {
                row.addView(tiles[r * 3 + cI], LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            panelV.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        attachPanel(panelV, "quick")
    }

    private fun showClipPanel() {
        val c = viewCtx ?: return
        val p = palette ?: return
        val panelV = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        val header = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(2), 0)
        }
        val title = TextView(c).apply {
            text = tr("Буфер обмена", "Clipboard")
            setTextColor(p.onSurface)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = kbFace()
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(
            textButton(c, p, tr("Очистить", "Clear")) {
                clipStore.clearUnpinned()
                fillClipList()
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        header.addView(
            textButton(c, p, "ABC") { hidePanel(true) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        panelV.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))

        val scroll = ScrollView(c).apply { isVerticalScrollBarEnabled = false }
        val list = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(2), dp(6), dp(4))
        }
        scroll.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panelV.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        clipList = list
        attachPanel(panelV, "clip")
        fillClipList()
    }

    private fun fillClipList() {
        val c = viewCtx ?: return
        val p = palette ?: return
        val list = clipList ?: return
        list.removeAllViews()
        val clips = clipStore.load()
        val enabled = prefs.getBoolean("clip_history", true)
        val live = panelLive()
        if (live) addLiveRow(list)
        if (clips.isEmpty() && !live) {
            val tv = TextView(c).apply {
                text = if (enabled) tr("Пока пусто.\nСкопируйте текст, и он появится здесь.", "Nothing here yet.\nCopy some text and it will appear here.")
                else tr("История буфера выключена в настройках.", "Clipboard history is turned off in settings.")
                setTextColor(p.onSurfaceVariant)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(28), dp(16), dp(16))
            }
            list.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        for (clip in clips) {
            val row = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(2), dp(2), dp(2))
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(if (plus) 22 else 14).toFloat()
                    setColor(if (clip.pinned) p.function else p.letter)
                }
                background = bg
                isClickable = true
            }
            val tv = TextView(c).apply {
                text = clip.text
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (clip.pinned) p.onFunction else p.onSurface)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setPadding(0, dp(8), dp(4), dp(8))
            }
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val pin = iconButton(c, p, R.drawable.ic_pin, if (clip.pinned) p.primary else p.onSurfaceVariant, clip.pinned) {
                clipStore.togglePin(clip.text)
                fillClipList()
            }
            pin.alpha = if (clip.pinned || barCookie()) 1f else 0.6f
            row.addView(pin, LinearLayout.LayoutParams(dp(40), dp(40)))
            val del = iconButton(c, p, R.drawable.ic_close, p.onSurfaceVariant) {
                clipStore.remove(clip.text)
                fillClipList()
            }
            row.addView(del, LinearLayout.LayoutParams(dp(40), dp(40)))

            row.setOnClickListener {
                feedback(it)
                pasteText(clip.text)
                hidePanel(true)
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, dp(3), 0, dp(3))
            list.addView(row, lp)
        }
    }

    private fun pasteText(text: String) {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()
        ic.commitText(text, 1)
        word.setLength(0); lastWord = null
        lastCorrection = null
        canDoubleSpace = false
        afterTyped(true)
        clearSuggestions()
    }

    // ---- emoji and special symbols

    private fun split(s: String): List<String> = s.split(" ").filter { it.isNotEmpty() }

    /** Splits pasted text into single emoji (no spaces needed), keeping flags and ZWJ sequences whole. */
    private fun splitEmoji(raw: String): List<String> {
        val out = ArrayList<String>()
        val it = android.icu.text.BreakIterator.getCharacterInstance()
        it.setText(raw)
        var start = it.first()
        var end = it.next()
        while (end != android.icu.text.BreakIterator.DONE) {
            val g = raw.substring(start, end)
            val cp = g.codePointAt(0)
            if (!Character.isWhitespace(cp) && !Character.isLetterOrDigit(cp) && cp != ','.code && cp != ';'.code && g !in out) out.add(g)
            start = end
            end = it.next()
        }
        return out
    }

    private fun emojiCats(): List<Cat> {
        val base = emojiCache ?: run {
            val paint = android.graphics.Paint()
            fun cat(tab: String, s: String) = Cat(tab, split(s).filter { paint.hasGlyph(it) })
            val list = listOf(
                cat("😀", "😀 😃 😄 😁 😆 😅 😂 🤣 🥲 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🫣 🤭 🫢 🤫 🫠 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 ☠️ 👽 👾 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾"),
                cat("👋", "👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦾 🦵 🦶 👂 👃 🧠 👀 👁️ 👅 👄 🫶 🫰 🫱 🫲 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵 🙍 🙎 🙅 🙆 💁 🙋 🧏 🙇 🤦 🤷 💆 💇 🚶 🏃 💃 🕺 👯 🧘"),
                cat("🐶", "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🕷️ 🦂 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦛 🐪 🦒 🐃 🐂 🐄 🐎 🐖 🐏 🐑 🐐 🦌 🐕 🐩 🐈 🐓 🦃 🕊️ 🐇 🐁 🐀 🐿️ 🦔 🌵 🎄 🌲 🌳 🌴 🌱 🌿 ☘️ 🍀 🍁 🍂 🍃 🌺 🌻 🌹 🌷 🌼 🌸 💐 🍄 🌍 🌙 ⭐ 🌟 ✨ ⚡ 🔥 🌈 ☀️ ⛅ ☁️ 🌧️ ❄️ ☃️ 💧 🌊"),
                cat("🍔", "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥒 🌶️ 🌽 🥕 🧄 🧅 🥔 🍠 🥐 🍞 🥖 🧀 🥚 🍳 🥞 🧇 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍘 🍥 🍢 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🌰 🥜 🍯 🥛 ☕ 🍵 🧃 🥤 🍶 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🍾 🍴 🥄"),
                cat("⚽", "⚽ 🏀 🏈 ⚾ 🥎 🎾 🏐 🏉 🎱 🏓 🏸 🥅 🏒 🏑 🏏 ⛳ 🏹 🎣 🥊 🥋 ⛸️ 🎿 🛷 🏂 🏋️ 🤸 ⛹️ 🤺 🏇 🧘 🏄 🏊 🚴 🏆 🥇 🥈 🥉 🏅 🎖️ 🎫 🎟️ 🎪 🎭 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🎻 🎲 ♟️ 🎯 🎳 🎮 🎰 🧩"),
                cat("🚗", "🚗 🚕 🚙 🚌 🚎 🏎️ 🚓 🚑 🚒 🚐 🚚 🚛 🚜 🛵 🏍️ 🚲 🛴 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🚀 🛸 🚁 ⛵ 🚤 🛳️ ⚓ 🚧 ⛽ 🚦 🗺️ 🗿 🗽 🗼 🏰 🏯 🎡 🎢 ⛲ ⛰️ 🏔️ 🗻 🌋 🏕️ 🏖️ 🏝️ 🏠 🏡 🏢 🏥 🏦 🏫 🏭 ⛪ 🕌 🌃 🌆 🌇 🌉 🌌"),
                cat("💡", "⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 🖱️ 💽 💾 📀 📷 📸 📹 🎥 📞 ☎️ 📺 📻 ⏰ ⌛ ⏳ 🔋 🔌 💡 🔦 🕯️ 💸 💵 💴 💶 💷 💰 💳 💎 ⚖️ 🔧 🔨 ⚒️ 🛠️ ⛏️ 🔩 ⚙️ 🧲 🔫 💣 🧨 🔪 🗡️ ⚔️ 🛡️ 🚬 ⚰️ 🔮 📿 💈 🔭 🔬 💊 💉 🩸 🧬 🦠 🧪 🌡️ 🧹 🧺 🧻 🚽 🚿 🛁 🔑 🗝️ 🚪 🛋️ 🛏️ 🧸 🖼️ 🛍️ 🎁 🎈 🎀 🎊 🎉 ✉️ 📦 📬 📝 📁 📅 📌 📎 ✂️ 🔒 🔓 🔔 🔕"),
                cat("❤️", "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💯 💢 💥 💫 💦 💨 💬 💭 💤 ✅ ❌ ❎ ❓ ❔ ❕ ❗ ⭕ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🟥 🟧 🟨 🟩 🟦 🟪 ⬛ ⬜ ▶️ ⏸️ ⏹️ ⏺️ ⏭️ ⏮️ 🔀 🔁 🔄 ➕ ➖ ➗ ✖️ ♾️ ‼️ ⁉️ 〰️ ©️ ®️ ™️ 🔝 🔛 🔜 🆗 🆕 🆒 🆓 🔞 ♻️ ⚠️ ⛔ 🚫 🔰 ⚜️"),
                cat("🏳️", "🏳️ 🏴 🏁 🚩 🇷🇺 🇧🇾 🇺🇦 🇰🇿 🇺🇸 🇬🇧 🇪🇺 🇩🇪 🇫🇷 🇮🇹 🇪🇸 🇵🇱 🇹🇷 🇨🇳 🇯🇵 🇰🇷 🇮🇳 🇧🇷 🇨🇦 🇦🇿 🇦🇲 🇬🇪 🇺🇿 🇲🇩 🇱🇹 🇱🇻 🇪🇪")
            )
            emojiCache = list
            list
        }
        val recent = split(prefs.getString("recent_emoji", "") ?: "")
        val mine = splitEmoji(prefs.getString("my_emoji", "") ?: "")
        return listOf(Cat("🕘", recent), Cat("🛠️", mine)) + base
    }

    private fun symbolCats(): List<Cat> = listOf(
        Cat(tr("Кириллица", "Cyrillic"), split("ё Ё і І ї Ї є Є ґ Ґ ў Ў ң ү ө қ ғ һ ә ӣ ъ Ъ")),
        Cat(tr("Валюты", "Currency"), split("\$ € £ ¥ ₽ ₴ ₸ ₿ ¢ ₹ ₩ ₺ ₪ ₫ ฿ ₦ ₡ ₱ ¤")),
        Cat(tr("Математика", "Math"), split("± × ÷ = ≠ ≈ ≤ ≥ < > ∞ √ ∑ ∏ ∫ ∂ ∆ ∇ ∈ ∉ ⊂ ⊃ ∪ ∩ ∧ ∨ ¬ ∀ ∃ ∅ ° ′ ″ % ‰ ¼ ½ ¾ ⅓ ⅔ ⅛ ² ³ ¹ ⁴ ⁿ ₁ ₂ ₃ ∝ ≡ ≪ ≫ ⊕ ⊗ ⊥ ∥ ∠ ∴ ∵")),
        Cat(tr("Стрелки", "Arrows"), split("← → ↑ ↓ ↔ ↕ ↖ ↗ ↘ ↙ ⇐ ⇒ ⇑ ⇓ ⇔ ⇄ ⇅ ↩ ↪ ↺ ↻ ➔ ➜ ➤ ➡ ⬅ ⬆ ⬇ ▲ ▼ ◀ ▶ ◄ ►")),
        Cat(tr("Пунктуация", "Punctuation"), split("« » „ “ ” ‘ ’ ‹ › … – — ¡ ¿ § ¶ † ‡ • · ※ ‽ № @ # & * ~ ^ | \\ / _ ` ´ ¨ ¦")),
        Cat(tr("Знаки", "Signs"), split("© ® ™ ℗ ℠ ℃ ℉ № ♀ ♂ ⚥ ☮ ☯ ☪ ✝ ☦ ☸ ✡ ☢ ☣ ⚠ ♨ ♻ ☎ ✆ ✉ ✂ ✎ ✓ ✔ ✕ ✖ ✗ ✘ ★ ☆ ♠ ♣ ♥ ♦ ♪ ♫ ♭ ♯ ☀ ☁ ☂ ☃ ☼ ☽ ☾ ✿ ❀ ❁ ❤ ♡ ☺ ☻ ☹")),
        Cat(tr("Греческие", "Greek"), split("α β γ δ ε ζ η θ ι κ λ μ ν ξ ο π ρ σ τ υ φ χ ψ ω Γ Δ Θ Λ Ξ Π Σ Φ Ψ Ω")),
        Cat(tr("Линии", "Lines"), split("─ │ ┌ ┐ └ ┘ ├ ┤ ┬ ┴ ┼ ═ ║ ╔ ╗ ╚ ╝ █ ▓ ▒ ░ ■ □ ▪ ▫ ● ○ ◆ ◇ ◉ ◎")),
        Cat(tr("Латиница", "Latin"), split("à á â ã ä å æ ç è é ê ë ì í î ï ñ ò ó ô õ ö ø œ ù ú û ü ý ÿ ß ð þ ł ń ś ź ż ą ę ć č š ž ř ě ů ő ű ğ ı ş"))
    )

    private fun showGridPanel(kind: String) {
        if (panelKind == kind) {
            hidePanel(true)
            return
        }
        val c = viewCtx ?: return
        val p = palette ?: return
        clipList = null
        val emoji = kind == "emoji"
        val cats = if (emoji) emojiCats() else symbolCats()

        val panelV = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        val header = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tabScroll = android.widget.HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false }
        val tabs = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        tabScroll.addView(tabs, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        header.addView(tabScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        header.addView(
            iconButton(c, p, R.drawable.ic_backspace, p.onSurfaceVariant) { backspace() },
            LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT)
        )
        header.addView(
            textButton(c, p, "ABC") { hidePanel(true) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        panelV.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))

        val scroll = ScrollView(c).apply { isVerticalScrollBarEnabled = false }
        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(4))
        }
        scroll.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panelV.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val tabViews = ArrayList<TextView>()
        fun select(i: Int) {
            for ((j, t) in tabViews.withIndex()) {
                val on = j == i
                t.setTextColor(if (on) p.onFunction else p.onSurfaceVariant)
                t.background = if (on) GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(16).toFloat()
                    setColor(p.function)
                } else null
            }
            fillGrid(grid, cats[i].items, kind)
            scroll.scrollTo(0, 0)
        }
        cats.forEachIndexed { i, cat ->
            val tv = TextView(c).apply {
                text = cat.tab
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, if (emoji) 20f else 14f)
                setPadding(dp(12), 0, dp(12), 0)
                minWidth = dp(40)
            }
            tv.setOnClickListener {
                feedback(it)
                select(i)
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32))
            lp.setMargins(dp(2), 0, dp(2), 0)
            tabs.addView(tv, lp)
            tabViews.add(tv)
        }
        attachPanel(panelV, kind)
        select(if (emoji) cats.indexOfFirst { it.items.isNotEmpty() }.coerceAtLeast(0) else 0)
    }

    private fun fillGrid(grid: LinearLayout, items: List<String>, kind: String) {
        val c = viewCtx ?: return
        val p = palette ?: return
        grid.removeAllViews()
        val emoji = kind == "emoji"
        if (items.isEmpty()) {
            val tv = TextView(c).apply {
                text = tr("Здесь пока пусто. Долгое нажатие на смайл добавляет его в 🛠️", "Nothing here yet. Long-press an emoji to add it to 🛠️")
                setTextColor(p.onSurfaceVariant)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(24), dp(16), dp(16))
            }
            grid.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        val cols = 8
        val ripple = TypedValue()
        c.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, ripple, true)
        var row: LinearLayout? = null
        var count = 0
        for (g in items) {
            if (count % cols == 0) {
                val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
                grid.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
                row = r
            }
            val tv = TextView(c).apply {
                text = g
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, if (emoji) 26f else 22f)
                setTextColor(p.onSurface)
                if (ripple.resourceId != 0) setBackgroundResource(ripple.resourceId)
            }
            tv.setOnClickListener {
                feedback(it)
                pasteText(g)
                if (emoji) addRecent(g)
            }
            if (emoji) tv.setOnLongClickListener {
                feedback(it)
                val cur = splitEmoji(prefs.getString("my_emoji", "") ?: "")
                val has = g in cur
                val next = if (has) cur.filter { x -> x != g } else cur + g
                prefs.edit().putString("my_emoji", next.joinToString(" ")).apply()
                android.widget.Toast.makeText(
                    this, if (has) tr("Убрано из 🛠️", "Removed from 🛠️") else tr("Добавлено в 🛠️", "Added to 🛠️"),
                    android.widget.Toast.LENGTH_SHORT
                ).show()
                true
            }
            row?.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            count++
        }
        while (count % cols != 0) {
            row?.addView(View(c), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            count++
        }
    }

    private fun addRecent(e: String) {
        val cur = split(prefs.getString("recent_emoji", "") ?: "").filter { it != e }
        val next = (listOf(e) + cur).take(32)
        prefs.edit().putString("recent_emoji", next.joinToString(" ")).apply()
    }
}
