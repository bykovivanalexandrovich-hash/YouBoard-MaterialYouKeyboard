# YouBoard 5.0 Prerelease 11

## New in this build
- **Telegram group button** in Control Center: opens the YouBoard group on Telegram (https://t.me/MaterialYouBoard).

## Previous build (Prerelease 10)
- **Settings search.** A search button now sits at the top of the Settings, Themes and Control Center screens. Type a word, tap a result: the right screen opens, the group expands, the screen scrolls to the setting and it flashes.
- Square mode was removed from the hidden settings and turned off for everyone.

## Highlights of 5.0
- **Two keyboard styles:** *Material 3 Expressive* (key shapes, rotating cookies, animations, glow) and *Material You* (a plain keyboard with the colour of each main key chosen from the palette).
- **New Version tab** with a colourful home screen of the installed version, a stretchable sheet and a button to the full update log.
- **Interface editor** in Control Center: reorder and remove bottom bar tabs, reorder and hide setting groups.
- Redesigned Material 3 app: large collapsing bars, collapsible groups, tile rows with monochrome icons, slim bottom bar.
- Static press animations (None, Dim, Push down) and slowly rotating cookies (can be turned off).
- Keyboard colours: System plus your own colours that also colour the app; app theme (System, Light, Dark).
- Keyboard editor: swap, recolour, resize, delete and reshape keys per language.

## Install
Download `YouBoard.apk` below and install it over the old version. Your settings are kept.
