package com.materialyou.keyboard

import android.animation.ValueAnimator
import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors

/** Chevron that turns smoothly: progress 0 = pointing down (closed), 1 = pointing up (open). */
class ArrowDrawable(color: Int, private val size: Int, circle: Int = 0) : Drawable() {
    private val circlePaint: Paint? = if (circle != 0) Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = circle } else null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        this.color = color
    }
    var progress = 0f
        set(v) {
            field = v
            invalidateSelf()
        }

    override fun draw(c: Canvas) {
        val b = bounds
        val cx = b.exactCenterX()
        val cy = b.exactCenterY()
        val s = b.width() * 0.2f
        paint.strokeWidth = b.width() * 0.09f
        circlePaint?.let { c.drawCircle(cx, cy, minOf(b.width(), b.height()) / 2f, it) }
        c.save()
        c.rotate(180f * progress, cx, cy)
        val p = Path().apply {
            moveTo(cx - s, cy - s / 2f)
            lineTo(cx, cy + s / 2f)
            lineTo(cx + s, cy - s / 2f)
        }
        c.drawPath(p, paint)
        c.restore()
    }

    override fun getIntrinsicWidth() = size
    override fun getIntrinsicHeight() = size
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** A round badge with an emoji inside: the icon at the start of a group header. */
class IconBadge(private val emoji: String, color: Int, private val size: Int) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = size * 0.52f
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val cx = b.exactCenterX()
        val cy = b.exactCenterY()
        c.drawCircle(cx, cy, minOf(b.width(), b.height()) / 2f, fill)
        val fm = text.fontMetrics
        c.drawText(emoji, cx, cy - (fm.ascent + fm.descent) / 2f, text)
    }

    override fun getIntrinsicWidth() = size
    override fun getIntrinsicHeight() = size
    override fun setAlpha(alpha: Int) { fill.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { fill.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** Collapsible groups: gray capsule header + the card under it, with animated arrow and expand/collapse. */
object Groups {

    /** Bumped by the interface editor; the app screens rebuild themselves when they see a newer value. */
    fun rev(prefs: SharedPreferences): Long = prefs.getLong("ui_rev", 0L)

    fun idList(prefs: SharedPreferences, key: String): List<Int> =
        (prefs.getString(key, "") ?: "").split(",").mapNotNull { it.toIntOrNull() }

    private class Seg(val idx: Int, val views: List<View>)

    /** Every group of a screen as (original index, title), in layout order. Works on any inflated screen. */
    fun titles(root: View): List<Pair<Int, String>> {
        val out = ArrayList<Pair<Int, String>>()
        var n = 0
        fun walk(v: View) {
            if (v !is ViewGroup) return
            for (i in 0 until v.childCount) {
                val c = v.getChildAt(i)
                if (c is TextView && c.tag == "section") {
                    out.add(n to c.text.toString())
                    n++
                } else walk(c)
            }
        }
        walk(root)
        return out
    }

    /**
     * Applies the user's order and hidden groups of a screen (see the interface editor).
     * Hidden groups stay in the view tree (the screens still find their views by id) but are gone and ignored by [scan].
     */
    fun arrange(act: Activity, prefs: SharedPreferences, screen: String) {
        val order = idList(prefs, "ui_g_$screen")
        val hide = idList(prefs, "ui_gh_$screen").toSet()
        val parents = ArrayList<Pair<ViewGroup, List<Seg>>>()
        var n = 0
        fun walk(v: View) {
            if (v !is ViewGroup) return
            val segs = ArrayList<Seg>()
            var i = 0
            while (i < v.childCount) {
                val c = v.getChildAt(i)
                if (c is TextView && c.tag == "section") {
                    var j = i + 1
                    while (j < v.childCount && v.getChildAt(j) !is MaterialCardView) j++
                    val last = if (j < v.childCount) j else i
                    val idx = (c.getTag(R.id.tag_group_idx) as? Int) ?: n
                    c.setTag(R.id.tag_group_idx, idx)
                    n++
                    segs.add(Seg(idx, (i..last).map { v.getChildAt(it) }))
                    i = last
                } else walk(c)
                i++
            }
            if (segs.isNotEmpty()) parents.add(v to segs)
        }
        walk(act.findViewById(android.R.id.content))
        for ((parent, segs) in parents) {
            for (sg in segs) for (w in sg.views) {
                w.setTag(R.id.tag_group_hidden, if (sg.idx in hide) true else null)
                if (sg.idx in hide) w.visibility = View.GONE
            }
            if (order.isEmpty()) continue
            val sorted = segs.sortedBy { sg -> order.indexOf(sg.idx).let { if (it < 0) 1000 + sg.idx else it } }
            val slotStart = segs.map { it.views.first() }
            val inSeg = HashSet<View>().apply { segs.forEach { addAll(it.views) } }
            val kids = (0 until parent.childCount).map { parent.getChildAt(it) }
            val result = ArrayList<View>()
            var k = 0
            for (c in kids) {
                if (c !in inSeg) result.add(c)
                else if (k < slotStart.size && c === slotStart[k]) {
                    result.addAll(sorted[k].views)
                    k++
                }
            }
            val lps = result.map { it.layoutParams }
            parent.removeAllViews()
            result.forEachIndexed { i2, c -> parent.addView(c, lps[i2]) }
        }
    }

    /** Finds every view tagged "section" in the activity and makes it a collapsible header for the next card. */
    fun scan(act: Activity, prefs: SharedPreferences, key: String) {
        val collapse = prefs.getBoolean("groups_collapse", true)
        val open = (prefs.getString(key, "") ?: "").split(",").mapNotNull { it.toIntOrNull() }.toMutableSet()
        var n = 0
        fun walk(v: View) {
            if (v !is ViewGroup) return
            var i = 0
            while (i < v.childCount) {
                val c = v.getChildAt(i)
                if (c is TextView && c.tag == "section") {
                    var j = i + 1
                    while (j < v.childCount && v.getChildAt(j) !is MaterialCardView) j++
                    val card = v.getChildAt(j)
                    val idx = (c.getTag(R.id.tag_group_idx) as? Int) ?: n
                    n++
                    if (card != null && c.getTag(R.id.tag_group_hidden) != true) {
                        style(c, true)
                        bind(c, card, idx in open, collapse) { isOpen ->
                            if (isOpen) open.add(idx) else open.remove(idx)
                            prefs.edit().putString(key, open.joinToString(",")).apply()
                        }
                    }
                } else walk(c)
                i++
            }
        }
        walk(act.findViewById(android.R.id.content))
    }

    private val icons = listOf(
        R.string.sec_input to "✍️", R.string.sec_langswitch to "🌐", R.string.sec_keys to "⌨️", R.string.sec_clip to "📋",
        R.string.sec_shortcuts to "⚡", R.string.sec_myemoji to "😊", R.string.sec_feedback to "📳", R.string.sec_test to "🧪",
        R.string.sec_theme to "🎨", R.string.sec_fx to "🌈", R.string.sec_bg to "🖼️", R.string.sec_height to "📏",
        R.string.ke_title to "🛠️", R.string.cc_language to "🗣️", R.string.cc_apptheme to "🌓", R.string.cc_kb_langs to "🌍",
        R.string.sec_voice to "🎤"
    )

    fun style(tv: TextView, margins: Boolean) {
        val dm = tv.resources.displayMetrics.density
        val bg = MaterialColors.getColor(tv, com.google.android.material.R.attr.colorPrimaryContainer, 0xFF4F378B.toInt())
        val fg = MaterialColors.getColor(tv, com.google.android.material.R.attr.colorOnPrimaryContainer, 0xFFEADDFF.toInt())
        tv.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 28f * dm
            setColor(bg)
        }
        tv.setTextColor(fg)
        tv.setTypeface(Typeface.DEFAULT_BOLD)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        tv.gravity = Gravity.CENTER_VERTICAL
        tv.setPadding((12 * dm).toInt(), (10 * dm).toInt(), (12 * dm).toInt(), (10 * dm).toInt())
        val label = tv.text.toString()
        val emoji = icons.firstOrNull { tv.context.getString(it.first) == label }?.second
        if (emoji != null) {
            val badge = IconBadge(emoji, MaterialColors.getColor(tv, com.google.android.material.R.attr.colorSurface, 0xFF141218.toInt()), (40 * dm).toInt())
            badge.setBounds(0, 0, badge.intrinsicWidth, badge.intrinsicHeight)
            tv.setCompoundDrawablesRelative(badge, null, null, null)
            tv.compoundDrawablePadding = (14 * dm).toInt()
        }
        if (margins) (tv.layoutParams as? ViewGroup.MarginLayoutParams)?.apply {
            marginStart = 0
            marginEnd = 0
            topMargin = (20 * dm).toInt()
            bottomMargin = (8 * dm).toInt()
        }
    }

    fun bind(header: TextView, target: View, startOpen: Boolean, collapse: Boolean, onToggle: (Boolean) -> Unit) {
        (target.getTag(R.id.tag_group_anim) as? ValueAnimator)?.cancel()
        target.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
        (target.getTag(R.id.tag_group_base) as? Float)?.let { target.alpha = it }
        if (!collapse) {
            header.setCompoundDrawablesRelative(header.compoundDrawablesRelative[0], null, null, null)
            header.setOnClickListener(null)
            header.isClickable = false
            target.visibility = View.VISIBLE
            return
        }
        val dm = header.resources.displayMetrics.density
        val arrow = ArrowDrawable(
            MaterialColors.getColor(header, androidx.appcompat.R.attr.colorPrimary, 0xFFD0BCFF.toInt()),
            (38 * dm).toInt(),
            MaterialColors.getColor(header, com.google.android.material.R.attr.colorSurface, 0xFF141218.toInt())
        )
        arrow.setBounds(0, 0, arrow.intrinsicWidth, arrow.intrinsicHeight)
        arrow.progress = if (startOpen) 1f else 0f
        header.setCompoundDrawablesRelative(header.compoundDrawablesRelative[0], null, arrow, null)
        target.visibility = if (startOpen) View.VISIBLE else View.GONE
        var isOpen = startOpen
        header.setOnClickListener {
            isOpen = !isOpen
            onToggle(isOpen)
            animate(target, arrow, isOpen)
        }
    }

    private fun animate(target: View, arrow: ArrowDrawable, open: Boolean) {
        val running = target.getTag(R.id.tag_group_anim) as? ValueAnimator
        running?.cancel()
        // the resting alpha is remembered once, so a cancelled animation can never leave the card half-transparent
        val base = (target.getTag(R.id.tag_group_base) as? Float) ?: target.alpha.also { target.setTag(R.id.tag_group_base, it) }
        val lp = target.layoutParams
        val a0 = target.alpha
        val a1 = if (open) base else 0f
        val parent = target.parent as? View
        val from: Int
        val to: Int
        if (open) {
            from = if (target.visibility == View.VISIBLE) target.height else 0
            target.visibility = View.VISIBLE
            val w = (parent?.width ?: target.resources.displayMetrics.widthPixels) -
                ((lp as? ViewGroup.MarginLayoutParams)?.let { it.marginStart + it.marginEnd } ?: 0)
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            target.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            to = target.measuredHeight
        } else {
            from = target.height
            to = 0
        }
        val p0 = arrow.progress
        val p1 = if (open) 1f else 0f
        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                lp.height = (from + (to - from) * f).toInt()
                target.layoutParams = lp
                target.alpha = a0 + (a1 - a0) * f
                arrow.progress = p0 + (p1 - p0) * f
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    if (cancelled) return
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                    target.layoutParams = lp
                    target.alpha = base
                    target.visibility = if (open) View.VISIBLE else View.GONE
                    arrow.progress = p1
                }
            })
        }
        target.setTag(R.id.tag_group_anim, anim)
        anim.start()
    }
}
