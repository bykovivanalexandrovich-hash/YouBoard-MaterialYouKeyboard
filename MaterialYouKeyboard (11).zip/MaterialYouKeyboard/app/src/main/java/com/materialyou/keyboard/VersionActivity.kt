package com.materialyou.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.pm.PackageInfoCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton

/**
 * "Version" tab: the home screen of the installed version. Coloured header with the app badge, name and version,
 * a rounded sheet with info tiles and quick links, and a permanent blue button that opens the update log.
 */
class VersionActivity : AppCompatActivity() {
    private var barCtl: BottomBar.Controller? = null
    private var uiRev = 0L
    private lateinit var prefs: SharedPreferences
    private var d = 1f

    private fun dp(v: Int) = (v * d).toInt()
    private fun attr(a: Int, fb: Int) = MaterialColors.getColor(this, a, fb)

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        barCtl?.feed(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        if (Groups.rev(prefs) != uiRev) recreate()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        uiRev = Groups.rev(prefs)

        val top = attr(androidx.appcompat.R.attr.colorPrimary, 0xFF6750A4.toInt())
        val bottom = attr(com.google.android.material.R.attr.colorTertiary, 0xFF7D5260.toInt())
        val onTop = attr(com.google.android.material.R.attr.colorOnPrimary, 0xFFFFFFFF.toInt())
        val surface = attr(com.google.android.material.R.attr.colorSurface, 0xFFFFFBFE.toInt())
        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFF1C1B1F.toInt())
        val onSurfaceVar = attr(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF49454F.toInt())
        val tile = attr(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFFECE6F0.toInt())
        val accent = attr(androidx.appcompat.R.attr.colorPrimary, 0xFF6750A4.toInt())

        // the status bar takes the colour of the header, so the header looks like it reaches the top edge
        @Suppress("DEPRECATION")
        window.statusBarColor = top
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
            ColorUtils.calculateLuminance(top) > 0.5

        val info = packageManager.getPackageInfo(packageName, 0)
        val vName = info.versionName ?: ""
        val vCode = PackageInfoCompat.getLongVersionCode(info).toInt()

        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom))
        }

        // ---------------------------------------------------------------- header
        val hero = FrameLayout(this)
        val heroCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(40), dp(24), dp(40))
        }
        val badge = FrameLayout(this)
        val cookieFill = attr(com.google.android.material.R.attr.colorTertiaryContainer, 0xFFFFD8E4.toInt())
        val cookieText = attr(com.google.android.material.R.attr.colorOnTertiaryContainer, 0xFF31111D.toInt())
        val cookie = CookieDrawable(8).apply { setColor(cookieFill) }
        badge.background = cookie
        badge.addView(TextView(this).apply {
            text = "Aa"
            textSize = 52f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            includeFontPadding = false
            setTextColor(cookieText)
            gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        heroCol.addView(badge, LinearLayout.LayoutParams(dp(132), dp(132)))
        heroCol.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 34f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(onTop)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(20) })
        heroCol.addView(TextView(this).apply {
            text = "v$vName ($vCode)"
            textSize = 16f
            setTextColor(ColorUtils.setAlphaComponent(onTop, 0xD0))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        heroCol.addView(TextView(this).apply {
            text = getString(R.string.ver_copy)
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(onTop)
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(16), dp(28), dp(16))
            background = RippleDrawable(
                ColorStateList.valueOf(ColorUtils.setAlphaComponent(onTop, 0x33)),
                GradientDrawable().apply {
                    cornerRadius = dp(40).toFloat()
                    setColor(ColorUtils.setAlphaComponent(onTop, 0x2E))
                }, null
            )
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("version", "${getString(R.string.app_name)} $vName ($vCode)"))
                Toast.makeText(this@VersionActivity, R.string.ver_copied, Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(24) })
        hero.addView(heroCol, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        hero.addView(android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setColorFilter(onTop)
            scaleType = android.widget.ImageView.ScaleType.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(ColorUtils.setAlphaComponent(onTop, 0x2E))
            }
            setOnClickListener { finish() }
        }, FrameLayout.LayoutParams(dp(48), dp(48)).apply {
            leftMargin = dp(12)
            topMargin = dp(12)
        })

        // ---------------------------------------------------------------- sheet
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(150))
            background = GradientDrawable().apply {
                cornerRadii = floatArrayOf(dp(36).toFloat(), dp(36).toFloat(), dp(36).toFloat(), dp(36).toFloat(), 0f, 0f, 0f, 0f)
                setColor(surface)
            }
        }
        sheet.addView(View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(3).toFloat()
                setColor(ColorUtils.setAlphaComponent(onSurfaceVar, 0x66))
            }
        }, LinearLayout.LayoutParams(dp(44), dp(5)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(14)
        })

        fun infoTile(emoji: String, title: String, value: String): MaterialCardView =
            MaterialCardView(this).apply {
                radius = dp(28).toFloat()
                cardElevation = 0f
                setCardBackgroundColor(tile)
                strokeWidth = 0
                val box = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(20), dp(18), dp(20), dp(18))
                }
                box.addView(TextView(context).apply {
                    text = emoji
                    textSize = 26f
                })
                box.addView(TextView(context).apply {
                    text = title
                    textSize = 20f
                    typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                    setTextColor(onSurface)
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) })
                box.addView(TextView(context).apply {
                    text = value
                    textSize = 14f
                    setTextColor(onSurfaceVar)
                })
                addView(box)
            }

        fun tileRow(a: MaterialCardView, b: MaterialCardView) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.addView(a, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(5) })
            r.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(5) })
            sheet.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }
        tileRow(
            infoTile("🏷️", getString(R.string.ver_t_ver), vName),
            infoTile("🔧", getString(R.string.ver_t_build), vCode.toString())
        )
        tileRow(
            infoTile("🤖", getString(R.string.ver_t_android), "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"),
            infoTile("🎨", getString(R.string.ver_t_color), getString(if (Build.VERSION.SDK_INT >= 31) R.string.ver_color_dyn else R.string.ver_color_std))
        )

        fun sectionLabel(text: String) {
            sheet.addView(TextView(this).apply {
                this.text = text
                textSize = 15f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(onSurfaceVar)
                setPadding(dp(12), dp(14), dp(12), dp(8))
            })
        }

        fun linkCard(vararg rows: Triple<String, String, () -> Unit>) {
            val card = MaterialCardView(this).apply {
                radius = dp(28).toFloat()
                cardElevation = 0f
                setCardBackgroundColor(tile)
                strokeWidth = 0
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            for ((emoji, title, click) in rows) {
                val line = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(20), dp(18), dp(20), dp(18))
                    isClickable = true
                    isFocusable = true
                    background = RippleDrawable(ColorStateList.valueOf(ColorUtils.setAlphaComponent(accent, 0x2A)), null, ColorDrawableMask())
                    setOnClickListener { click() }
                }
                line.addView(TextView(this).apply {
                    text = emoji
                    textSize = 22f
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(dp(36), ViewGroup.LayoutParams.WRAP_CONTENT))
                line.addView(TextView(this).apply {
                    text = title
                    textSize = 17f
                    setTextColor(onSurface)
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12) })
                line.addView(android.widget.ImageView(this).apply {
                    setImageResource(R.drawable.ic_chevron_right)
                    setColorFilter(onSurfaceVar)
                }, LinearLayout.LayoutParams(dp(24), dp(24)))
                col.addView(line)
            }
            card.addView(col)
            sheet.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        sectionLabel(getString(R.string.ver_sec_about))
        linkCard(
            Triple("📜", getString(R.string.ver_fab)) { startActivity(Intent(this, ChangelogActivity::class.java)) },
            Triple("🛠️", getString(R.string.ver_row_editor)) { startActivity(Intent(this, InterfaceEditorActivity::class.java)) }
        )

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(hero, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        column.addView(sheet, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        scroll.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---------------------------------------------------------------- permanent blue update-log button
        val fab = ExtendedFloatingActionButton(this).apply {
            text = getString(R.string.ver_fab)
            setIconResource(R.drawable.ic_log)
            isExtended = true
            backgroundTintList = ColorStateList.valueOf(accent)
            setTextColor(onTop)
            iconTint = ColorStateList.valueOf(onTop)
            setOnClickListener { startActivity(Intent(this@VersionActivity, ChangelogActivity::class.java)) }
        }
        root.addView(fab, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
            marginEnd = dp(16)
            bottomMargin = dp(84)
        })

        setContentView(root)
        barCtl = BottomBar.attach(this, BottomBar.LOG)
    }

    /** Ripple mask that fills the whole row. */
    private class ColorDrawableMask : android.graphics.drawable.ColorDrawable(0xFFFFFFFF.toInt())
}
