package com.materialyou.keyboard

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.PathInterpolator
import android.widget.CompoundButton
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.google.android.material.color.MaterialColors
import com.google.android.material.slider.Slider
import kotlin.math.abs
import kotlin.math.sin

/**
 * Floating, opaque tab bar at the bottom of the app screens: Settings, Control Center, Update log.
 * The highlighted "capsule" flows from the old tab to the new one, and a horizontal swipe on the
 * screen turns to the neighbouring tab. Colours come from the current (light or dark) Material theme.
 */
object BottomBar {
    const val SETTINGS = 0
    const val THEMES = 1
    const val CONTROL = 2
    const val LOG = 3
    const val EXTRA_FROM = "bar_from"

    fun attach(act: Activity, selected: Int): Controller = Controller(act, selected)

    const val ALL = 4
    /** Tabs that can never be removed: Settings (home) and Control Center (holds the interface editor). */
    fun locked(id: Int) = id == SETTINGS || id == CONTROL

    /** Visible tabs in the order chosen in the interface editor. */
    fun order(p: android.content.SharedPreferences): List<Int> {
        val saved = (p.getString("ui_tabs", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }.filter { it in 0 until ALL }.distinct()
        if (saved.isEmpty()) return (0 until ALL).toList()
        val res = saved.toMutableList()
        for (id in 0 until ALL) if (locked(id) && id !in res) res.add(id)
        return res
    }

    class Controller(private val act: Activity, selectedTab: Int) {
        private val order: List<Int> = BottomBar.order(act.getSharedPreferences(KeyboardService.PREFS, android.content.Context.MODE_PRIVATE))
            .let { if (selectedTab in it) it else it + selectedTab }
        /** position of the current tab in the bar */
        private val selected = order.indexOf(selectedTab)
        private val n = order.size
        val view: View
        private val d = act.resources.displayMetrics.density
        private val indicator: View
        private val items = ArrayList<LinearLayout>()
        private val icons = ArrayList<ImageView>()
        private val labels = ArrayList<TextView>()
        private val labelW = IntArray(n)
        private val selFg: Int
        private val fg: Int
        private val ev = ArgbEvaluator()
        private var anim: ValueAnimator? = null
        private var blocked = false
        private lateinit var rowC: LinearLayout   // compact row: only the current tab has a label
        private lateinit var rowX: LinearLayout   // big row: every tab with its label under the icon
        private var expandAmt = 0f                // 0 = compact bar, 1 = big bar
        private var expandedOn = false
        private var lens: LensView? = null
        private var lensCell = 0f
        private var lensAnim: ValueAnimator? = null
        private var expAnim: ValueAnimator? = null
        private var wc = 0                        // size of the compact bar, measured when it starts to grow
        private var hc = 0

        private fun dp(v: Int) = (v * d).toInt()

        /** Width of a tab whose label is [f] (0..1) of the way out: only the icon when closed. */
        private fun itemW(i: Int, f: Float): Int = dp(24) + dp(24) + (f * (dp(6) + labelW[i])).toInt()

        private fun left(i: Int, f: FloatArray): Float {
            var x = dp(2).toFloat()
            for (j in 0 until i) x += itemW(j, f[j]) + dp(4)
            return x
        }

        private fun fractions(active: Int) = FloatArray(n) { if (it == active) 1f else 0f }

        init {
            val host = act.findViewById<ViewGroup>(android.R.id.content)
            fun color(attr: Int, fb: Int) = MaterialColors.getColor(host, attr, fb)
            val surface = color(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF2B2930.toInt())
            val outline = color(com.google.android.material.R.attr.colorOutlineVariant, 0xFF49454F.toInt())
            val selBg = color(com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt())
            selFg = color(com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt())
            fg = color(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())

            val pill = FrameLayout(act).apply {
                setPadding(dp(6), dp(6), dp(6), dp(6))
                elevation = dp(8).toFloat()
            }
            // Liquid glass theme (hidden settings, W.I.P.): the bar becomes liquid glass, otherwise it stays a solid pill
            val liquidOn = Frost.liquid(act.getSharedPreferences(KeyboardService.PREFS, android.content.Context.MODE_PRIVATE))
            val liquidBg = LiquidDrawable({ host.getChildAt(0)?.takeIf { it !== pill } }, surface, dp(40).toFloat(), d, 0.3f)
            pill.background = if (liquidOn) liquidBg else FrostDrawable(
                { null }, null, surface, dp(40).toFloat(), 9f * d,
                outline, dp(1).toFloat(), false, 0xB0, 0xFF
            )
            indicator = View(act).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(20).toFloat()
                    setColor(if (liquidOn) ((selBg and 0x00FFFFFF) or 0x99000000.toInt()) else selBg)
                }
            }
            // fixed size on purpose: a MATCH_PARENT child would stretch the wrap-content bar over the whole screen
            pill.addView(indicator, FrameLayout.LayoutParams(dp(48), dp(40), Gravity.CENTER_VERTICAL or Gravity.START))

            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            rowC = row
            val tabs = listOf(
                Triple(SETTINGS, R.drawable.ic_settings, R.string.tab_settings),
                Triple(THEMES, R.drawable.ic_palette, R.string.tab_themes),
                Triple(CONTROL, R.drawable.ic_tune, R.string.tab_cc_bar),
                Triple(LOG, R.drawable.ic_info, R.string.tab_log_bar)
            )
            for ((pos, tabId) in order.withIndex()) {
                val (_, icon, name) = tabs.first { it.first == tabId }
                val item = LinearLayout(act).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), 0, dp(12), 0)
                    isClickable = true
                    isFocusable = true
                }
                val iv = ImageView(act).apply { setImageResource(icon) }
                item.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
                val tv = TextView(act).apply {
                    text = act.getString(name)
                    typeface = Fonts.wide(context)
                    gravity = Gravity.CENTER_VERTICAL or Gravity.START
                    maxLines = 1
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                }
                labelW[pos] = Math.ceil(tv.paint.measureText(tv.text.toString()).toDouble()).toInt() + dp(2)
                item.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT))
                item.setOnClickListener { if (pos != selected) go(act, tabId, order[selected], pos > selected, false) }
                row.addView(item, LinearLayout.LayoutParams(dp(48), dp(40)).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                })
                items.add(item)
                icons.add(iv)
                labels.add(tv)
            }
            pill.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

            // the big bar (shown after scrolling up): every tab with its name under the icon, it fades in over the compact one
            val cellW = (act.resources.displayMetrics.widthPixels - dp(32) - dp(12)) / n
            val rx = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                alpha = 0f
                visibility = View.INVISIBLE
            }
            val xLabels = ArrayList<TextView>()
            for ((pos, tabId) in order.withIndex()) {
                val (_, icon, name) = tabs.first { it.first == tabId }
                val col = if (pos == selected && !liquidOn) selFg else fg
                val item = LinearLayout(act).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    isClickable = true
                    isFocusable = true
                }
                item.addView(ImageView(act).apply {
                    setImageResource(icon)
                    setColorFilter(col)
                }, LinearLayout.LayoutParams(dp(24), dp(24)))
                val tv = TextView(act).apply {
                    text = act.getString(name)
                    typeface = Fonts.wide(context)
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                    setTextColor(col)
                }
                xLabels.add(tv)
                item.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
                item.setOnClickListener { if (pos != selected) go(act, tabId, order[selected], pos > selected, false) }
                rx.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            }
            // the longest name must fit its cell: shrink the names together when the screen is narrow
            val longest = xLabels.maxOf { it.paint.measureText(it.text.toString()) }
            val room = (cellW - dp(8)).toFloat()
            val labelSp = if (longest > room) (10f * room / longest).coerceAtLeast(7.5f) else 10f
            for (t in xLabels) t.setTextSize(TypedValue.COMPLEX_UNIT_SP, labelSp)
            if (liquidOn) {
                for (i in 0 until rx.childCount) {
                    val it = rx.getChildAt(i)
                    it.setOnClickListener(null)
                    it.isClickable = false
                    it.isFocusable = false
                }
            }
            rowX = rx
            pill.addView(rx, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            lp.setMargins(dp(16), 0, dp(16), dp(12))
            host.addView(pill, lp)
            view = pill
            if (liquidOn && android.os.Build.VERSION.SDK_INT >= 31) {
                val vto = host.viewTreeObserver
                vto.addOnScrollChangedListener(ViewTreeObserver.OnScrollChangedListener { liquidBg.dirty = true; liquidBg.invalidateSelf() })
                vto.addOnGlobalLayoutListener(ViewTreeObserver.OnGlobalLayoutListener { liquidBg.dirty = true; liquidBg.invalidateSelf() })
            }

            // scrolling up and stopping makes the bar big, scrolling down and stopping brings the compact bar back
            val sv = if (liquidOn) null else Frost.scrollOf(host.getChildAt(0))
            if (sv != null) {
                val last = intArrayOf(sv.scrollY)
                val acc = intArrayOf(0)
                host.viewTreeObserver.addOnScrollChangedListener(ViewTreeObserver.OnScrollChangedListener {
                    val y = sv.scrollY
                    val dy = y - last[0]
                    last[0] = y
                    if (dy != 0) {
                        if (acc[0] != 0 && (dy < 0) != (acc[0] < 0)) acc[0] = 0
                        acc[0] += dy
                        // reacts at once: a short pull up opens the big bar, a short pull down closes it
                        if (abs(acc[0]) >= dp(6)) {
                            setExpanded(acc[0] < 0)
                            acc[0] = 0
                        }
                    }
                })
            }

            if (liquidOn) {
                // liquid glass: no compact mode, the bar is always big and a lens marks the tab (it swells while you drag it)
                indicator.visibility = View.GONE
                rowC.alpha = 0f
                rowC.visibility = View.INVISIBLE
                rowX.alpha = 1f
                rowX.visibility = View.VISIBLE
                expandedOn = true
                expandAmt = 1f
                val plp = pill.layoutParams
                plp.width = act.resources.displayMetrics.widthPixels - dp(32)
                plp.height = dp(72)
                pill.layoutParams = plp
                lensCell = (plp.width - dp(12)).toFloat() / n
                val l = LensView(act, { rowX }, surface)
                l.baseW = lensCell - dp(4)
                l.baseH = dp(52).toFloat()
                pill.addView(l, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                l.cx = lensCx(selected)
                lens = l
                pill.isClickable = true
                pill.setOnTouchListener { v, e -> lensTouch(v, e) }
            }

            showState(selected)
            animateFrom(act.intent?.getIntExtra(EXTRA_FROM, selectedTab) ?: selectedTab)
        }

        private fun lensCx(i: Int) = (i + 0.5f) * lensCell

        private val decay = object : Runnable {
            override fun run() {
                val l = lens ?: return
                l.stretch = l.stretch * 0.72f
                if (l.stretch > 0.5f) l.postDelayed(this, 16) else l.stretch = 0f
            }
        }

        private fun lensTo(cxT: Float, g: Float, ms: Long) {
            val l = lens ?: return
            lensAnim?.cancel()
            val x0 = l.cx
            val g0 = l.grow
            val s0 = l.stretch
            val bump = minOf(abs(cxT - x0) * 0.5f, lensCell * 0.7f)
            lensAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = ms
                interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
                addUpdateListener {
                    val t = it.animatedValue as Float
                    l.cx = x0 + (cxT - x0) * t
                    l.grow = g0 + (g - g0) * t
                    l.stretch = s0 * (1f - t) + bump * sin(Math.PI * t).toFloat()
                }
                start()
            }
        }

        private fun lensTouch(v: View, e: MotionEvent): Boolean {
            val l = lens ?: return false
            val half = l.baseW / 2f + dp(2)
            fun at(x: Float) = (x - dp(6)).coerceIn(half, lensCell * n - half)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    l.removeCallbacks(decay)
                    lensTo(at(e.x), 1f, 160)
                }
                MotionEvent.ACTION_MOVE -> {
                    lensAnim?.cancel()
                    l.removeCallbacks(decay)
                    val nx = at(e.x)
                    // the capsule stretches along the finger and relaxes when it stops
                    l.stretch = l.stretch * 0.6f + minOf(abs(nx - l.cx) * 2.5f, dp(46).toFloat()) * 0.4f
                    l.cx = nx
                    l.grow = 1f
                    l.postDelayed(decay, 50)
                }
                MotionEvent.ACTION_UP -> {
                    l.removeCallbacks(decay)
                    val idx = ((e.x - dp(6)) / lensCell).toInt().coerceIn(0, n - 1)
                    lensTo(lensCx(idx), 0f, 260)
                    if (idx != selected) go(act, order[idx], order[selected], idx > selected, false)
                }
                MotionEvent.ACTION_CANCEL -> {
                    l.removeCallbacks(decay)
                    lensTo(lensCx(selected), 0f, 260)
                }
            }
            return true
        }

        /** Back to the compact bar at once (no animation), e.g. when the screen is shown again. */
        fun collapseNow() {
            if (lens != null) return
            expAnim?.cancel()
            if (expandAmt <= 0.001f && !expandedOn) return
            expandedOn = false
            expandAmt = 0f
            rowC.alpha = 1f; rowC.visibility = View.VISIBLE
            rowX.alpha = 0f; rowX.visibility = View.INVISIBLE
            val lp = view.layoutParams
            lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            view.layoutParams = lp
            val ilp = indicator.layoutParams
            ilp.height = dp(40)
            indicator.layoutParams = ilp
            showState(selected)
        }

        /** Grow into the big bar ([on]) or shrink back, smoothly. */
        fun setExpanded(on: Boolean) {
            if (lens != null) return
            if (on == expandedOn) return
            expandedOn = on
            val pill = view as FrameLayout
            expAnim?.cancel()
            if (expandAmt <= 0.001f) {
                wc = pill.width
                hc = pill.height
            }
            if (wc <= 0 || hc <= 0) {
                expandedOn = false
                return
            }
            var cancelled = false
            expAnim = ValueAnimator.ofFloat(expandAmt, if (on) 1f else 0f).apply {
                duration = 180
                interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
                addUpdateListener { applyExpand(it.animatedValue as Float) }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationCancel(animation: android.animation.Animator) {
                        cancelled = true
                    }

                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        if (cancelled || expandedOn) return
                        // back to the plain wrap-content bar
                        val lp = pill.layoutParams
                        lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
                        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                        pill.layoutParams = lp
                        showState(selected)
                    }
                })
                start()
            }
        }

        /** One frame of the growth: [g] 0 = compact bar, 1 = big bar. */
        private fun applyExpand(g: Float) {
            expandAmt = g
            val pill = view as FrameLayout
            val wf = act.resources.displayMetrics.widthPixels - dp(32)
            val hf = dp(72)
            val w = (wc + (wf - wc) * g).toInt()
            val h = (hc + (hf - hc) * g).toInt()
            val lp = pill.layoutParams
            if (lp.width != w || lp.height != h) {
                lp.width = w
                lp.height = h
                pill.layoutParams = lp
            }
            val inner = w - dp(12)
            val off = (inner - (wc - dp(12))) / 2f
            val xc = off + left(selected, fractions(selected))
            val wcI = itemW(selected, 1f).toFloat()
            val cell = inner.toFloat() / n
            val xe = selected * cell + dp(2)
            val we = cell - dp(4)
            val wi = (wcI + (we - wcI) * g).toInt()
            val hi = (dp(40) + (dp(52) - dp(40)) * g).toInt()
            val ilp = indicator.layoutParams
            if (ilp.width != wi || ilp.height != hi) {
                ilp.width = wi
                ilp.height = hi
                indicator.layoutParams = ilp
            }
            indicator.translationX = xc + (xe - xc) * g
            rowC.alpha = (1f - g / 0.6f).coerceIn(0f, 1f)
            rowX.alpha = ((g - 0.4f) / 0.6f).coerceIn(0f, 1f)
            rowC.visibility = if (g >= 0.999f) View.INVISIBLE else View.VISIBLE
            rowX.visibility = if (g <= 0.001f) View.INVISIBLE else View.VISIBLE
        }

        /** Apply label fractions [f] to the tabs: widths, label size and alpha, colours. */
        private fun applyFractions(f: FloatArray) {
            for (i in items.indices) {
                val itm = items[i]
                val lp = itm.layoutParams as LinearLayout.LayoutParams
                lp.width = itemW(i, f[i])
                itm.layoutParams = lp
                val tv = labels[i]
                val tl = tv.layoutParams as LinearLayout.LayoutParams
                tl.width = (f[i] * labelW[i]).toInt()
                tl.marginStart = (dp(6) * f[i]).toInt()
                tv.layoutParams = tl
                tv.alpha = f[i]
                val c = ev.evaluate(f[i].coerceIn(0f, 1f), fg, selFg) as Int
                icons[i].setColorFilter(c)
                tv.setTextColor(c)
            }
        }

        private fun placeIndicator(x: Float, w: Float) {
            val lp = indicator.layoutParams
            if (lp.width != w.toInt()) {
                lp.width = w.toInt()
                indicator.layoutParams = lp
            }
            indicator.translationX = x
        }

        private fun showState(tab: Int) {
            val f = fractions(tab)
            applyFractions(f)
            placeIndicator(left(tab, f), itemW(tab, 1f).toFloat())
        }

        /** Put the capsule on tab [from] and let it flow to the current tab, the label of the old tab folds in while the new one slides out. */
        fun animateFrom(fromTab: Int) {
            val from = order.indexOf(fromTab)
            val lz = lens
            if (lz != null) {
                lensAnim?.cancel()
                if (from in 0 until n && from != selected) {
                    lz.cx = lensCx(from)
                    lz.grow = 0.7f
                    lensTo(lensCx(selected), 0f, 420)
                } else {
                    lz.cx = lensCx(selected)
                    lz.grow = 0f
                }
                return
            }
            anim?.cancel()
            collapseNow()
            if (from == selected || from !in items.indices) {
                showState(selected)
                return
            }
            val fa = fractions(from)
            val fb = fractions(selected)
            val x0 = left(from, fa)
            val w0 = itemW(from, 1f).toFloat()
            val x1 = left(selected, fb)
            val w1 = itemW(selected, 1f).toFloat()
            showState(from)
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 420
                interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
                addUpdateListener {
                    val g = it.animatedValue as Float
                    applyFractions(FloatArray(n) { i -> fa[i] + (fb[i] - fa[i]) * g })
                    val w = w0 + (w1 - w0) * g
                    val cx = (x0 + w0 / 2f) + ((x1 + w1 / 2f) - (x0 + w0 / 2f)) * g
                    // the capsule stretches while it flows, like liquid
                    val ws = w * (1f + 0.22f * sin(Math.PI * g).toFloat())
                    placeIndicator(cx - ws / 2f, ws)
                }
                start()
            }
        }

        // ------------------------------------------------------------ swipe between tabs

        private val detector = GestureDetector(act, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || blocked || view.visibility != View.VISIBLE) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(vx) < 700 || abs(dx) < dp(70) || abs(dx) < abs(dy) * 1.8f) return false
                val next = selected + if (dx < 0) 1 else -1
                if (next !in 0 until n) return false
                go(act, order[next], order[selected], next > selected, true)
                return true
            }
        })

        /** Call from Activity.dispatchTouchEvent. Never consumes the event. */
        fun feed(ev: MotionEvent) {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                val root = act.window.decorView
                var v: View? = hit(root, ev.rawX.toInt(), ev.rawY.toInt())
                blocked = false
                while (v != null) {
                    if (v is GlowPad || v is Slider || v is SeekBar || v is HorizontalScrollView || v is CompoundButton) {
                        blocked = true
                        break
                    }
                    v = v.parent as? View
                }
            }
            detector.onTouchEvent(ev)
        }

        private fun hit(v: View, x: Int, y: Int): View? {
            if (v.visibility != View.VISIBLE) return null
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            if (x < loc[0] || x >= loc[0] + v.width || y < loc[1] || y >= loc[1] + v.height) return null
            if (v is ViewGroup) for (i in v.childCount - 1 downTo 0) hit(v.getChildAt(i), x, y)?.let { return it }
            return v
        }
    }

    @Suppress("DEPRECATION")
    private fun go(act: Activity, tab: Int, from: Int, forward: Boolean, swipe: Boolean) {
        val target = when (tab) {
            SETTINGS -> MainActivity::class.java
            THEMES -> ThemesActivity::class.java
            CONTROL -> ControlCenterActivity::class.java
            else -> VersionActivity::class.java
        }
        val i = Intent(act, target).putExtra(EXTRA_FROM, from)
        if (tab == SETTINGS) i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        act.startActivity(i)
        if (tab != SETTINGS && act !is MainActivity) act.finish()
        if (swipe) {
            if (forward) act.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            else act.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        } else {
            act.overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
        }
    }
}
