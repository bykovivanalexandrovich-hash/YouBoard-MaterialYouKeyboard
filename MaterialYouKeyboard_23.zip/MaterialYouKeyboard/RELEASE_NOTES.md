# YouBoard 5.3

## New in this build
- Keyboard editor: a corner radius slider for every key, from square to a full pill.
- The top bar and the bottom tab bar are light frosted glass (blur on Android 12+). It can be turned off in Control Center, "Blur panels".
- Themes: "Own background colour" with a colour row. It turns the photo background off.

## Previous build (5.2)
- Key preview: a big round bubble with the letter above the pressed key, like in Gboard.

## Install
Download `YouBoard.apk` below and install it over the old version.
