# YouBoard 5.1

## New in this build
- Loading indicator redesigned as a Material 3 Expressive wavy ring: a rounded sine wave that grows, shrinks and keeps running around a smooth track.
- Fewer typing mistakes: autocorrect is more careful. It only fixes words of 4+ letters and only when there is a single clear candidate.

## Highlights of 5.0
- Two keyboard styles: Material You and Material 3 Expressive.
- Interface editor, settings search, Version screen, Telegram group button.
- Wide bold app font with an optional switch for the keyboard.

## Install
Download `YouBoard.apk` below and install it over the old version.
