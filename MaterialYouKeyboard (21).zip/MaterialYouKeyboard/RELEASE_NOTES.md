# YouBoard 5.1.1_3

## New in this build
- New "R" button at the top right of the Version screen (opposite the back arrow). It adapts to the colours of the screen and opens the release history from 1.0 to 5.0 as colourful cards, now with the real changes of each version.

## Previous build (5.1)
- Wavy loading indicator and more careful autocorrect.

## Install
Download `YouBoard.apk` below and install it over the old version.
