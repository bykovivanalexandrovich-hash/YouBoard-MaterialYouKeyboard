package com.materialyou.keyboard

import android.animation.ValueAnimator
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.color.MaterialColors

/** The Material You + card (switch, cookie bar and key preview); lives in the Themes tab. */
class PlusCard(private val a: AppCompatActivity, private val prefs: SharedPreferences) {

    private fun <T : View> findViewById(id: Int): T = a.findViewById(id)
    private val resources get() = a.resources
    private fun getString(id: Int) = a.getString(id)
    private val layoutInflater get() = a.layoutInflater

    private class PreviewKey(
        val view: TextView, val kind: KeyKind, val d: GradientDrawable, val cur: FloatArray,
        val bgI: Int, val fgI: Int
    )

    private val previewKeys = ArrayList<PreviewKey>()
    private var previewH = 0f
    private var dynamicColors = IntArray(8)

    /** Material 3 Expressive = everything on; Material You = plain keys with coloured main keys. */
    private fun expressive() = prefs.getBoolean("plus", false) && !prefs.getBoolean("square_mode", false)

    private var youBox: LinearLayout? = null
    private var styleGroup: com.google.android.material.button.MaterialButtonToggleGroup? = null
    private var arrowBox: FrameLayout? = null

    private fun showMode() {
        val ex = expressive()
        findViewById<TextView>(R.id.plus_level_text).text = getString(if (ex) R.string.plus_l3 else R.string.plus_l1)
        findViewById<TextView>(R.id.plus_level_sub).text = getString(if (ex) R.string.plus_l3_s else R.string.plus_l1_s)
        youBox?.visibility = if (ex) View.GONE else View.VISIBLE
        arrowBox?.visibility = if (ex) View.VISIBLE else View.GONE
        if (!ex) findViewById<LinearLayout>(R.id.plus_adv).visibility = View.GONE
    }

    private fun applyMode(ex: Boolean) {
        prefs.edit().putBoolean("plus", ex).apply()
        showMode()
        repaint()
        animatePreview(ex)
    }

    // main-key colours of the Material You mode
    private fun roleIdx(role: String?): Pair<Int, Int>? = when (role) {
        "primary" -> 6 to 7
        "secondary" -> 2 to 3
        "tertiary" -> 4 to 5
        "neutral" -> 0 to 1
        else -> null
    }

    private fun prefKey(kind: KeyKind): String? = when (kind) {
        KeyKind.ENTER -> "yk_enter"; KeyKind.SHIFT -> "yk_shift"; KeyKind.BACKSPACE -> "yk_bksp"
        KeyKind.SPACE -> "yk_space"; KeyKind.FUNCTION -> "yk_func"; else -> null
    }

    private fun idxFor(kind: KeyKind): Pair<Int, Int> {
        val ex = expressive()
        val base = when (kind) {
            KeyKind.LETTER -> 0 to 1
            KeyKind.SHIFT, KeyKind.BACKSPACE -> 2 to 3
            KeyKind.SPACE -> if (ex) 4 to 5 else 0 to 1
            KeyKind.ENTER -> 6 to 7
            else -> 2 to 3
        }
        if (ex) return base
        return prefKey(kind)?.let { roleIdx(prefs.getString(it, "auto")) } ?: base
    }

    private fun buildStyleBox() {
        val box = findViewById<LinearLayout>(R.id.style_box)
        val dm = resources.displayMetrics.density
        val square = prefs.getBoolean("square_mode", false)
        box.removeAllViews()

        // two modes
        val group = com.google.android.material.button.MaterialButtonToggleGroup(a).apply {
            isSingleSelection = true
            isSelectionRequired = true
        }
        val idYou = View.generateViewId()
        val idEx = View.generateViewId()
        for ((id, res) in listOf(idYou to R.string.plus_l1, idEx to R.string.plus_l3)) {
            group.addView(com.google.android.material.button.MaterialButton(a, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                this.id = id
                text = getString(res)
                setAllCaps(false)
                maxLines = 2
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        group.check(if (expressive()) idEx else idYou)
        group.isEnabled = !square
        for (i in 0 until group.childCount) group.getChildAt(i).isEnabled = !square
        group.addOnButtonCheckedListener { _, checked, isChecked ->
            if (isChecked) applyMode(checked == idEx)
        }
        styleGroup = group
        box.addView(group, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Material You mode: colours of the main keys
        val you = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        you.addView(TextView(a).apply {
            text = getString(R.string.yk_title)
            textSize = 15f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(color(box, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt()))
            setPadding(0, (16 * dm).toInt(), 0, (2 * dm).toInt())
        })
        val roles = listOf(
            "auto" to R.string.yk_auto, "primary" to R.string.yk_primary, "secondary" to R.string.yk_secondary,
            "tertiary" to R.string.yk_tertiary, "neutral" to R.string.yk_neutral
        )
        val keys = listOf(
            "yk_enter" to R.string.yk_enter, "yk_shift" to R.string.yk_shift, "yk_bksp" to R.string.yk_bksp,
            "yk_space" to R.string.yk_space, "yk_func" to R.string.yk_func
        )
        for ((pk, nameRes) in keys) {
            you.addView(TextView(a).apply {
                text = getString(nameRes)
                textSize = 13f
                setTextColor(color(box, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFFCAC4D0.toInt()))
                setPadding(0, (8 * dm).toInt(), 0, 0)
            })
            val cur = prefs.getString(pk, "auto")
            val chips = com.google.android.material.chip.ChipGroup(a).apply {
                isSingleSelection = true
                isSelectionRequired = true
            }
            for ((role, res) in roles) {
                chips.addView(com.google.android.material.chip.Chip(a).apply {
                    text = getString(res)
                    id = View.generateViewId()
                    isCheckable = true
                    isChecked = role == cur
                    setOnClickListener {
                        prefs.edit().putString(pk, role).apply()
                        repaint()
                    }
                })
            }
            you.addView(chips)
        }
        youBox = you
        box.addView(you, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        showMode()
    }

    private fun isDark(): Boolean =
        (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES

    /** letter, onSurface, function, onFunction, tertiary, onTertiary, primary, onPrimary */
    private fun previewColors(): IntArray {
        val t = Themes.colors(prefs.getString(Themes.KEY, "system") ?: "system", isDark()) ?: return dynamicColors
        return intArrayOf(t.space, t.onSurface, t.function, t.onFunction, t.tertiary, t.onTertiary, t.primary, t.onPrimary)
    }

    fun repaint() {
        if (previewKeys.isEmpty()) return
        paintBar()
        val cols = previewColors()
        for (k in previewKeys) {
            val (b, f) = idxFor(k.kind)
            k.d.setColor(cols[b])
            k.view.setTextColor(cols[f])
        }
    }

    // ------------------------------------------------------------ keyboard style

    private fun color(v: View, attr: Int, fallback: Int): Int = MaterialColors.getColor(v.context, attr, fallback)

    fun setup() {
        val box = findViewById<LinearLayout>(R.id.plus_preview)
        val density = resources.displayMetrics.density
        val margin = (3 * density).toInt()
        previewH = 58f * density - 2 * margin
        val square = prefs.getBoolean("square_mode", false)
        val plus = prefs.getBoolean("plus", false) && !square

        dynamicColors = intArrayOf(
            color(box, com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E.toInt()),
            color(box, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt()),
            color(box, com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt()),
            color(box, com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt()),
            color(box, com.google.android.material.R.attr.colorTertiaryContainer, 0xFF633B48.toInt()),
            color(box, com.google.android.material.R.attr.colorOnTertiaryContainer, 0xFFFFD8E4.toInt()),
            color(box, com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt()),
            color(box, com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72.toInt())
        )
        val cols = previewColors()

        class Spec(val kind: KeyKind, val label: String, val w: Float, val bgI: Int, val fgI: Int)

        val specs = listOf(
            Spec(KeyKind.LETTER, "Q", 1f, 0, 1),
            Spec(KeyKind.LETTER, "W", 1f, 0, 1),
            Spec(KeyKind.SHIFT, "⇧", 1f, 2, 3),
            Spec(KeyKind.SPACE, getString(R.string.space_key), 2.2f, 4, 5),
            Spec(KeyKind.BACKSPACE, "⌫", 1f, 2, 3),
            Spec(KeyKind.ENTER, "↵", 1f, 6, 7)
        )
        for (s in specs) {
            val radii = KeyShapes.normal(s.kind, plus, previewH, density, square, prefs.getBoolean("plus_shapes", true), KeyShapes.round(prefs))
            val d = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(cols[s.bgI])
                cornerRadii = radii.copyOf()
            }
            val tv = TextView(a).apply {
                text = s.label
                gravity = Gravity.CENTER
                setTextColor(cols[s.fgI])
                textSize = if (s.kind == KeyKind.SPACE) 13f else 18f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                background = d
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, s.w)
            lp.setMargins(margin, margin, margin, margin)
            box.addView(tv, lp)
            previewKeys.add(PreviewKey(tv, s.kind, d, radii.copyOf(), s.bgI, s.fgI))
        }

        paintBar()
        arrowBox = findViewById(R.id.plus_arrow)
        buildStyleBox()
        repaint()
        setupAdvanced()
    }

    /** Closed arrow in a circle (Material You blue); opens the advanced Material You+ settings. */
    private fun setupAdvanced() {
        val density = resources.displayMetrics.density
        val box = findViewById<FrameLayout>(R.id.plus_arrow)
        val adv = findViewById<LinearLayout>(R.id.plus_adv)
        val bg = color(box, com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt())
        val fg = color(box, com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72.toInt())
        val onSurface = color(box, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        box.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(bg)
        }
        val arrow = ArrowDrawable(fg, (40 * density).toInt())
        box.foreground = arrow

        adv.removeAllViews()
        adv.addView(TextView(a).apply {
            text = getString(R.string.plus_adv_anim)
            textSize = 14f
            setTextColor(onSurface)
        })
        val modes = listOf(
            "shrink" to R.string.plus_anim_shrink, "grow" to R.string.plus_anim_grow,
            "none" to R.string.plus_anim_none, "fade" to R.string.plus_anim_fade, "push" to R.string.plus_anim_push
        )
        val cur = prefs.getString("press_anim", "shrink")
        val chips = com.google.android.material.chip.ChipGroup(a).apply {
            isSingleSelection = true
            isSelectionRequired = true
        }
        for ((key, res) in modes) {
            val chip = com.google.android.material.chip.Chip(a).apply {
                text = getString(res)
                id = View.generateViewId()
                isCheckable = true
                isChecked = key == cur
                setOnClickListener { prefs.edit().putString("press_anim", key).apply() }
            }
            chips.addView(chip)
        }
        adv.addView(chips, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (8 * density).toInt()
        })
        val shapesSw = com.google.android.material.materialswitch.MaterialSwitch(a).apply {
            text = getString(R.string.plus_shapes_sw)
            isChecked = prefs.getBoolean("plus_shapes", true)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("plus_shapes", on).apply()
                sync()
            }
        }
        adv.addView(shapesSw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (8 * density).toInt()
        })
        val spinSw = com.google.android.material.materialswitch.MaterialSwitch(a).apply {
            text = getString(R.string.plus_spin)
            isChecked = prefs.getBoolean("cookie_spin", true)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("cookie_spin", on).apply()
                CookieDrawable.spin = on
            }
        }
        adv.addView(spinSw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (8 * density).toInt()
        })

        var open = false
        var anim: ValueAnimator? = null
        box.setOnClickListener {
            open = !open
            anim?.cancel()
            val from = arrow.progress
            val to = if (open) 1f else 0f
            if (open) {
                adv.alpha = 0f
                adv.visibility = View.VISIBLE
            }
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 260
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener {
                    val f = it.animatedValue as Float
                    arrow.progress = from + (to - from) * f
                    adv.alpha = if (open) f else 1f - f
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: android.animation.Animator) {
                        if (!open) adv.visibility = View.GONE
                    }
                })
                start()
            }
        }
    }

    /** The hidden square mode is changed in another screen: bring the card and preview in line when we come back. */
    fun sync() {
        if (styleGroup == null) return
        val square = prefs.getBoolean("square_mode", false)
        val plus = prefs.getBoolean("plus", false) && !square
        val density = resources.displayMetrics.density
        styleGroup?.let { g ->
            for (i in 0 until g.childCount) g.getChildAt(i).isEnabled = !square
            g.check(g.getChildAt(if (plus) 1 else 0).id)
        }
        showMode()
        paintBar()
        repaint()
        for (k in previewKeys) {
            val to = KeyShapes.normal(k.kind, plus, previewH, density, square, prefs.getBoolean("plus_shapes", true), KeyShapes.round(prefs))
            for (i in 0 until 8) k.cur[i] = to[i]
            k.d.cornerRadii = to.copyOf()
        }
    }

    /** Banner row of top-bar buttons: cookies with Material You + (and shapes on), gray circles otherwise. */
    private fun paintBar() {
        val bar = findViewById<LinearLayout>(R.id.plus_bar) ?: return
        val dm = resources.displayMetrics.density
        val square = prefs.getBoolean("square_mode", false)
        val cookie = prefs.getBoolean("plus", false) && !square && prefs.getBoolean("plus_shapes", true)
        bar.removeAllViews()
        val pc = previewColors()
        val bg = if (cookie) pc[6] else dynamicColors[0]
        val fg = if (cookie) pc[7] else dynamicColors[1]
        for (res in listOf(R.drawable.ic_clipboard, R.drawable.ic_mic, 0)) {
            val b = FrameLayout(a)
            if (cookie) {
                b.background = CookieDrawable(8, (36 * dm).toInt()).also { it.setColor(bg) }
            } else {
                val oval = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(bg)
                }
                b.background = android.graphics.drawable.InsetDrawable(oval, (4 * dm).toInt(), (3 * dm).toInt(), (4 * dm).toInt(), (3 * dm).toInt())
            }
            val iv = android.widget.ImageView(a)
            if (res != 0) {
                iv.setImageResource(res)
                iv.setColorFilter(fg)
            } else {
                iv.setImageDrawable(ArrowDrawable(fg, (28 * dm).toInt()))
            }
            b.addView(iv, FrameLayout.LayoutParams((24 * dm).toInt(), (24 * dm).toInt(), Gravity.CENTER))
            bar.addView(b, LinearLayout.LayoutParams((52 * dm).toInt(), (44 * dm).toInt()).apply {
                setMargins((6 * dm).toInt(), 0, (6 * dm).toInt(), 0)
            })
        }
    }

    private fun animatePreview(plus: Boolean) {
        paintBar()
        val density = resources.displayMetrics.density
        for (k in previewKeys) {
            val from = k.cur.copyOf()
            val to = KeyShapes.normal(k.kind, plus, previewH, density, false, prefs.getBoolean("plus_shapes", true), KeyShapes.round(prefs))
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 380
                interpolator = android.view.animation.OvershootInterpolator(1.6f)
                addUpdateListener {
                    val f = it.animatedValue as Float
                    for (i in 0 until 8) k.cur[i] = maxOf(0f, from[i] + (to[i] - from[i]) * f)
                    k.d.cornerRadii = k.cur.copyOf()
                }
                start()
            }
        }
    }
}
