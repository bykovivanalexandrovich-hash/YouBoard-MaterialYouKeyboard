package com.materialyou.keyboard

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.color.MaterialColors

/** The big releases (1.0, 1.5, 2.0 ... 5.0) as colourful cards. */
class ReleasesActivity : AppCompatActivity() {
    private var d = 1f
    private fun dp(v: Int) = (v * d).toInt()
    private fun attr(a: Int, fb: Int) = MaterialColors.getColor(this, a, fb)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
            (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) !=
                    android.content.res.Configuration.UI_MODE_NIGHT_YES

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            setBackgroundColor(attr(com.google.android.material.R.attr.colorSurface, 0xFF141218.toInt()))
        }
        root.addView(MaterialToolbar(this).apply {
            title = getString(R.string.rel_title)
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { finish() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(32))
        }
        val scroll = ScrollView(this).apply { addView(col) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val vers = resources.getStringArray(R.array.rel_ver)
        val names = resources.getStringArray(R.array.rel_name)
        val bodies = resources.getStringArray(R.array.rel_body)
        val pairs = listOf(
            Triple(com.google.android.material.R.attr.colorPrimaryContainer, com.google.android.material.R.attr.colorOnPrimaryContainer, com.google.android.material.R.attr.colorPrimary),
            Triple(com.google.android.material.R.attr.colorSecondaryContainer, com.google.android.material.R.attr.colorOnSecondaryContainer, com.google.android.material.R.attr.colorSecondary),
            Triple(com.google.android.material.R.attr.colorTertiaryContainer, com.google.android.material.R.attr.colorOnTertiaryContainer, com.google.android.material.R.attr.colorTertiary)
        )
        // newest first
        for (n in vers.indices.reversed()) {
            val (bg, fg, acc) = pairs[n % 3]
            val cBg = attr(bg, 0xFFE8DEF8.toInt())
            val cFg = attr(fg, 0xFF1D192B.toInt())
            val cAcc = attr(acc, 0xFF6750A4.toInt())
            val onAcc = attr(com.google.android.material.R.attr.colorOnPrimary, 0xFFFFFFFF.toInt())
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(20), dp(20), dp(20))
                background = GradientDrawable().apply { cornerRadius = dp(32).toFloat(); setColor(cBg) }
            }
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val badge = FrameLayout(this).apply {
                background = CookieDrawable(if (n % 2 == 0) 8 else 6).apply { setColor(cAcc) }
                addView(TextView(this@ReleasesActivity).apply {
                    text = vers[n]
                    textSize = 20f
                    setTextColor(onAcc)
                    gravity = Gravity.CENTER
                }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
            head.addView(badge, LinearLayout.LayoutParams(dp(76), dp(76)))
            head.addView(TextView(this).apply {
                text = names[n]
                textSize = 22f
                setTextColor(cFg)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(16) })
            card.addView(head)
            card.addView(TextView(this).apply {
                text = bodies[n].replace("\\n", "\n")
                textSize = 15f
                setLineSpacing(0f, 1.2f)
                setTextColor(cFg)
                alpha = 0.9f
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) })
            col.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
            card.alpha = 0f
            card.translationY = dp(30).toFloat()
            card.animate().alpha(1f).translationY(0f).setStartDelay((vers.size - 1 - n) * 70L).setDuration(350).start()
        }
    }
}
