package com.materialyou.keyboard

import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat

/** The app-wide wide bold font (DejaVu Sans Bold, free licence). */
object Fonts {
    private var cached: Typeface? = null

    fun wide(c: Context): Typeface {
        cached?.let { return it }
        val t = try { ResourcesCompat.getFont(c, R.font.youboard_wide) } catch (e: Exception) { null }
            ?: Typeface.create("sans-serif-medium", Typeface.BOLD)
        cached = t
        return t
    }

    /** Key label font: the custom one when the Themes switch is on. */
    fun kb(c: Context, prefs: android.content.SharedPreferences): Typeface =
        if (prefs.getBoolean("kb_font", false)) wide(c)
        else Typeface.create("sans-serif-medium", Typeface.NORMAL)
}
