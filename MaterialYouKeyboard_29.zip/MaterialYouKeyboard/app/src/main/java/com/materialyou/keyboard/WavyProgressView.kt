package com.materialyou.keyboard

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import com.google.android.material.color.MaterialColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Material 3 Expressive circular wavy progress (indeterminate): the active indicator is a rounded sine wave
 * wrapped around the ring, its length grows and shrinks while it travels clockwise and the wave itself keeps
 * running; the track is a smooth ring with a fixed gap before and after the wave.
 */
class WavyProgressView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private val d = resources.displayMetrics.density
    private val stroke = 4f * d
    private val amp = 1.8f * d
    private val cycles = 9
    private val gapDeg = 14f

    private val active = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = stroke
        color = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF6750A4.toInt())
    }
    private val track = Paint(active).apply {
        color = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSecondaryContainer, 0xFFE8DEF8.toInt())
    }
    private val rect = RectF()
    private val path = Path()
    private var t = 0f
    private var anim: ValueAnimator? = null

    override fun onMeasure(w: Int, h: Int) {
        val def = (40 * d).toInt()
        val s = minOf(resolveSize(def, w), resolveSize(def, h))
        setMeasuredDimension(s, s)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val r = minOf(width, height) / 2f - stroke / 2f - amp
        if (r <= 0f) return
        val cx = width / 2f
        val cy = height / 2f
        // the sweep breathes between 50 and 270 degrees, the head travels clockwise
        val breathe = (0.5f - 0.5f * cos(t * 2f * PI.toFloat() * 2f))
        val sweep = 50f + 220f * breathe
        val start = -90f + t * 360f * 2f
        val total = 360f

        // track: smooth arc over the part not covered by the wave, with a gap on both sides
        val trackStart = start + sweep + gapDeg
        val trackSweep = total - sweep - 2f * gapDeg
        if (trackSweep > 1f) {
            rect.set(cx - r, cy - r, cx + r, cy + r)
            c.drawArc(rect, trackStart, trackSweep, false, track)
        }

        // active wave: radius oscillates around r, the phase runs so the wave keeps moving
        val phase = t * 2f * PI.toFloat() * 6f
        path.rewind()
        val steps = (sweep / 2f).toInt().coerceAtLeast(8)
        for (i in 0..steps) {
            val a = start + sweep * i / steps
            val rad = Math.toRadians(a.toDouble())
            val k = (i.toFloat() / steps)
            // the wave fades in and out at the ends so it joins the ring smoothly
            val env = minOf(1f, minOf(k, 1f - k) * 6f)
            val rr = r + amp * env * sin(rad.toFloat() * cycles + phase)
            val x = cx + rr * cos(rad).toFloat()
            val y = cy + rr * sin(rad).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, active)
    }
}
