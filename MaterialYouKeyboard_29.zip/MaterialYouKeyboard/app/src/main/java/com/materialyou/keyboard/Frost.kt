package com.materialyou.keyboard

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import androidx.annotation.RequiresApi
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.widget.NestedScrollView
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.color.MaterialColors

/**
 * Light "frosted glass" for the top bar of the app screens and for the floating bottom tab bar:
 * the content that scrolls under them is blurred a little and tinted with the surface colour.
 * The real blur needs Android 12+; older versions get the same translucent tint without the blur.
 * The switch "Blur panels" (pref ui_blur) in the Control Center turns all of it off.
 */
object Frost {
    const val LIQUID = "liquid_glass"

    /** The matte blur of the panels was removed in 5.4 beta; only the liquid glass theme uses the blur code now. */
    @Suppress("UNUSED_PARAMETER")
    fun enabled(p: SharedPreferences) = false

    fun liquid(p: SharedPreferences) = p.getBoolean(LIQUID, false)

    private fun <T : View> find(root: View, cls: Class<T>): T? {
        if (cls.isInstance(root)) return cls.cast(root)
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) {
                val r = find(root.getChildAt(i), cls)
                if (r != null) return r
            }
        }
        return null
    }

    /** The vertical scroller of a screen (used by the bottom bar to follow the scrolling direction). */
    fun scrollOf(root: View?): View? {
        if (root == null) return null
        return find(root, NestedScrollView::class.java) ?: find(root, android.widget.ScrollView::class.java)
    }

    /**
     * Top bar of a screen with a collapsing toolbar: the scrolling content is moved under the bar (it keeps the same
     * position at rest through a top padding that follows the bar) and the bar's scrim becomes a blurred glass.
     */
    fun top(act: Activity, p: SharedPreferences) {
        if (!enabled(p)) return
        val content = act.findViewById<ViewGroup>(android.R.id.content) ?: return
        val appBar = find(content, AppBarLayout::class.java) ?: return
        val scroll = find(content, NestedScrollView::class.java) ?: return
        val ctl = find(appBar, CollapsingToolbarLayout::class.java) ?: return
        val lp = scroll.layoutParams as? CoordinatorLayout.LayoutParams ?: return
        val d = act.resources.displayMetrics.density

        lp.behavior = null
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT
        scroll.layoutParams = lp
        scroll.clipToPadding = false
        appBar.setBackgroundColor(Color.TRANSPARENT)
        appBar.bringToFront()

        val surface = MaterialColors.getColor(content, com.google.android.material.R.attr.colorSurface, 0xFF141218.toInt())
        val tint = MaterialColors.getColor(content, com.google.android.material.R.attr.colorSurfaceContainer, 0xFF2B2930.toInt())
        val src: () -> View? = { scroll }
        val scrim = FrostDrawable(src, surface, tint, 0f, 9f * d, 0, 0f, true, 0xB0, 0xF2)
        val status = FrostDrawable(src, surface, tint, 0f, 9f * d, 0, 0f, true, 0xB0, 0xF2)
        ctl.setContentScrim(scrim)
        ctl.setStatusBarScrim(status)

        fun sync() {
            val t = if (appBar.visibility == View.GONE) 0 else maxOf(appBar.bottom, 0)
            if (scroll.paddingTop != t) scroll.setPadding(scroll.paddingLeft, t, scroll.paddingRight, scroll.paddingBottom)
        }
        appBar.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { _, _ -> sync() })
        scroll.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> sync() }

        if (Build.VERSION.SDK_INT >= 31) {
            val vto = scroll.viewTreeObserver
            vto.addOnScrollChangedListener(ViewTreeObserver.OnScrollChangedListener {
                scrim.invalidateSelf()
                status.invalidateSelf()
            })
            vto.addOnGlobalLayoutListener(ViewTreeObserver.OnGlobalLayoutListener {
                scrim.invalidateSelf()
                status.invalidateSelf()
            })
        }
    }
}

/**
 * A rounded, tinted background that shows a blurred copy of what is behind the view it belongs to.
 * [source] is the view whose picture is blurred (it must not contain the host view); [fill] is painted under it
 * when the source has no background of its own.
 */
class FrostDrawable(
    private val source: () -> View?,
    internal val fill: Int?,
    private val tint: Int,
    private val corner: Float,
    internal val radius: Float,
    private val stroke: Int,
    private val strokeW: Float,
    private val enabled: Boolean,
    private val blurAlpha: Int,
    private val plainAlpha: Int
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    internal var alphaV = 255
    internal var node: Any? = null
    private var busy = false

    private fun cr(): Float = minOf(corner, minOf(bounds.width(), bounds.height()) / 2f)

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val rect = RectF(b)
        val r = cr()
        var blurred = false
        if (enabled && Build.VERSION.SDK_INT >= 31 && canvas.isHardwareAccelerated && !busy) {
            val host = callback as? View
            val src = source()
            if (host != null && src != null && src.isAttachedToWindow && src.width > 0 && src.height > 0) {
                busy = true
                val save = canvas.save()
                try {
                    if (r > 0f) {
                        path.reset()
                        path.addRoundRect(rect, r, r, Path.Direction.CW)
                        canvas.clipPath(path)
                    } else {
                        canvas.clipRect(rect)
                    }
                    blurred = Blur31.draw(this, canvas, host, src)
                } catch (_: Throwable) {
                    blurred = false
                } finally {
                    canvas.restoreToCount(save)
                    busy = false
                }
            }
        }
        val a = (if (blurred) blurAlpha else plainAlpha) * alphaV / 255
        paint.style = Paint.Style.FILL
        paint.color = (tint and 0x00FFFFFF) or (a shl 24)
        canvas.drawRoundRect(rect, r, r, paint)
        if (strokeW > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = strokeW
            paint.color = (stroke and 0x00FFFFFF) or ((stroke ushr 24) * alphaV / 255 shl 24)
            val h = strokeW / 2f
            canvas.drawRoundRect(RectF(rect.left + h, rect.top + h, rect.right - h, rect.bottom - h), maxOf(r - h, 0f), maxOf(r - h, 0f), paint)
        }
    }

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, cr())
        outline.alpha = 1f
    }

    override fun setAlpha(alpha: Int) {
        alphaV = alpha
        invalidateSelf()
    }

    override fun getAlpha(): Int = alphaV

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** The Android 12+ part, kept apart so that older devices never load the classes it needs. */
@RequiresApi(31)
internal object Blur31 {
    fun draw(d: FrostDrawable, canvas: Canvas, host: View, src: View): Boolean {
        val b = d.bounds
        val w = b.width()
        val h = b.height()
        if (w <= 0 || h <= 0) return false
        val node = (d.node as? android.graphics.RenderNode) ?: android.graphics.RenderNode("frost").also { d.node = it }
        node.setPosition(0, 0, w, h)
        node.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(d.radius, d.radius, android.graphics.Shader.TileMode.CLAMP))
        val hl = IntArray(2)
        val sl = IntArray(2)
        host.getLocationOnScreen(hl)
        src.getLocationOnScreen(sl)
        val dx = (hl[0] + b.left - sl[0]).toFloat()
        val dy = (hl[1] + b.top - sl[1]).toFloat()
        val rec = node.beginRecording(w, h)
        try {
            d.fill?.let { rec.drawColor(it) }
            rec.translate(-dx, -dy)
            src.draw(rec)
        } finally {
            node.endRecording()
        }
        node.setAlpha(d.alphaV / 255f)
        val save = canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        canvas.drawRenderNode(node)
        canvas.restoreToCount(save)
        return true
    }
}


/**
 * Liquid glass (W.I.P.): the backdrop is lightly blurred and bent like a lens near the edges (Android 13+ draws the
 * refraction with a shader, Android 12 only blurs, older versions get a clear tinted glass), with a bright rim and a soft sheen.
 */
class LiquidDrawable(
    private val source: () -> View?,
    private val tint: Int,
    private val corner: Float,
    private val density: Float,
    private val rim: Float = 1f
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    internal var alphaV = 255
    internal var node: Any? = null
    internal var shader: Any? = null
    internal val blurPx get() = 3f * density
    private var busy = false

    internal fun cr(): Float = minOf(corner, minOf(bounds.width(), bounds.height()) / 2f)

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val rect = RectF(b)
        val r = cr()
        var blurred = false
        if (Build.VERSION.SDK_INT >= 31 && canvas.isHardwareAccelerated && !busy) {
            val host = callback as? View
            val src = source()
            if (host != null && src != null && src.isAttachedToWindow && src.width > 0 && src.height > 0) {
                busy = true
                val save = canvas.save()
                try {
                    path.reset()
                    path.addRoundRect(rect, r, r, Path.Direction.CW)
                    canvas.clipPath(path)
                    blurred = Liquid31.draw(this, canvas, host, src)
                } catch (_: Throwable) {
                    blurred = false
                } finally {
                    canvas.restoreToCount(save)
                    busy = false
                }
            }
        }
        // body of the glass
        paint.shader = null
        paint.style = Paint.Style.FILL
        val base = if (blurred) 0x40 else 0xD8
        paint.color = (tint and 0x00FFFFFF) or ((base * alphaV / 255) shl 24)
        canvas.drawRoundRect(rect, r, r, paint)
        // sheen: lighter on top, clear at the bottom
        paint.shader = android.graphics.LinearGradient(
            rect.left, rect.top, rect.left, rect.bottom,
            intArrayOf(Color.argb(0x46 * alphaV / 255, 255, 255, 255), Color.argb(0x0C * alphaV / 255, 255, 255, 255), Color.argb(0x1E * alphaV / 255, 255, 255, 255)),
            floatArrayOf(0f, 0.55f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(rect, r, r, paint)
        // bright rim, strongest on the top-left and bottom-right edges
        val sw = 1.5f * density
        paint.shader = android.graphics.LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(Color.argb((0xE6 * alphaV / 255 * rim).toInt(), 255, 255, 255), Color.argb((0x2A * alphaV / 255 * rim).toInt(), 255, 255, 255), Color.argb((0xB4 * alphaV / 255 * rim).toInt(), 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = sw
        val h = sw / 2f
        canvas.drawRoundRect(RectF(rect.left + h, rect.top + h, rect.right - h, rect.bottom - h), maxOf(r - h, 0f), maxOf(r - h, 0f), paint)
        paint.shader = null
    }

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, cr())
        outline.alpha = 1f
    }

    override fun setAlpha(alpha: Int) {
        alphaV = alpha
        invalidateSelf()
    }

    override fun getAlpha(): Int = alphaV

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

@RequiresApi(31)
internal object Liquid31 {
    private const val AGSL = """
        uniform shader content;
        uniform float2 size;
        uniform float radius;
        half4 main(float2 p) {
            float2 c = size * 0.5;
            float2 q = abs(p - c) - (c - float2(radius));
            float sd = length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - radius;
            float depth = clamp(-sd / (radius * 0.9), 0.0, 1.0);
            float bend = pow(1.0 - depth, 2.2);
            float2 r = (c - p) * bend * 0.5;
            half4 a = content.eval(p + r);
            half4 b = content.eval(p + r * 1.07);
            half4 d = content.eval(p + r * 1.14);
            return half4(a.r, b.g, d.b, 1.0);
        }
    """

    fun draw(d: LiquidDrawable, canvas: Canvas, host: View, src: View): Boolean {
        val bnd = d.bounds
        val w = bnd.width()
        val h = bnd.height()
        if (w <= 0 || h <= 0) return false
        val node = (d.node as? android.graphics.RenderNode) ?: android.graphics.RenderNode("liquid").also { d.node = it }
        node.setPosition(0, 0, w, h)
        val blur = android.graphics.RenderEffect.createBlurEffect(d.blurPx, d.blurPx, android.graphics.Shader.TileMode.CLAMP)
        if (Build.VERSION.SDK_INT >= 33) {
            val sh = (d.shader as? android.graphics.RuntimeShader) ?: android.graphics.RuntimeShader(AGSL).also { d.shader = it }
            sh.setFloatUniform("size", w.toFloat(), h.toFloat())
            sh.setFloatUniform("radius", d.cr())
            val lens = android.graphics.RenderEffect.createRuntimeShaderEffect(sh, "content")
            node.setRenderEffect(android.graphics.RenderEffect.createChainEffect(lens, blur))
        } else {
            node.setRenderEffect(blur)
        }
        val hl = IntArray(2)
        val sl = IntArray(2)
        host.getLocationOnScreen(hl)
        src.getLocationOnScreen(sl)
        val dx = (hl[0] + bnd.left - sl[0]).toFloat()
        val dy = (hl[1] + bnd.top - sl[1]).toFloat()
        val rec = node.beginRecording(w, h)
        try {
            rec.translate(-dx, -dy)
            src.draw(rec)
        } finally {
            node.endRecording()
        }
        node.setAlpha(d.alphaV / 255f)
        val save = canvas.save()
        canvas.translate(bnd.left.toFloat(), bnd.top.toFloat())
        canvas.drawRenderNode(node)
        canvas.restoreToCount(save)
        return true
    }
}


/**
 * The lens of the liquid glass tab bar: a glass capsule that sits on the current tab and swells when it is touched or
 * dragged, magnifying the icons and names under it like a drop of water.
 */
class LensView(ctx: android.content.Context, private val under: () -> View?, private val tint: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    /** 0 = resting, 1 = fully swollen */
    var grow = 0f
        set(v) {
            field = v
            scaleX = 1f + 0.2f * v
            scaleY = 1f + 0.16f * v
            invalidate()
        }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = h / 2f
        val rect = RectF(0f, 0f, w, h)
        path.reset()
        path.addRoundRect(rect, r, r, Path.Direction.CW)
        val u = under()
        paint.style = Paint.Style.FILL
        if (u != null && grow > 0.01f) {
            val save = c.save()
            c.clipPath(path)
            // the glass hides what is under it and shows the same thing bigger
            paint.color = (tint and 0x00FFFFFF) or ((0xE8 * grow).toInt() shl 24)
            c.drawRect(rect, paint)
            val s = 1f + 0.25f * grow
            c.scale(s, s, w / 2f, h / 2f)
            c.translate(-(left + translationX - u.left), -(top - u.top).toFloat())
            u.draw(c)
            c.restoreToCount(save)
        }
        paint.color = Color.argb(0x2C, 255, 255, 255)
        c.drawRoundRect(rect, r, r, paint)
        paint.shader = android.graphics.LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(Color.argb(0x5A, 255, 255, 255), Color.argb(0x08, 255, 255, 255), Color.argb(0x2E, 255, 255, 255)),
            floatArrayOf(0f, 0.55f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rect, r, r, paint)
        val sw = 2f * resources.displayMetrics.density
        paint.shader = android.graphics.LinearGradient(
            0f, 0f, w, h,
            intArrayOf(Color.argb(0xF0, 255, 255, 255), Color.argb(0x30, 255, 255, 255), Color.argb(0xC8, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = sw
        val hh = sw / 2f
        c.drawRoundRect(RectF(hh, hh, w - hh, h - hh), r - hh, r - hh, paint)
        paint.shader = null
    }
}

/** Sheen and a thin bright rim over a key of the liquid glass theme (the keyboard experiment). */
class GlassOverlay(private val shape: android.graphics.drawable.GradientDrawable, private val density: Float) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val radii = shape.cornerRadii ?: return
        val rect = RectF(b)
        path.reset()
        path.addRoundRect(rect, radii, Path.Direction.CW)
        paint.style = Paint.Style.FILL
        paint.shader = android.graphics.LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            intArrayOf(Color.argb(0x40, 255, 255, 255), Color.argb(0x06, 255, 255, 255), Color.argb(0x16, 255, 255, 255)),
            floatArrayOf(0f, 0.55f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        canvas.drawPath(path, paint)
        val sw = density
        paint.shader = android.graphics.LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(Color.argb(0xB0, 255, 255, 255), Color.argb(0x14, 255, 255, 255), Color.argb(0x70, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = sw
        canvas.save()
        canvas.clipPath(path)
        canvas.drawPath(path, paint)
        canvas.restore()
        paint.shader = null
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
