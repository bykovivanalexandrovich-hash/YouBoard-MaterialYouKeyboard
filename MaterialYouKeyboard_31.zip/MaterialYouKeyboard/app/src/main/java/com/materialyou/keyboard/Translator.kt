package com.materialyou.keyboard

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Live translation for the keyboard: the typed text is sent to Google Translate (language is detected by itself). */
object Translator {
    val langs = listOf("en", "ru", "uk", "de", "es", "fr", "it", "pl")

    /** @return the translation and the detected source language, or null when it failed */
    fun translate(text: String, target: String): Pair<String, String>? {
        val q = URLEncoder.encode(text.takeLast(800), "UTF-8")
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$target&dt=t&q=$q")
        val con = url.openConnection() as HttpURLConnection
        con.connectTimeout = 4000
        con.readTimeout = 6000
        con.setRequestProperty("User-Agent", "Mozilla/5.0")
        try {
            if (con.responseCode != 200) return null
            val body = con.inputStream.bufferedReader().use { it.readText() }
            val root = JSONArray(body)
            val segs = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segs.length()) sb.append(segs.getJSONArray(i).optString(0, ""))
            return sb.toString() to root.optString(2, "")
        } finally {
            con.disconnect()
        }
    }
}
