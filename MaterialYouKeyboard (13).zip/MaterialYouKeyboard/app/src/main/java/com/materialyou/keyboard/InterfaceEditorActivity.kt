package com.materialyou.keyboard

import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

/**
 * Interface editor: order and removal of the bottom bar tabs, order and visibility of the setting groups
 * on every screen. Everything is stored in prefs (ui_tabs, ui_g_*, ui_gh_*); ui_rev tells the screens to rebuild.
 */
class InterfaceEditorActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var col: LinearLayout
    private var d = 1f

    private fun dp(v: Int) = (v * d).toInt()
    private fun attr(a: Int, fb: Int) = MaterialColors.getColor(this, a, fb)

    private class Screen(val id: String, val layout: Int, val title: Int)

    private val screens = listOf(
        Screen("main", R.layout.activity_main, R.string.ui_scr_main),
        Screen("themes", R.layout.activity_themes, R.string.ui_scr_themes),
        Screen("cc", R.layout.activity_control, R.string.ui_scr_cc)
    )

    private val tabNames = intArrayOf(R.string.tab_name_0, R.string.tab_name_1, R.string.tab_name_2, R.string.tab_name_3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
            (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) !=
                    android.content.res.Configuration.UI_MODE_NIGHT_YES

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            setBackgroundColor(attr(com.google.android.material.R.attr.colorSurface, 0xFF141218.toInt()))
        }
        val tb = MaterialToolbar(this).apply {
            title = getString(R.string.ui_title)
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { finish() }
        }
        root.addView(tb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
        val scroll = ScrollView(this)
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(32))
        }
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        render()
    }

    private fun changed() {
        prefs.edit().putLong("ui_rev", System.currentTimeMillis()).apply()
        render()
    }

    private fun heading(text: String, hint: String?) {
        col.addView(TextView(this).apply {
            this.text = text
            textSize = 18f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setTextColor(attr(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt()))
            setPadding(dp(4), dp(20), dp(4), dp(4))
        })
        if (hint != null) col.addView(TextView(this).apply {
            this.text = hint
            textSize = 13f
            setTextColor(attr(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt()))
            setPadding(dp(4), 0, dp(4), dp(8))
        })
    }

    private fun arrowBtn(icon: Int, enabled: Boolean, click: () -> Unit) =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            setIconResource(icon)
            iconPadding = 0
            iconGravity = MaterialButton.ICON_GRAVITY_TEXT_START
            minWidth = 0
            minimumWidth = 0
            insetTop = 0
            insetBottom = 0
            setPadding(dp(12), 0, dp(12), 0)
            isEnabled = enabled
            setOnClickListener { click() }
        }

    /** One list row: title, up / down arrows and a visibility switch. */
    private fun row(title: String, canUp: Boolean, canDown: Boolean, shown: Boolean, canHide: Boolean,
                    up: () -> Unit, down: () -> Unit, show: (Boolean) -> Unit) {
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(attr(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF2B2930.toInt()))
            }
            alpha = if (shown) 1f else 0.55f
        }
        line.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt()))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        line.addView(arrowBtn(R.drawable.ic_arrow_up, canUp, up), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { marginStart = dp(4) })
        line.addView(arrowBtn(R.drawable.ic_arrow_down, canDown, down), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { marginStart = dp(4) })
        line.addView(MaterialSwitch(this).apply {
            isChecked = shown
            isEnabled = canHide
            setOnCheckedChangeListener { _, on -> show(on) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        col.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }

    private fun render() {
        col.removeAllViews()

        // ---- tabs: shown ones in their order, then the removed ones
        heading(getString(R.string.ui_tabs), getString(R.string.ui_tabs_hint))
        val shownTabs = BottomBar.order(prefs).toMutableList()
        val allTabs = shownTabs + (0 until BottomBar.ALL).filter { it !in shownTabs }
        for (id in allTabs) {
            val pos = shownTabs.indexOf(id)
            val shown = pos >= 0
            row(getString(tabNames[id]), shown && pos > 0, shown && pos < shownTabs.size - 1, shown, !BottomBar.locked(id),
                up = { shownTabs.add(pos - 1, shownTabs.removeAt(pos)); saveTabs(shownTabs) },
                down = { shownTabs.add(pos + 1, shownTabs.removeAt(pos)); saveTabs(shownTabs) },
                show = { on -> if (on) shownTabs.add(id) else shownTabs.remove(id); saveTabs(shownTabs) })
        }

        // ---- groups of every screen
        for (sc in screens) {
            val titles = Groups.titles(LayoutInflater.from(this).inflate(sc.layout, null))
            val byIdx = titles.toMap()
            val saved = Groups.idList(prefs, "ui_g_${sc.id}").filter { it in byIdx }
            val order = (saved + titles.map { it.first }.filter { it !in saved }).toMutableList()
            val hidden = Groups.idList(prefs, "ui_gh_${sc.id}").toMutableSet()
            heading(getString(sc.title), if (sc === screens[0]) getString(R.string.ui_groups_hint) else null)
            for ((i, idx) in order.withIndex()) {
                row(byIdx[idx] ?: "", i > 0, i < order.size - 1, idx !in hidden, true,
                    up = { order.add(i - 1, order.removeAt(i)); saveGroups(sc.id, order, hidden) },
                    down = { order.add(i + 1, order.removeAt(i)); saveGroups(sc.id, order, hidden) },
                    show = { on -> if (on) hidden.remove(idx) else hidden.add(idx); saveGroups(sc.id, order, hidden) })
            }
        }

        col.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = getString(R.string.ui_reset)
            setAllCaps(false)
            setOnClickListener {
                MaterialAlertDialogBuilder(this@InterfaceEditorActivity)
                    .setTitle(R.string.ui_reset)
                    .setMessage(R.string.ui_reset_msg)
                    .setNegativeButton(R.string.cancel, null)
                    .setPositiveButton(R.string.reset_ok) { _, _ ->
                        val e = prefs.edit().remove("ui_tabs")
                        for (sc in screens) e.remove("ui_g_${sc.id}").remove("ui_gh_${sc.id}")
                        e.apply()
                        changed()
                    }
                    .show()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(24) })
    }

    private fun saveTabs(shown: List<Int>) {
        prefs.edit().putString("ui_tabs", shown.joinToString(",")).apply()
        changed()
    }

    private fun saveGroups(screen: String, order: List<Int>, hidden: Set<Int>) {
        prefs.edit()
            .putString("ui_g_$screen", order.joinToString(","))
            .putString("ui_gh_$screen", hidden.joinToString(","))
            .apply()
        changed()
    }
}
