# YouBoard 5.0

The final 5.0 release.

## New in this build
- The whole app now uses a wide, bold font (DejaVu Sans Bold).
- New **Font** switch in Themes: use the same font for key labels on the keyboard.

## Highlights of 5.0
- Two keyboard styles: Material You (pick the colour of the main keys) and Material 3 Expressive (key shapes, rotating cookies, animations, glow).
- Interface editor: reorder or hide tabs and setting groups.
- Settings search on every main screen.
- Version screen with a changelog button.
- Telegram group button in Control Center: https://t.me/MaterialYouBoard
- Monochrome vector icons everywhere, no emoji.

## Install
Download `YouBoard.apk` below and install it over the old version.
