# YouBoard 5.2

## New in this build
- Key preview: when you press a key, a big round bubble with its letter pops up above it, like in Gboard. It can be turned off in Settings, Feedback, "Key preview".

## Previous build (5.1.1_3)
- New "R" button on the Version screen that opens the release history from 1.0 to 5.0.

## Install
Download `YouBoard.apk` below and install it over the old version.
