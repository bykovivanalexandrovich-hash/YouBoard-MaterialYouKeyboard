# YouBoard 5.3_1_2

The big bottom bar now opens and closes instantly while you scroll (fast 0.18 s animation, no waiting for a stop).

---


## New in this build
- The bottom bar follows your scrolling: scroll up and stop, and it smoothly grows big with a name under every tab icon. Scroll down and stop, and it goes back to the compact bar.

## Previous build (5.3)
- Keyboard editor: a corner radius slider for every key.
- Frosted glass on the top bar and the bottom bar (Android 12+), switch "Blur panels" in Control Center.
- Themes: "Own background colour".

## Install
Download `YouBoard.apk` below and install it over the old version.
