package com.materialyou.keyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.view.WindowCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.color.MaterialColors

/**
 * Settings search: type a word, tap a result and the right screen opens with the setting's group expanded,
 * scrolled into view and flashed.
 */
class SearchActivity : AppCompatActivity() {

    private class Entry(val title: Int, val sub: Int, val screen: Int)

    private val entries = listOf(
        // Settings screen (0)
        Entry(R.string.sec_input, 0, 0), Entry(R.string.sw_suggestions, R.string.sw_suggestions_s, 0),
        Entry(R.string.sw_autocorrect, R.string.sw_autocorrect_s, 0), Entry(R.string.sw_autocap, R.string.sw_autocap_s, 0),
        Entry(R.string.sw_swipetype, R.string.sw_swipetype_s, 0), Entry(R.string.sw_profanity, R.string.sw_profanity_s, 0),
        Entry(R.string.sw_guard, R.string.sw_guard_s, 0),
        Entry(R.string.sec_langswitch, 0, 0),
        Entry(R.string.sec_keys, 0, 0), Entry(R.string.sw_numrow, R.string.sw_numrow_s, 0),
        Entry(R.string.sw_sym123, R.string.sw_sym123_s, 0), Entry(R.string.sw_hard, R.string.sw_hard_s, 0),
        Entry(R.string.sw_bigletters, R.string.sw_bigletters_s, 0), Entry(R.string.sw_hideemoji, R.string.sw_hideemoji_s, 0),
        Entry(R.string.sw_joystick, R.string.sw_joystick_s, 0),
        Entry(R.string.sec_clip, 0, 0), Entry(R.string.sw_cliphist, R.string.sw_cliphist_s, 0),
        Entry(R.string.sw_clipchip, R.string.sw_clipchip_s, 0), Entry(R.string.sw_clipmask, R.string.sw_clipmask_s, 0),
        Entry(R.string.sec_shortcuts, 0, 0), Entry(R.string.sec_myemoji, 0, 0),
        Entry(R.string.sec_feedback, 0, 0), Entry(R.string.sw_vibrate, R.string.sw_vibrate_s, 0), Entry(R.string.sw_preview, R.string.sw_preview_s, 0), Entry(R.string.sw_bgcolor, R.string.bgcolor_hint, 1), Entry(R.string.sw_blur, R.string.sw_blur_s, 2),
        Entry(R.string.sw_sound, R.string.sw_sound_s, 0),
        Entry(R.string.sec_test, 0, 0),
        // Themes (1)
        Entry(R.string.plus_title, R.string.plus_sub, 1), Entry(R.string.sec_theme, 0, 1), Entry(R.string.sec_fx, 0, 1),
        Entry(R.string.sec_bg, 0, 1), Entry(R.string.sec_height, 0, 1), Entry(R.string.ke_title, 0, 1),
        // Control Center (2)
        Entry(R.string.cc_kb_langs, 0, 2), Entry(R.string.sec_voice, 0, 2), Entry(R.string.cc_language, 0, 2),
        Entry(R.string.cc_apptheme, 0, 2), Entry(R.string.ui_editor, 0, 2)
    )

    private val screenNames = intArrayOf(R.string.tab_name_0, R.string.tab_name_1, R.string.tab_name_2)
    private val screenClasses = listOf(MainActivity::class.java, ThemesActivity::class.java, ControlCenterActivity::class.java)

    private var d = 1f
    private fun dp(v: Int) = (v * d).toInt()
    private fun attr(a: Int, fb: Int) = MaterialColors.getColor(this, a, fb)

    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
            (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) !=
                    android.content.res.Configuration.UI_MODE_NIGHT_YES
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val onSurface = attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val variant = attr(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFFCAC4D0.toInt())

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            setBackgroundColor(attr(com.google.android.material.R.attr.colorSurface, 0xFF141218.toInt()))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(16), dp(8))
        }
        top.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setColorFilter(onSurface)
            scaleType = ImageView.ScaleType.CENTER
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        val field = EditText(this).apply {
            hint = getString(R.string.search_hint)
            setHintTextColor(variant)
            setTextColor(onSurface)
            textSize = 17f
            maxLines = 1
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(20), 0, dp(20), 0)
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(attr(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF2B2930.toInt()))
            }
        }
        top.addView(field, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(4) })
        root.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val scroll = ScrollView(this).apply { isFillViewport = true }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(24))
        }
        scroll.addView(list, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = render(s?.toString() ?: "")
        })
        render("")
        field.requestFocus()
    }

    private fun render(query: String) {
        list.removeAllViews()
        val tokens = query.lowercase().split(' ').filter { it.isNotBlank() }
        var shown = 0
        for (e in entries) {
            val title = getString(e.title)
            val sub = if (e.sub != 0) getString(e.sub) else ""
            val hay = "$title $sub ${getString(screenNames[e.screen])}".lowercase()
            if (tokens.any { it !in hay }) continue
            shown++
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(14), dp(20), dp(14))
                background = GradientDrawable().apply {
                    cornerRadius = dp(22).toFloat()
                    setColor(attr(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF2B2930.toInt()))
                }
                isClickable = true
                isFocusable = true
                setOnClickListener { open(e.screen, title) }
            }
            row.addView(TextView(this).apply {
                text = title
                textSize = 17f
                setTextColor(attr(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt()))
            })
            if (sub.isNotEmpty()) row.addView(TextView(this).apply {
                text = sub
                textSize = 13f
                setTextColor(attr(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFFCAC4D0.toInt()))
            })
            row.addView(TextView(this).apply {
                text = getString(screenNames[e.screen])
                textSize = 12f
                setTextColor(attr(androidx.appcompat.R.attr.colorPrimary, 0xFFD0BCFF.toInt()))
                setPadding(0, dp(4), 0, 0)
            })
            list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        }
        if (shown == 0) list.addView(TextView(this).apply {
            text = getString(R.string.search_none)
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(attr(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFFCAC4D0.toInt()))
            setPadding(0, dp(48), 0, 0)
        })
    }

    private fun open(screen: Int, title: String) {
        startActivity(Intent(this, screenClasses[screen]).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_FOCUS, title)
        })
        finish()
    }

    companion object {
        const val EXTRA_FOCUS = "focus_text"

        /** Puts the search icon into the (otherwise empty) toolbar row of a screen. */
        fun attach(act: Activity, tb: MaterialToolbar) {
            val color = MaterialColors.getColor(act, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
            val icon = DrawableCompat.wrap(androidx.core.content.ContextCompat.getDrawable(act, R.drawable.ic_search)!!.mutate())
            DrawableCompat.setTint(icon, color)
            tb.menu.clear()
            tb.menu.add(0, 1, 0, R.string.search_hint).setIcon(icon).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
            tb.setOnMenuItemClickListener {
                act.startActivity(Intent(act, SearchActivity::class.java))
                true
            }
        }

        /** Called by the target screen: expands the group of the found setting, scrolls to it and flashes it. */
        fun focus(act: Activity) {
            val text = act.intent?.getStringExtra(EXTRA_FOCUS) ?: return
            act.intent?.removeExtra(EXTRA_FOCUS)
            val root = act.findViewById<ViewGroup>(android.R.id.content)
            root.postDelayed({
                val tv = findText(root, text) ?: return@postDelayed
                var wasClosed = false
                // open the group the setting lives in
                var child: View = tv
                while (child.parent is ViewGroup && child.parent !== root) {
                    val p = child.parent as ViewGroup
                    if (child is com.google.android.material.card.MaterialCardView) {
                        var i = p.indexOfChild(child) - 1
                        while (i >= 0 && !(p.getChildAt(i) is TextView && p.getChildAt(i).tag == "section")) i--
                        if (i >= 0 && child.visibility != View.VISIBLE) {
                            p.getChildAt(i).performClick()
                            wasClosed = true
                        }
                        break
                    }
                    child = p
                }
                tv.postDelayed({
                    scrollTo(root, tv)
                    flash(tv)
                }, if (wasClosed) 340L else 60L)
            }, 250L)
        }

        private fun findText(v: View, text: String): TextView? {
            if (v is TextView && v.text.toString().equals(text, ignoreCase = true) && v.getTag(R.id.tag_group_hidden) != true) return v
            if (v is ViewGroup) for (i in 0 until v.childCount) findText(v.getChildAt(i), text)?.let { return it }
            return null
        }

        private fun scrollTo(root: ViewGroup, target: View) {
            val sv = findScroll(root) ?: return
            val content = sv.getChildAt(0) ?: return
            var y = 0
            var v: View = target
            while (v !== content && v.parent is View) {
                y += v.top
                v = v.parent as View
            }
            sv.smoothScrollTo(0, (y - (120 * sv.resources.displayMetrics.density)).toInt().coerceAtLeast(0))
        }

        private fun findScroll(v: View): androidx.core.widget.NestedScrollView? {
            if (v is androidx.core.widget.NestedScrollView) return v
            if (v is ViewGroup) for (i in 0 until v.childCount) findScroll(v.getChildAt(i))?.let { return it }
            return null
        }

        private fun flash(v: View) {
            android.animation.ObjectAnimator.ofFloat(v, "alpha", 1f, 0.2f, 1f, 0.2f, 1f).setDuration(1000).start()
        }
    }
}
