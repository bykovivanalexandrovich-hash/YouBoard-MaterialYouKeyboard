package com.materialyou.keyboard

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import androidx.annotation.RequiresApi
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.widget.NestedScrollView
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.color.MaterialColors

/**
 * Light "frosted glass" for the top bar of the app screens and for the floating bottom tab bar:
 * the content that scrolls under them is blurred a little and tinted with the surface colour.
 * The real blur needs Android 12+; older versions get the same translucent tint without the blur.
 * The switch "Blur panels" (pref ui_blur) in the Control Center turns all of it off.
 */
object Frost {
    const val KEY = "ui_blur"

    fun enabled(p: SharedPreferences) = p.getBoolean(KEY, true)

    private fun <T : View> find(root: View, cls: Class<T>): T? {
        if (cls.isInstance(root)) return cls.cast(root)
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) {
                val r = find(root.getChildAt(i), cls)
                if (r != null) return r
            }
        }
        return null
    }

    /** The vertical scroller of a screen (used by the bottom bar to follow the scrolling direction). */
    fun scrollOf(root: View?): View? {
        if (root == null) return null
        return find(root, NestedScrollView::class.java) ?: find(root, android.widget.ScrollView::class.java)
    }

    /**
     * Top bar of a screen with a collapsing toolbar: the scrolling content is moved under the bar (it keeps the same
     * position at rest through a top padding that follows the bar) and the bar's scrim becomes a blurred glass.
     */
    fun top(act: Activity, p: SharedPreferences) {
        if (!enabled(p)) return
        val content = act.findViewById<ViewGroup>(android.R.id.content) ?: return
        val appBar = find(content, AppBarLayout::class.java) ?: return
        val scroll = find(content, NestedScrollView::class.java) ?: return
        val ctl = find(appBar, CollapsingToolbarLayout::class.java) ?: return
        val lp = scroll.layoutParams as? CoordinatorLayout.LayoutParams ?: return
        val d = act.resources.displayMetrics.density

        lp.behavior = null
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT
        scroll.layoutParams = lp
        scroll.clipToPadding = false
        appBar.setBackgroundColor(Color.TRANSPARENT)
        appBar.bringToFront()

        val surface = MaterialColors.getColor(content, com.google.android.material.R.attr.colorSurface, 0xFF141218.toInt())
        val tint = MaterialColors.getColor(content, com.google.android.material.R.attr.colorSurfaceContainer, 0xFF2B2930.toInt())
        val src: () -> View? = { scroll }
        val scrim = FrostDrawable(src, surface, tint, 0f, 9f * d, 0, 0f, true, 0xB0, 0xF2)
        val status = FrostDrawable(src, surface, tint, 0f, 9f * d, 0, 0f, true, 0xB0, 0xF2)
        ctl.setContentScrim(scrim)
        ctl.setStatusBarScrim(status)

        fun sync() {
            val t = if (appBar.visibility == View.GONE) 0 else maxOf(appBar.bottom, 0)
            if (scroll.paddingTop != t) scroll.setPadding(scroll.paddingLeft, t, scroll.paddingRight, scroll.paddingBottom)
        }
        appBar.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { _, _ -> sync() })
        scroll.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> sync() }

        if (Build.VERSION.SDK_INT >= 31) {
            val vto = scroll.viewTreeObserver
            vto.addOnScrollChangedListener(ViewTreeObserver.OnScrollChangedListener {
                scrim.invalidateSelf()
                status.invalidateSelf()
            })
            vto.addOnGlobalLayoutListener(ViewTreeObserver.OnGlobalLayoutListener {
                scrim.invalidateSelf()
                status.invalidateSelf()
            })
        }
    }
}

/**
 * A rounded, tinted background that shows a blurred copy of what is behind the view it belongs to.
 * [source] is the view whose picture is blurred (it must not contain the host view); [fill] is painted under it
 * when the source has no background of its own.
 */
class FrostDrawable(
    private val source: () -> View?,
    internal val fill: Int?,
    private val tint: Int,
    private val corner: Float,
    internal val radius: Float,
    private val stroke: Int,
    private val strokeW: Float,
    private val enabled: Boolean,
    private val blurAlpha: Int,
    private val plainAlpha: Int
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    internal var alphaV = 255
    internal var node: Any? = null
    private var busy = false

    private fun cr(): Float = minOf(corner, minOf(bounds.width(), bounds.height()) / 2f)

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val rect = RectF(b)
        val r = cr()
        var blurred = false
        if (enabled && Build.VERSION.SDK_INT >= 31 && canvas.isHardwareAccelerated && !busy) {
            val host = callback as? View
            val src = source()
            if (host != null && src != null && src.isAttachedToWindow && src.width > 0 && src.height > 0) {
                busy = true
                val save = canvas.save()
                try {
                    if (r > 0f) {
                        path.reset()
                        path.addRoundRect(rect, r, r, Path.Direction.CW)
                        canvas.clipPath(path)
                    } else {
                        canvas.clipRect(rect)
                    }
                    blurred = Blur31.draw(this, canvas, host, src)
                } catch (_: Throwable) {
                    blurred = false
                } finally {
                    canvas.restoreToCount(save)
                    busy = false
                }
            }
        }
        val a = (if (blurred) blurAlpha else plainAlpha) * alphaV / 255
        paint.style = Paint.Style.FILL
        paint.color = (tint and 0x00FFFFFF) or (a shl 24)
        canvas.drawRoundRect(rect, r, r, paint)
        if (strokeW > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = strokeW
            paint.color = (stroke and 0x00FFFFFF) or ((stroke ushr 24) * alphaV / 255 shl 24)
            val h = strokeW / 2f
            canvas.drawRoundRect(RectF(rect.left + h, rect.top + h, rect.right - h, rect.bottom - h), maxOf(r - h, 0f), maxOf(r - h, 0f), paint)
        }
    }

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, cr())
        outline.alpha = 1f
    }

    override fun setAlpha(alpha: Int) {
        alphaV = alpha
        invalidateSelf()
    }

    override fun getAlpha(): Int = alphaV

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** The Android 12+ part, kept apart so that older devices never load the classes it needs. */
@RequiresApi(31)
internal object Blur31 {
    fun draw(d: FrostDrawable, canvas: Canvas, host: View, src: View): Boolean {
        val b = d.bounds
        val w = b.width()
        val h = b.height()
        if (w <= 0 || h <= 0) return false
        val node = (d.node as? android.graphics.RenderNode) ?: android.graphics.RenderNode("frost").also { d.node = it }
        node.setPosition(0, 0, w, h)
        node.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(d.radius, d.radius, android.graphics.Shader.TileMode.CLAMP))
        val hl = IntArray(2)
        val sl = IntArray(2)
        host.getLocationOnScreen(hl)
        src.getLocationOnScreen(sl)
        val dx = (hl[0] + b.left - sl[0]).toFloat()
        val dy = (hl[1] + b.top - sl[1]).toFloat()
        val rec = node.beginRecording(w, h)
        try {
            d.fill?.let { rec.drawColor(it) }
            rec.translate(-dx, -dy)
            src.draw(rec)
        } finally {
            node.endRecording()
        }
        node.setAlpha(d.alphaV / 255f)
        val save = canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        canvas.drawRenderNode(node)
        canvas.restoreToCount(save)
        return true
    }
}
